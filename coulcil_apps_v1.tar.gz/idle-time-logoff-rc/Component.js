sap.ui.define([
  "sap/ui/core/Component",
  "sap/ui/model/json/JSONModel",
  "sap/ui/model/odata/v2/ODataModel",
  "sap/ui/Device"
], function(Component, JSONModel, Device, ODataModel) {

  return Component.extend("auto.logoff.Component", {

    metadata: {
      "manifest": "json"
    },

    init: function() {
      var t;
      var oTimeOutModel = new JSONModel();
      var oChkExtModel = new JSONModel();
      var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/Z_IDLE_LOGOFF_SRV/", true);
      oModel.setUseBatch(false);
      var oDeviceModel = new sap.ui.model.json.JSONModel(Device);
      oDeviceModel.setDefaultBindingMode("OneWay");
       if(jQuery.sap.getUriParameters() != null && jQuery.sap.getUriParameters() != undefined){
            if(jQuery.sap.getUriParameters().get("zsap-conn-ac") != null && jQuery.sap.getUriParameters().get("zsap-conn-ac") != undefined){
                var urlParValue= jQuery.sap.getUriParameters().get("zsap-conn-ac").trim();
            };
       };

       if(urlParValue == 'wd'){
        document.addEventListener("mousemove", resetTimer, false);
        document.addEventListener("mousedown", resetTimer, false);
        document.addEventListener("mousewheel", resetTimer, false);
        document.addEventListener("keypress", resetTimer, false);
        document.addEventListener("DOMMouseScroll", resetTimer, false);
        document.addEventListener("MSPointerMove", resetTimer, false);
        document.addEventListener("touchstart", resetTimer, false);
        document.addEventListener("touchmove", resetTimer, false);
        document.addEventListener("touchend", resetTimer, false);
        oModel.read("/SrvTimeOutSet", {
        success: function(oData, oResponse) {
          oTimeOutModel.setSizeLimit(200);
          oTimeOutModel.setData(oData.results);
          sap.ushell.services._globaltimeoutmodel = oTimeOutModel;
         },
       });
      };

      function resetTimer() {
        var application = sap.ushell.services.AppConfiguration.getCurrentAppliction();
        var pos = application.url.search("/sap/bc/ui5_ui5/sap/");
        pos = pos + 20;
        var appnameurl = application.url.slice(pos);
        var appnameindex = appnameurl.indexOf("/");
        var appname = appnameurl.slice(0, appnameindex);
        var appnameUC = appname.toUpperCase();
        var localtimeoutmodel = new sap.ui.model.json.JSONModel();
        localtimeoutmodel = sap.ushell.services._globaltimeoutmodel;
         var localtimeout;
         localtimeout = localtimeoutmodel.oData;
         var servicetime;
         for(var i = 0; i < localtimeout.length; i++)  {
            if (localtimeout[i].SrvName == appnameUC)
             {  servicetime = localtimeout[i]; break; };
            };

        clearTimeout(t);
        if (servicetime != undefined ) {
        var servicetimems = 1000 * servicetime.TimeOut };
        if (servicetimems == undefined) {servicetimems = 600000 };
        t = setTimeout(logoff, servicetimems);
      };

      function logoff() {
        sap.ushell.Container.logout();
      };

    },
  });
});