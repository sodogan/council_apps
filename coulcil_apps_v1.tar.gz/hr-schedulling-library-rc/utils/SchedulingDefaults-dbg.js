sap.ui.define([
	"jquery.sap.global"
],
function(jQuery) {
    "use strict";

    function SchedulingDefaults() {
        return this;
    }

    return new SchedulingDefaults();

});