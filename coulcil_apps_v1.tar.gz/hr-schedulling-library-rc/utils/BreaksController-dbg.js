/* global moment:true */
sap.ui.define([
    "jquery.sap.global",
    "sap/ui/base/Object",
    "sap/ui/core/format/DateFormat",
    "team/zag/library/scheduling/utils/Break"
], function(jQuery, Object, DateFormat, Break) {
	"use strict";

    var oTimeFormatter = DateFormat.getDateInstance({pattern: "PTHH'H'mm'M'ss'S'", UTC: false});
	var oTimeFormatterUTC = DateFormat.getDateInstance({pattern: "PTHH'H'mm'M'ss'S'", UTC: true});

    var BreaksController = Object.extend("team.zag.library.scheduling.utils.BreaksController", {

        _aBreaksConfiguration: [],
        _aBreakTimes: [],

        constructor: function(sBreaksConfiguration) {
            this.setBreaks(sBreaksConfiguration);
        },

        setBreaks: function(sBreaks) {
            this._aBreaksConfiguration = [];
            if (sBreaks) {
                var aBreaks = sBreaks.split(",");
                aBreaks.forEach(function(sBreak) {
                    var aDurationAndThreshold = sBreak.split("|");
                    if (aDurationAndThreshold.length === 2) {
                        this._aBreaksConfiguration.push(new Break(aDurationAndThreshold[0], aDurationAndThreshold[1]));
                    } else {
                        this._aBreaksConfiguration.push(new Break(sBreak, undefined));
                    }
                }.bind(this));
            }
        },

        setBreaksConfiguration: function(aBreaksConfiguration) {
            this._aBreaksConfiguration = aBreaksConfiguration;
        },

        setBreakTimes: function(aBreakStartTimes) {
            if (aBreakStartTimes && aBreakStartTimes.length) {
                for (var i = 0; i < aBreakStartTimes.length; i++) {
                    var oThresholdDuration = moment.duration(this._aBreaksConfiguration[i].getThreshold().format("HH:mm"), "hours");
                    var oStartTime = moment(this._parseODataTime(aBreakStartTimes[i])).add(oThresholdDuration.asHours(), "hours");
                    this._aBreaksConfiguration[i].setStartTime(oStartTime);
                }
            }
        },

        getBreaksConfiguration: function() {
            return this._aBreaksConfiguration;
        },

        calculateEndTime: function(sStartTime, sHours) {
            if (!sStartTime || !sHours) {
                return undefined;
            }
            var oStartTime = moment(this._parseODataTime(sStartTime));
            var oHours = moment(this._parseODataTime(sHours));
            var oEndTime = oStartTime.add(oHours.hours(), "hours");
            return oTimeFormatter.format(oEndTime.toDate());
        },

        calculateEndTimeWithBreaks: function(sStartTime, sHours) {
            if (!sStartTime || !sHours) {
                return undefined;
            }
            var oStartTime = moment(this._parseODataTime(sStartTime));
            var oHours = moment(this._parseODataTime(sHours));
            var oEndTime = oStartTime.add(moment.duration(sHours).asHours(), "hours");
            var aBreaks = this.getBreaksConfiguration();
            aBreaks.forEach(function(oBreak) {
                var oThreshold = oBreak.getThreshold();
                if (oThreshold && oHours.isAfter(oThreshold)) {
                    var oDuration = oBreak.getDuration().asHours();
                    oEndTime = oEndTime.add(oDuration, "hours");
                }
            });
            return oTimeFormatter.format(oEndTime.toDate());
        },

        calculateEndTimeWithBreaksForAdditionalHours: function(sHours, sAdditionalHoursStartTime, sAdditionalHoursEndTime) {
            if (!sHours || !sAdditionalHoursStartTime || !sAdditionalHoursEndTime) {
                return undefined;
            }
            var oHours = moment(this._parseODataTime(sHours));
            var oAdditionalHoursStartTime = moment(this._parseODataTime(sAdditionalHoursStartTime));
            var oAdditionalHoursEndTime = moment(this._parseODataTime(sAdditionalHoursEndTime));
            var aBreaks = this.getBreaksConfiguration();
            aBreaks.forEach(function(oBreak) {
                var oThreshold = oBreak.getThreshold();
                if (oThreshold && oHours.isAfter(oThreshold)) {
                    var oBreakStartTime = oBreak.getStartTime();
                    if (oBreakStartTime && oBreakStartTime.isSameOrAfter(oAdditionalHoursStartTime) && oBreakStartTime.isSameOrBefore(oAdditionalHoursEndTime)) {
                        var oDuration = oBreak.getDuration().asHours();
                        oAdditionalHoursEndTime = oAdditionalHoursEndTime.add(oDuration, "hours");
                    }
                }
            });
            return oTimeFormatter.format(oAdditionalHoursEndTime.toDate());
        },

        _parseODataTime: function(vTime) {
			if (vTime && vTime.ms !== undefined) {
				return oTimeFormatter.parse(oTimeFormatterUTC.format(new Date(vTime.ms)));
			}
			if (vTime) {
				return oTimeFormatter.parse(vTime);
			}
			return undefined;
		}


    });

    return BreaksController;

});