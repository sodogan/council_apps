/* global md5:true */
sap.ui.define([
    "jquery.sap.global"
], function(jQuery) {
	"use strict";

    var iWeekInMilliseconds = (7 * 24 * 60 * 60 * 1000);
    var iTwoWeeksInMilliseconds = (7 * 24 * 60 * 60 * 1000 * 2);

	return {

        CALENDAR: {
            MY_TEAM: md5("MY_TEAM").replace(/(\w{8})(\w{4})(\w{4})(\w{4})(\w{12})/, "$1-$2-$3-$4-$5"),
            ME: md5("ME").replace(/(\w{8})(\w{4})(\w{4})(\w{4})(\w{12})/, "$1-$2-$3-$4-$5")
        },

        SCHEDULE_REQUEST_TYPE: {
            ON_CALL: "90",
            DAY_OFF: "OFF",
            PH_W_ALT_DAY: "12",
            PH_WO_ALT_DAY: "21",
            RESCHEDULE_CONTRACT_HOURS: "10",
            SCHEDULE_ADDITIONAL_HOURS: "20",
            SCHEDULE_CONTRACT_HOURS_AND_ADDITIONAL_HOURS: "30"
        },

        EVENT_TYPE: {
            ABSENCE: "01"
        },

        EMPLOYEE: {
            SCHEDULE_TYPE: {
                FIXED: "FIXED",
                FLEX: "FLEX"
            }
        },

        CALENDAR_BUILT_IN_VIEWS: ["Week", "Day", "One Month"],

        CALENDAR_VIEW_TYPES: ["Week", "Day", "One Month"],

        CROSS_NAVIGATION_LEAVE_REQUEST: {
            target: {
                semanticObject: "LeaveRequest",
                action: "manage"
            }
        },

        CROSS_NAVIGATION_SCHEDULE_CHANGE: {
            target: {
                semanticObject: "Schedule",
                action: "manageSchedule"
            }
        },

        FILTER_DELAY_MS: 1000,

        asGuid: function(sString) {
            return sString.replace(/(\w{8})(\w{4})(\w{4})(\w{4})(\w{12})/, "$1-$2-$3-$4-$5");
        },

        resetHours: function(oDate) {
            return new Date(new Date(oDate).setHours(0, 0, 0, 0));
        },

        addWeek: function(oDate, iWeeks) {
            return new Date(oDate.getTime() + (iWeekInMilliseconds * (iWeeks ? iWeeks : 1)));
        },

        addMonth: function(oDate) {
            return new Date(new Date(new Date(oDate).setMonth(oDate.getMonth() + 1)).setDate(1));
        },

        calculateIntervalDifference: function(oDate, oStartDate, oEndDate, iMultiply) {
            var iTimeInMilliseconds = (oEndDate.getTime() - oStartDate.getTime() + 1) * iMultiply;
            if (Math.abs(iTimeInMilliseconds) > iTwoWeeksInMilliseconds) {
                var bIsStart = (oDate === oStartDate);
                oDate = new Date(oDate.getTime());
                if (bIsStart) {
                    oDate.setMonth(oDate.getMonth() + iMultiply);
                } else {
                    oDate.setMonth(oDate.getMonth() + (bIsStart ? 0 : iMultiply + 1));
                }
                oDate.setDate(bIsStart ? 1 : 0);
                return oDate;
            }
            return new Date(oDate.getTime() + iTimeInMilliseconds);
        },

        getEndDateForListSchedule: function(oEndDate) {
            if (oEndDate.getMilliseconds() !== 999) {
                return new Date(oEndDate.getTime() - 1);
            }
            return oEndDate;
        },

        createAppSpecificRoute: function(oRoute, sAppSpecificRoute) {
            var _oRoute = _.cloneDeep(oRoute);
            _oRoute.appSpecificRoute = sAppSpecificRoute;
            return _oRoute;
        },

        waitForPendingRequests: function(oModel) {
            return new Promise(function(fnResolve) {
                var bHasPendingRequests = oModel.hasPendingRequests();
                if (bHasPendingRequests) {
                    var fnOnResponse = function(oEvent) {
                        if (!this.hasPendingRequests()) {
                            this.detachEvent("requestCompleted", fnOnResponse);
                            this.detachEvent("requestFailed", fnOnResponse);
                            jQuery.sap.delayedCall(0, this, function() {
                                fnResolve();
                            });
                        }
                    };
                    oModel.attachEvent("requestCompleted", fnOnResponse);
                    oModel.attachEvent("requestFailed", fnOnResponse);
                } else {
                    jQuery.sap.delayedCall(0, this, function() {
                        fnResolve();
                    });
                }
            });
        },

        capitalize: function(sString) {
            if (typeof sString !== "string") {
                return "";
            }
            return sString.charAt(0).toUpperCase() + sString.slice(1);
        },

        removeMeta: function(oObject) {
			for (var sProperty in oObject) {
				if (sProperty === "__metadata") {
					delete oObject[sProperty];
				} else if (typeof oObject[sProperty] === "object") {
					this.removeMeta(oObject[sProperty]);
				}
			}
			return oObject;
		},

		relocateResults: function(oObject) {
			for (var sProperty in oObject) {
				if (oObject[sProperty] && oObject[sProperty].results instanceof Array) {
					oObject[sProperty] = oObject[sProperty].results;
				} else if (typeof oObject[sProperty] === "object") {
					this.relocateResults(oObject[sProperty]);
				}
			}
			return oObject;
		},

		patchODataObject: function(oObject) {
			var oPatchedObject = this.removeMeta(oObject);
			return this.relocateResults(oPatchedObject);
		}

    };
});