sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/Locale",
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/format/NumberFormat"
],
function(jQuery, Locale, DateFormat, NumberFormat) {
    "use strict";

    var _oLocale = new Locale("en");

    var Formatter = {

        newGuid: function() {
            return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(c) {
                var r = Math.random() * 16 | 0,
                    v = c === "x" ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
        },

        parseAbapBoole: function(bValue) {
            return bValue ? "X" : "";
        },

        parseBoolean: function(sValue) {
            return !!sValue;
        },

        parseStringArray: function(sArray) {
            return sArray ? sArray.split(",") : [];
        },

        parseArrayString: function(aString) {
            return aString.toString();
        },

        parseODataDate: function(sDate) {
            if (sDate && sDate.indexOf && sDate.indexOf("/Date(") !== -1) {
                return new Date(Number(sDate.match(/\(([^)]+)\)/)[1]));
            }
            return new Date(sDate);
        },

        toUTCDate: function(oDate) {
            return new Date(Date.UTC(oDate.getFullYear(), oDate.getMonth(), oDate.getDate()));
        },

        formatDate: function(oDate) {
            if (oDate && oDate.indexOf && oDate.indexOf("/Date(") !== -1) {
                jQuery.sap.log.error("formatDate: '" + oDate + "' looks like an incorrect date.");
                oDate = new Date(Number(oDate.match(/\(([^)]+)\)/)[1]));
            }
            return oDate ? DateFormat.getInstance({pattern: "dd/MM/yyyy"}).format(oDate) : "";
        },

        formatDateSmall: function(oDate) {
            if (oDate && oDate.indexOf && oDate.indexOf("/Date(") !== -1) {
                jQuery.sap.log.error("formatDateSmall: '" + oDate + "' looks like an incorrect date.");
                oDate = new Date(Number(oDate.match(/\(([^)]+)\)/)[1]));
            }
            return oDate ? DateFormat.getInstance({pattern: "dd/MM/yy"}).format(oDate) : "";
        },

        formatNetValue: function(sNetValue) {
            if (sNetValue) {
                try {
                    return NumberFormat.getCurrencyInstance({groupingEnabled: false, decimals: 2}, _oLocale).format(sNetValue);
                } catch (oError) {
                    jQuery.sap.log.error("formatNetValue: '" + sNetValue + "' cannot be converted to float.");
                }
            }
            return undefined;
        },

        formatNetValueAndCurrency: function(sNetValue, sCurrency) {
            if (sNetValue && sCurrency) {
                try {
                    return NumberFormat.getCurrencyInstance({groupingEnabled: false, decimals: 2}, _oLocale).format(parseFloat(sNetValue)) + " " + sCurrency.toUpperCase();
                } catch (oError) {
                    jQuery.sap.log.error("formatNetValueAndCurrency: '" + sNetValue + "' cannot be converted to float.");
                }
            }
            return undefined;
        },

        formatNetValueGrouping: function(sNetValue) {
            if (sNetValue) {
                try {
                    return NumberFormat.getCurrencyInstance({groupingEnabled: true, decimals: 2}, _oLocale).format(sNetValue);
                } catch (oError) {
                    jQuery.sap.log.error("formatNetValueGrouping: '" + sNetValue + "' cannot be converted to float.");
                }
            }
            return undefined;
        },

        formatNetValueAndCurrencyGrouping: function(sNetValue, sCurrency) {
            if (sNetValue && sCurrency) {
                try {
                    return NumberFormat.getCurrencyInstance({groupingEnabled: true, decimals: 2}, _oLocale).format(parseFloat(sNetValue)) + " " + sCurrency.toUpperCase();
                } catch (oError) {
                    jQuery.sap.log.error("formatNetValueAndCurrencyGrouping: '" + sNetValue + "' cannot be converted to float.");
                }
            }
            return undefined;
        },

        formatNetValueWithSign: function(sNetValue) {
            if (sNetValue) {
                try {
                    return "$ " + NumberFormat.getCurrencyInstance({decimals: 0}, _oLocale).format(parseFloat(sNetValue).toFixed(0));
                } catch (oError) {
                    jQuery.sap.log.error("formatNetValueWithSign: '" + sNetValue + "' cannot be converted to float.");
                }
            }
            return undefined;
        },

        formatQuantity: function(sQuantity) {
            if (sQuantity) {
                try {
                    return parseInt(sQuantity, 10);
                } catch (oError) {
                    jQuery.sap.log.error("formatQuantity: '" + sQuantity + "' cannot be converted to integer.");
                }
            }
            return undefined;
        },

        formatDescriptionAndCode: function(sDescription, sCode) {
            if (sDescription && sCode) {
                return this._oResourceBundle.getText("NZ.GOVT.CCC.LIBRARY.CASHDESK.CODE_AND_DESCRIPTION_FORMATTER", [sDescription, sCode]);
            }
            return undefined;
        },

        formatDescriptionAndCodeOptional: function(sDescription, sCode) {
            if (sCode) {
                return this._oResourceBundle.getText("NZ.GOVT.CCC.LIBRARY.CASHDESK.CODE_AND_DESCRIPTION_FORMATTER", [sDescription, sCode]);
            }
            return undefined;
        },

        parseDecimal: function(sDecimal) {
            if (sDecimal) {
                try {
                    return parseFloat(sDecimal);
                } catch (oError) {
                    jQuery.sap.log.error("parseDecimal: '" + sDecimal + "' cannot be converted to float.");
                }
            }
            return undefined;
        },

        isValidWhenNotNull: function(oObject) {
            return (oObject ? sap.ui.core.ValueState.None : sap.ui.core.ValueState.Error);
        },

        isValidWhenNotEmpty: function(sString) {
            return (sString && sString !== "" ? sap.ui.core.ValueState.None : sap.ui.core.ValueState.Error);
        },

        isValidWhenNotEmptyOrX: function(sString, sXString) {
            return (sString && sString !== "" && sXString !== "X" ? sap.ui.core.ValueState.None : sap.ui.core.ValueState.Error);
        },

        isTrueWhenEmpty: function(sString) {
            return (!sString || sString === null || sString === "");
        },

        isTrueWhenNotEmpty: function(sString) {
            return (sString !== undefined && sString !== null && sString !== "");
        },

        isValidWhenPositiveInteger: function(sString) {
            try {
                return (sString !== undefined && sString !== "" && parseInt(sString, 10) > 0 ? sap.ui.core.ValueState.None : sap.ui.core.ValueState.Error);
            } catch (oError) {
                jQuery.sap.log.error("isValidWhenPositiveInteger: '" + sString + "' cannot be converted to integer.");
            }
            return sap.ui.core.ValueState.Error;
        },

        isTrueWhenPositiveInteger: function(sString) {
            try {
                return (sString !== undefined && sString !== "" && parseInt(sString, 10) > 0);
            } catch (oError) {
                jQuery.sap.log.error("isTrueWhenPositiveInteger: '" + sString + "' cannot be converted to integer.");
            }
            return false;
        },

        isValidWhenPositive: function(sString) {
            try {
                return (sString !== undefined && sString !== "" && parseFloat(sString) > 0 ? sap.ui.core.ValueState.None : sap.ui.core.ValueState.Error);
            } catch (oError) {
                jQuery.sap.log.error("isValidWhenPositive: '" + sString + "' cannot be converted to integer.");
            }
            return sap.ui.core.ValueState.Error;
        },

        isTrueWhenPositive: function(sString) {
            try {
                return (sString !== undefined && sString !== "" && parseFloat(sString) > 0);
            } catch (oError) {
                jQuery.sap.log.error("isTrueWhenPositive: '" + sString + "' cannot be converted to integer.");
            }
            return false;
        }

    };

    return Formatter;

}, /* bExport= */ true);