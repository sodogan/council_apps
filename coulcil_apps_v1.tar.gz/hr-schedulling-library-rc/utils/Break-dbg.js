/* global moment:true */
sap.ui.define([
    "jquery.sap.global",
    "sap/ui/base/Object"
], function(jQuery, Object) {
	"use strict";

    var Break = Object.extend("team.zag.library.scheduling.utils.Break", {

        _oDuration: undefined,
        _oThreshold: undefined,
        _oStartTime: undefined,

        constructor: function(vDuration, vThreshold) {
            if (vDuration) {
                this._oDuration = (vDuration.indexOf(":") !== -1 ? moment.duration(vDuration, "HH:mm") : moment.duration(parseFloat(vDuration), "hours"));
            }
            if (vThreshold) {
                vThreshold = (vThreshold.indexOf(":") !== -1 ? moment.duration(vThreshold, "HH:mm").asHours() : parseFloat(vThreshold));
                this._oThreshold = moment(0).startOf("day").add(vThreshold, "hours");
            }
        },

        getDuration: function() {
            return this._oDuration;
        },

        getThreshold: function() {
            return this._oThreshold;
        },

        setStartTime: function(oStartTime) {
            this._oStartTime = oStartTime;
        },

        getStartTime: function() {
            return this._oStartTime;
        }

    });

    return Break;

});