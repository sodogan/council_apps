/*!
 * ${copyright}
 */

/**
 * Initialization Code and shared classes of library team.zag.library.scheduling.library.
 */
sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/library",
    "team/zag/library/scheduling/utils/md5",
	"team/zag/library/scheduling/utils/lodash.min",
	"team/zag/library/scheduling/utils/moment.min",
	"team/zag/library/scheduling/utils/moment-duration-format.min",
	"team/zag/library/scheduling/utils/polyfill.min"
], function(jQuery, library, md5js, lodashjs, momentjs, momentjs_format, es6Promisejs) {
	"use strict";

	/**
	 * NOT FOR PRODUCTIVE USE
	 *
	 * @namespace
	 * @name team.zag.library.scheduling
	 * @author Daniel Ruiz
	 * @version 0.0.9
	 * @public
	 */

	// delegate further initialization of this library to the Core
	sap.ui.getCore().initLibrary({
		name: "team.zag.library.scheduling",
		version: "0.0.9",
		dependencies: [
			"sap.ui.core"
		],
		types: [],
		interfaces: [],
		controls: [
			"team.zag.library.scheduling.controls.SchedulerPlanningCalendar"
		],
		elements: []
	});

	/* eslint-disable */
	return team.zag.library.scheduling;
	/* eslint-enable */

}, /* bExport= */ false);