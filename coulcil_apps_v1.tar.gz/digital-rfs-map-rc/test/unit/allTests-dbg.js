sap.ui.define([
	"ZRFSDigital/ZRFSDigital_v6/test/unit/controller/mapApp.controller"
], function () {
	"use strict";
});