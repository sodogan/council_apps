sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"ZRFSDigital/ZRFSDigital_v6/model/models"
], function (UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("ZRFSDigital.ZRFSDigital_v6.Component", {

		metadata: {
			manifest: "json",
			fullWidth: true //Set your fullscreen parameter here!
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			var parameters = {
				json: true
			};
			var sServiceUrl = "/sap/opu/odata/sap/ZGW_RFS_SERVICESV2_SRV/";
			var oAppDetailsModel = new sap.ui.model.odata.v2.ODataModel(sServiceUrl, parameters);

			//set the model
			sap.ui.getCore().setModel(oAppDetailsModel);
			oAppDetailsModel.setUseBatch(false);

			//global variables in CRM system - ZRFS_GIS_WEB_APP_URL
			oAppDetailsModel.read("/AppDetailsSet", {
				filters: [
					new sap.ui.model.Filter({
						path: "Name",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: "ZRFS_GIS_WEB_APP_URL"
					})
				],
				success: function (data) {
					var oJsonModel = new sap.ui.model.json.JSONModel();
					oJsonModel.setData(data);
					var appDetails = oJsonModel.getProperty("/results/0");
					$.sap.sGisBaseUrl = appDetails.Value;
				},
				error: function (oError) {
					var errorObject = JSON.parse(oError.responseText);
					sap.m.MessageToast.show(errorObject.error.message.value);
				}
			});
			//url parameters (cater for lower and upper case parameters)
			$.sap.sObjectId = jQuery.sap.getUriParameters().get("objectid");
			if ($.sap.sObjectId === null || typeof $.sap.sObjectId === "undefined") {
				$.sap.sObjectId = jQuery.sap.getUriParameters().get("OBJECTID");
			}
			$.sap.sRfsGuid = jQuery.sap.getUriParameters().get("rfsguid");
			if ($.sap.sRfsGuid === null || typeof $.sap.sRfsGuid === "undefined") {
				$.sap.sRfsGuid = jQuery.sap.getUriParameters().get("RFSGUID");
			}
			//this connects UI5 session with CRM WebUI session => GUID
			$.sap.sSharedMemoryId = jQuery.sap.getUriParameters().get("sharedmemoryid");
			if ($.sap.sSharedMemoryId === null || typeof $.sap.sSharedMemoryId === "undefined") {
				$.sap.sSharedMemoryId = jQuery.sap.getUriParameters().get("SHAREDMEMORYID");
			}
			// $.sap.sProblemGroup = jQuery.sap.getUriParameters().get("problemgroup"); //keys
			// $.sap.sProblem = jQuery.sap.getUriParameters().get("problem");
			// $.sap.sConditions = jQuery.sap.getUriParameters().get("conditions");
			
			//asset level 3 in url
			$.sap.sAssetL3 = jQuery.sap.getUriParameters().get("assetl3");
			if ($.sap.sAssetL3 === null || typeof $.sap.sAssetL3 === "undefined") {
				$.sap.sAssetL3 = jQuery.sap.getUriParameters().get("ASSETL3");
			}
			if ($.sap.sAssetL3 !== null && $.sap.sAssetL3 !== "undefined" ) {
				 $.sap.sAssetL2 = $.sap.sAssetL3.slice(0, 10);
			} 
			
			//asset from GIS for redetrmination
			$.sap.sAssetGISReDet = jQuery.sap.getUriParameters().get("assetgisredet");
			if ($.sap.sAssetGISReDet === null || typeof $.sap.sAssetGISReDet === "undefined") {
				$.sap.sAssetGISReDet = jQuery.sap.getUriParameters().get("ASSETGISREDET");
			}
			
			$.sap.sXcoordinate = jQuery.sap.getUriParameters().get("xcoordinate");
			if ($.sap.sXcoordinate === null || typeof $.sap.sXcoordinate === "undefined") {
				$.sap.sXcoordinate = jQuery.sap.getUriParameters().get("XCOORDINATE");
			}
			$.sap.sYcoordinate = jQuery.sap.getUriParameters().get("ycoordinate");
			if ($.sap.sYcoordinate === null || typeof $.sap.sYcoordinate === "undefined") {
				$.sap.sYcoordinate = jQuery.sap.getUriParameters().get("YCOORDINATE");
			}
			$.sap.sCustomer = jQuery.sap.getUriParameters().get("customer");
			if ($.sap.sCustomer === null || typeof $.sap.sCustomer === "undefined") {
				$.sap.sCustomer = jQuery.sap.getUriParameters().get("CUSTOMER");
			}
			//confirmed contact person
			$.sap.sContact = jQuery.sap.getUriParameters().get("contact");
			if ($.sap.sContact === null || typeof $.sap.sContact === "undefined") {
				$.sap.sContact = jQuery.sap.getUriParameters().get("CONTACT");
			}
			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		}
	});
});