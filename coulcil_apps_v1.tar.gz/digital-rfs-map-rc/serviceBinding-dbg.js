// function initModel() {
// 	var sUrl = "/sap/opu/odata/sap/ZGW_RFS_SERVICESV2_SRV/";
// 	var oModel = new sap.ui.model.odata.v2.ODataModel(sUrl, true);
// 	sap.ui.getCore().setModel(oModel);
// }