sap.ui.define(["sap/ui/core/mvc/Controller", "ZRFSDigital/ZRFSDigital_v6/utils/mapUtilities", "sap/m/MessageBox", "sap/ui/core/Icon"],
	function (e, t) {
		"use strict";

		function s(e) {
			switch (e) {
			case "C":
				var t = "1";
				break;
			case "M":
				t = "2";
				break;
			case "U":
				t = "3";
				break;
			case "N":
				t = "5";
				break
			}
			return t
		}
		return e.extend("ZRFSDigital.ZRFSDigital_v6.controller.mapApp", {
			onInit: function () {
				var e = {
					SelectedPriority: "5",
					PriorityCollection: [{
						PriorityId: "1",
						Name: "Critical",
						Icon: "sap-icon://alert"
					}, {
						PriorityId: "2",
						Name: "Major",
						Icon: "sap-icon://error"
					}, {
						PriorityId: "3",
						Name: "Urgent",
						Icon: "sap-icon://message-error"
					}, {
						PriorityId: "5",
						Name: "Normal",
						Icon: "sap-icon://message-warning"
					}]
				};
				
				// Set css style for PGCcombobox
				$("#PGComboBox").css("background-color", "#ffffff");
				
				var s = new sap.ui.model.json.JSONModel(e);
				var a = sap.ui.getCore().byId("selectPriority");
				a.setModel(s);
				a.setSelectedKey("5");
				if (this.getView().byId("iFrameContent")) {
					this.getView().byId("iFrameContent").addEventDelegate({
						onAfterRendering: function () {
							if (window.addEventListener) {
								window.addEventListener("message", this.displayMessage.bind(this), false);
							} else {
								window.attachEvent("onmessage", this.displayMessage.bind(this));
							}
						}
					}, this)
				}
				t.readRFS($.sap.sObjectId);
			},
			bindEvent: function (e, t, s) {
				if (e.addEventListener) {
					e.addEventListener(t, s, false)
				} else if (e.attachEvent) {
					e.attachEvent("on" + t, s)
				}
			},
			onBeforeRendering: function () {},
			onAfterRendering: function () {
				this.bindEvent(window, "message", function (e) {});
				if (window.addEventListener) {
					window.addEventListener("message", this.displayMessage.bind(this), false)
				} else {
					window.attachEvent("onmessage", this.displayMessage.bind(this))
				}
			},
			displayMessage: function (e) {
				if (event.data) {
					var t = null;
					try {
						t = JSON.parse(event.data)
					} catch (e) {
						t = null
					}
					if (t) {
						if (typeof t.selectedL3Asset !== "undefined") {
							if (typeof t.selectedL3Asset.sapid === "undefined" || t.selectedL3Asset.sapid === null) {
								var s = t.sapid;
								var a = "";
								var o = t.sapid;
								var r = s
							} else {
								s = t.selectedL3Asset.sapid;
								a = t.sapid;
								o = t.sapid;
								r = s
							}
							sap.m.MessageToast.show("Asset ID:".concat(s));
							var i = sap.ui.getCore().byId("mapValue");
							i.setValue(s);
							i.setTooltip(t.description);
							i.data("xCoordinate", t.x.toString(), false);
							i.data("yCoordinate", t.y.toString(), false);
							i.data("addressStr", t.address, false);
							i.data("assetL2", a, false);
							i.data("assetGISReDet", o, false);
							var n = sap.ui.getCore().byId("PGComboBox");
							var d = sap.ui.getCore().byId("ProblemComboBox");
							var l = sap.ui.getCore().byId("ConditionMComboBox");
							var p = sap.ui.getCore().byId("selectPriority");
							if (n.getEditable() === false) {
								n.setEditable(true)
							}
							if (d.getEditable() === false) {
								d.setEditable(true)
							}
							if (l.getEditable() === false) {
								l.setEditable(true)
							}
							sap.ui.getCore().byId("ConfirmButton").setEnabled(true);
							sap.ui.getCore().byId("RefreshButton").setEnabled(true);
							n.setSelectedKey("");
							d.setSelectedKey("");
							l.removeAllSelectedItems();
							p.setSelectedKey("5");
							var u = sap.ui.getCore().getModel();
							u.setUseBatch(false);
							u.attachMetadataLoaded(function () {
								var e = u.getServiceMetadata();
								if (e.version !== "" && typeof e.version !== "undefined") {
									sap.m.MessageToast.show("Categorise Problem")
								}
							});
							u.read("/RFSProblemMatrixSet", {
								filters: [new sap.ui.model.Filter({
									path: "ZassetLevel2",
									operator: sap.ui.model.FilterOperator.EQ,
									value1: a
								}), new sap.ui.model.Filter({
									path: "ZassetLevel3",
									operator: sap.ui.model.FilterOperator.EQ,
									value1: r
								})],
								and: true,
								success: function (e, t) {
									if (typeof e.results !== "undefined" && e.results.length > 0) {
										var a = [];
										$.each(e.results, function (e, t) {
											a.push({
												key: t.ZproblemGrpId,
												text: t.ZproblemGrpShDesc,
												info: t.ZproblemGrpDesc + " (" + t.ZproblemGrpId + ")"
											})
										});
										a = a.map(JSON.stringify).reverse().filter(function (e, t, s) {
											return s.indexOf(e, t + 1) === -1
										}).reverse().map(JSON.parse);
										var o = new sap.ui.model.json.JSONModel(a);
										n.bindAggregation("items", {
											path: "/",
											template: new sap.ui.core.ListItem({
												key: "{key}",
												text: "{text}",
												tooltip: "{info}"
											})
										});
										n.setModel(o);
										var r = [];
										$.each(e.results, function (e, t) {
											if (t.ZproblemCode !== "") {
												r.push({
													key: t.ZproblemCode,
													text: t.ZprbCodeShTxt,
													info: t.ZprbCodeTxt + " (" + t.ZproblemCode + ")",
													keyPG: t.ZproblemGrpId,
													defPrio: t.ZdefPrio
												})
											}
										});
										r = r.map(JSON.stringify).reverse().filter(function (e, t, s) {
											return s.indexOf(e, t + 1) === -1
										}).reverse().map(JSON.parse);
										var i = new sap.ui.model.json.JSONModel(r);
										d.bindAggregation("items", {
											path: "/",
											template: new sap.ui.core.ListItem({
												key: "{key}",
												text: "{text}",
												tooltip: "{info}",
												customdata: [("keyPG", "{keyPG}"), ("defPrio", "{defPrio}")]
											})
										});
										d.setModel(i);
										var p = [];
										$.each(e.results, function (e, t) {
											if (t.Zconditions !== "") {
												p.push({
													key: t.Zconditions,
													text: t.ZcondShText,
													info: t.ZcondText + " (" + t.Zconditions + ")",
													keyPG: t.ZproblemGrpId,
													keyP: t.ZproblemCode,
													defPrio: t.ZdefPrio,
													condPrio: t.ZcondPrio
												})
											}
										});
										p = p.map(JSON.stringify).reverse().filter(function (e, t, s) {
											return s.indexOf(e, t + 1) === -1
										}).reverse().map(JSON.parse);
										var u = new sap.ui.model.json.JSONModel(p);
										l.bindAggregation("items", {
											path: "/",
											template: new sap.ui.core.ListItem({
												key: "{key}",
												text: "{text}",
												tooltip: "{info}",
												customdata: [("keyPG", "{keyPG}"), ("keyP", "{keyP}"), ("defPrio", "{defPrio}"), ("condPrio", "{condPrio}")]
											})
										});
										l.setModel(u);
										sap.m.MessageToast.show("Categorise Problem")
									} else {
										sap.m.MessageToast.show("No Problem Group/Problem found for Asset:".concat(s));
										n.setModel(new sap.ui.model.json.JSONModel({
											data: []
										}));
										d.setModel(new sap.ui.model.json.JSONModel({
											data: []
										}));
										l.setModel(new sap.ui.model.json.JSONModel({
											data: []
										}))
									}
								},
								error: function (e) {
									var t = JSON.parse(e.responseText);
									jQuery.sap.require("sap.m.MessageToast");
									sap.m.MessageToast.show(t.error.message.value)
								}
							})
						}
					}
				}
			},
			onMapValueChange: function (e) {
				sap.ui.getCore().byId("PGComboBox").setSelectedKey("");
				sap.ui.getCore().byId("ProblemComboBox").setSelectedKey("");
				sap.ui.getCore().byId("ConditionMComboBox").removeAllSelectedItems()
			},
			onMapValueSubmit: function (e) {
				var s = e.getParameter("value");
				sap.m.MessageToast.show(s);
				sap.ui.getCore().byId("PGComboBox").setSelectedKey("");
				sap.ui.getCore().byId("ProblemComboBox").setSelectedKey("");
				sap.ui.getCore().byId("ConditionMComboBox").removeAllSelectedItems();
				$.sap.problemMatrixRead = false;
				if ($.sap.problemMatrixRead !== true && s !== null && typeof s !== "undefined") {
					t.readProblemMatrix(s)
				}
			},
			onProblemGroupSelectionChange: function (e) {
				var t = e.getParameter("selectedItem");
				sap.m.MessageToast.show(t.getText());
				var s = sap.ui.getCore().byId("ProblemComboBox");
				var a = e.getParameter("selectedItem").getKey();
				var o = s.getBinding("items");
				var r = [];
				var i = new sap.ui.model.Filter("keyPG", sap.ui.model.FilterOperator.EQ, a);
				r.push(i);
				o.filter(r)
			},
			onProblemGroupBeforeRendering: function () {
				var e = sap.ui.getCore().byId("PGComboBox").getSelectedKey();
				var t = sap.ui.getCore().byId("ProblemComboBox");
				var s = e;
				var a = t.getBinding("items");
				var o = [];
				var r = new sap.ui.model.Filter("keyPG", sap.ui.model.FilterOperator.EQ, s);
				o.push(r);
				a.filter(o)
			},
			onProblemGroupChange: function (e) {
				var t = sap.ui.getCore().byId("PGComboBox");
				t.setTooltip(e.getParameter("value") + " (" + t.getSelectedKey() + ")");
			},
			onProblemChange: function (e) {
				var t = sap.ui.getCore().byId("ProblemComboBox");
				t.setTooltip(e.getParameter("value") + " (" + t.getSelectedKey() + ")");
			},
			onProblemSelectionChange: function (e) {
				var t = e.getParameter("selectedItem");
				sap.m.MessageToast.show(t.getText());
				var a = sap.ui.getCore().byId("ConditionMComboBox");
				var o = e.getParameter("selectedItem").getKey();
				var r = a.getBinding("items");
				var i = [];
				var n = new sap.ui.model.Filter("keyP", sap.ui.model.FilterOperator.EQ, o);
				i.push(n);
				r.filter(i);
				var d = sap.ui.getCore().byId("ProblemComboBox").getBinding("items");
				var l = [];
				l = d.oList.filter(function (e) {
					return e.key === o;
				});
				if (l[0].defPrio !== "undefined" && l[0].defPrio !== null && l[0].defPrio !== "") {
					var p = s(l[0].defPrio);
				} else {
					p = "5";
				}
				sap.ui.getCore().byId("selectPriority").setSelectedKey(p);
			},
			onConditionsSelectionChange: function (e) {
				var t = e.getParameter("changedItem");
				var a = e.getParameter("selected");
				var o = sap.ui.getCore().byId("ConditionMComboBox").getBinding("items");
				var r = [];
				r = o.oList.filter(function (e) {
					return e.key === t.getKey()
				});
				if (r[0].condPrio !== "undefined" && r[0].condPrio !== null) {
					var i = s(r[0].condPrio)
				}
				if (a === true && i !== null && parseInt(sap.ui.getCore().byId("selectPriority").getSelectedKey(), 10) > parseInt(i, 10)) {
					sap.ui.getCore().byId("selectPriority").setSelectedKey(i)
				}
			},
			onConditionsSelectionFinish: function (e) {
				var t = sap.ui.getCore().byId("ConditionMComboBox").getBinding("items");
				var a = sap.ui.getCore().byId("ConditionMComboBox").getSelectedKeys();
				var o = "5";
				var r = a.filter(function (e, t, s) {
					return e !== ""
				});
				if (r !== "undefined" && r !== null && r.length !== 0) {
					var i = function e(a, r, i) {
						var n = [];
						n = t.oList.filter(function (e) {
							return e.key === a
						});
						if (n[0].condPrio !== "undefined" && n[0].condPrio !== null) {
							var d = s(n[0].condPrio)
						}
						if (d !== null && parseInt(o, 10) >= parseInt(d, 10)) {
							o = d
						}
					};
					r.forEach(i)
				} else {
					var n = sap.ui.getCore().byId("ProblemComboBox").getSelectedKey();
					var d = sap.ui.getCore().byId("ProblemComboBox").getBinding("items");
					var l = [];
					l = d.oList.filter(function (e) {
						return e.key === n
					});
					if (l[0].defPrio !== "undefined" && l[0].defPrio !== null) {
						var p = s(l[0].defPrio)
					} else {
						p = "5"
					}
					o = p
				}
				sap.ui.getCore().byId("selectPriority").setSelectedKey(o)
			},
			onRefreshButtonPress: function (e) {
				t.refreshApp()
			},
			onCreateDuplicateDialogColumns: function () {
				return [new sap.m.Column({
					hAlign: "Begin",
					vAlign: sap.ui.core.VerticalAlign.Middle,
					width: "13%",
					header: new sap.m.Label({
						text: "Object ID"
					})
				}), new sap.m.Column({
					hAlign: "Center",
					vAlign: sap.ui.core.VerticalAlign.Middle,
					width: "45%",
					popinDisplay: "Inline",
					header: new sap.m.Label({
						text: "Description"
					}),
					minScreenWidth: "Medium",
					demandPopin: true
				}), new sap.m.Column({
					hAlign: "Begin",
					vAlign: sap.ui.core.VerticalAlign.Middle,
					width: "20%",
					header: new sap.m.Label({
						text: "Created"
					}),
					minScreenWidth: "Tablet",
					demandPopin: true
				}), new sap.m.Column({
					hAlign: "End",
					vAlign: sap.ui.core.VerticalAlign.Middle,
					width: "10%",
					header: new sap.m.Label({
						text: "Priority"
					}),
					minScreenWidth: "Tablet",
					demandPopin: true
				}), new sap.m.Column({
					hAlign: "End",
					vAlign: sap.ui.core.VerticalAlign.Middle,
					width: "12%",
					popinDisplay: "Inline",
					header: new sap.m.Label({
						text: "Status"
					}),
					minScreenWidth: "Tablet",
					demandPopin: true
				})]
			},
			onSortDuplicateDialogColumns: function (e) {
				var t = new sap.ui.model.Sorter(e, true);
				if (e === "created") {
					t.fnCompare = function (e, t) {
						var s = new Date(e);
						var a = new Date(t);
						if (a === null) {
							return -1
						}
						if (s === null) {
							return 1
						}
						if (s < a) {
							return -1
						}
						if (s > a) {
							return 1
						}
						return 0
					}
				}
			},
			onCreateUpdateRFSButtonPress: function (e) {
				e.ZsharedMemoryId = $.sap.sSharedMemoryId;
				if (typeof $.sap.sObjectId === "undefined" || $.sap.sObjectId === null) {
					e.ZobjectId = ""
				} else {
					e.ZobjectId = $.sap.sObjectId
				}
				if (e.ZobjectId !== "" && e.ZobjectId !== null && typeof e.ZobjectId !== "undefined") {
					sap.m.MessageToast.show("Update RFS");
					sap.ui.core.BusyIndicator.show();
					e.ZupdateMode = "Redeterm";
					if ((e.ZassetLvl2 === "" || e.ZassetLvl2 === null) && e.ZassetLvl3 !== "") {
						e.ZassetLvl2 = e.ZassetLvl3.slice(0, 10)
					}
					sap.ui.getCore().byId("ConfirmButton").setEnabled(true);
					sap.ui.getCore().byId("RefreshButton").setEnabled(true);
					var t = sap.ui.getCore().getModel();
					t.setUseBatch(false);
					t.setHeaders({
						"content-type": "application/json;charset=utf-8"
					});
					t.update("/RFSRecordSet('" + e.ZobjectId + "')", e, null, {
						method: "PUT",
						async: false,
						success: function () {
							sap.m.MessageToast.show("Update successful")
						},
						error: function () {
							sap.m.MessageToast.show("Update failed")
						}
					});
					t.attachRequestSent(function (e) {
						sap.m.MessageToast.show("Update RFS - Sent to CRM")
					});
					t.attachRequestCompleted(function (e) {
						var t = e.getParameter("url");
						if (t.includes("/RFSRecordSet") && !t.includes("$filter")) {
							var s = $.sap.sObjectId;
							if (s !== "" && typeof s !== "undefined") {
								sap.m.MessageToast.show("Update RFS - Completed: " + s);
								var a = window.top;
								a.close()
							} else {
								sap.m.MessageToast.show("No Transaction returned")
							}
						}
						sap.ui.core.BusyIndicator.hide()
					});
					t.attachRequestFailed(function (e) {
						sap.m.MessageToast.show("Update RFS - Failed");
						sap.ui.core.BusyIndicator.hide()
					})
				} else {
					if ((e.ZassetLvl2 === "" || e.ZassetLvl2 === null) && e.ZassetLvl3 !== "") {
						e.ZassetLvl2 = e.ZassetLvl3.slice(0, 10)
					}
					sap.m.MessageToast.show("Create RFS");
					sap.ui.core.BusyIndicator.show();
					var s = sap.ui.getCore().getModel();
					s.setUseBatch(false);
					s.setHeaders({
						"content-type": "application/json;charset=utf-8"
					});
					s.create("/RFSRecordSet", e, null, {
						method: "POST",
						async: false,
						success: function (e, t) {
							sap.m.MessageToast.show(" Created Successfully")
						},
						error: function (e) {
							sap.m.MessageToast.show(" Creation failed")
						}
					});
					s.attachRequestSent(function (e) {
						sap.m.MessageToast.show("Create RFS - Sent to CRM")
					});
					s.attachRequestCompleted(function (e) {
						var t = e.getParameter("response");
						var s = JSON.parse(t.responseText);
						var a = e.getParameter("url");
						if (a.includes("/RFSRecordSet") && !a.includes("$filter")) {
							var o = s.d.ZobjectId;
							if (o !== "" && typeof o !== "undefined") {
								sap.m.MessageToast.show("Create RFS - Completed: " + o);
								var r = window.top;
								r.close()
							} else {
								sap.m.MessageToast.show("No Transaction returned");
								sap.ui.core.BusyIndicator.hide()
							}
						}
					});
					s.attachRequestFailed(function (e) {
						sap.m.MessageToast.show("Create RFS - Failed");
						sap.ui.core.BusyIndicator.hide()
					})
				}
			},
			onUpdateSelectedRfsPress: function (e) {
				e.ZsharedMemoryId = $.sap.sSharedMemoryId;
				sap.ui.core.BusyIndicator.show();
				var t = sap.ui.getCore().byId("IdDuplicateTableSelect").getSelectedItem();
				var s = [];
				if (t === null || typeof t === "undefined") {
					sap.m.MessageToast.show("Please select an item for update");
					return
				} else {
					s = t.getCells()
				}
				if (s.length > 0 && s !== "undefined") {
					var a = s[0].getProperty("text");
					e.ZobjectId = a
				} else {
					sap.m.MessageToast.show("Please select an item for update");
					return
				}
				if (e.ZcustomerId === "" || e.ZcustomerID === "undefined") {
					e.ZcustomerId = jQuery.sap.getUriParameters().get("customer")
				}
				var o = sap.ui.getCore().getModel();
				o.setUseBatch(false);
				o.setHeaders({
					"content-type": "application/json;charset=utf-8"
				});
				e.ZupdateMode = "Duplicate";
				o.update("/RFSRecordSet('" + e.ZobjectId + "')", e, null, {
					method: "PUT",
					async: false,
					success: function () {
						sap.m.MessageToast.show("Update successful")
					},
					error: function () {
						sap.m.MessageToast.show("Update failed")
					}
				});
				o.attachRequestSent(function (e) {
					sap.m.MessageToast.show("Update RFS - Sent to CRM")
				});
				o.attachRequestCompleted(function (t) {
					sap.ui.core.BusyIndicator.hide();
					a = e.ZobjectId;
					if (a !== "" && a !== "undefined") {
						sap.m.MessageToast.show("Update RFS - Completed: " + a);
						var s = window.top;
						s.close()
					} else {
						sap.m.MessageToast.show("No Transaction returned")
					}
					sap.ui.core.BusyIndicator.hide()
				});
				o.attachRequestFailed(function (e) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("Update RFS - Failed");
					sap.ui.core.BusyIndicator.hide()
				})
			},
			onRFSCreateDialogMissingData: function (e, t) {
				return new Promise(function (t, s) {
					sap.m.MessageBox.confirm("Problem Group,Problem or Conditions haven't been selected for asset " + e + ". " +
						" Do you still want to proceed?", {
							icon: sap.m.MessageBox.Icon.WARNING,
							title: "Missing Data",
							actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
							onClose: function (e) {
								if (e === sap.m.MessageBox.Action.CANCEL) {
									s()
								} else if (e === sap.m.MessageBox.Action.OK) {
									t()
								} else {
									t()
								}
							}
						})
				})
			},
			getAppTitle: function (e, t) {
				if (e === null || typeof e === "undefined") {
					var s = "Confirmed Customer: No customer has been confirmed yet | "
				} else {
					var a = jQuery.sap.getUriParameters().get("account_description");
					if (a === null || typeof a === "undefined") {
						a = jQuery.sap.getUriParameters().get("ACCOUNT_DESCRIPTION")
					}
					s = "Confirmed Customer: " + a + " - " + e + " | "
				}
				if (t !== null) {
					s = s + "RFS: " + t
				} else {
					s = s + "RFS: New"
				}
				return s
			},
			getConfirmButtonText: function (e) {
				if (e !== null) {
					var t = "Update RFS"
				} else {
					t = "Create RFS"
				}
				return t
			},
			setMapUrl: function (e) {
				$.sap.sAction = "";
				$.sap.sActionprops = "";
				var s = $.sap.sAssetL2;
				if (s === "") {
					s = $.sap.sAssetL3
				}
				t.onDetermineAction($.sap.sXcoordinate, $.sap.sYcoordinate, $.sap.sAssetGISReDet, $.sap.sAction, $.sap.sActionprops);
				var a = sap.ui.getCore().getModel();
				a.setUseBatch(false);
				a.read("/AppDetailsSet", {
					filters: [new sap.ui.model.Filter({
						path: "Name",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: "ZRFS_GIS_WEB_APP_URL"
					})],
					success: function (e) {
						var t = new sap.ui.model.json.JSONModel;
						t.setData(e);
						var s = t.getProperty("/results/0");
						$.sap.sGisBaseUrl = s.Value
					},
					error: function (e) {
						var t = JSON.parse(e.responseText);
						sap.m.MessageToast.show(t.error.message.value)
					}
				});
				a.attachRequestCompleted(function (e) {
					var s = e.getParameter("url");
					if (s.includes("/AppDetailsSet")) {
						t.onDetermineAction($.sap.sXcoordinate, $.sap.sYcoordinate, $.sap.sAssetGISReDet, $.sap.sAction, $.sap.sActionprops);
						if ($.sap.sGisBaseUrl === "NO_GIS_AVAILABLE") {
							var a = sap.ui.getCore().byId("mapValue");
							a.setValue("");
							if (a.getEditable() === false) {
								a.setEditable(true)
							}
							var o = "noGISAvailable.html";
							t.onIFrameAfterRendering(o)
						} else {
							$.sap.sGisUrl = t.buildMapUrl($.sap.sGisBaseUrl, "12345", "normal", "csr", "", $.sap.sAction, $.sap.sActionprops);
							t.onIFrameAfterRendering($.sap.sGisUrl)
						}
					}
				});
				a.attachRequestFailed(function (e) {
					sap.m.MessageToast.show("Determine GIS URL failed")
				})
			}
		})
	});