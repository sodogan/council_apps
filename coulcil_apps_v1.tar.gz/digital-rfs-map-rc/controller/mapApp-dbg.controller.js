sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"ZRFSDigital/ZRFSDigital_v6/utils/mapUtilities",
	"sap/m/MessageBox",
	"sap/ui/core/Icon"
], function (Controller, mapUtilities) {
	"use strict";

	function translatePriority(sPriority) {
		switch (sPriority) {
		case "C":
			var sPrio = "1";
			break;
		case "M":
			sPrio = "2";
			break;
		case "U":
			sPrio = "3";
			break;
		case "N":
			sPrio = "5";
			break;
		}
		return sPrio;
	}
	return Controller.extend("ZRFSDigital.ZRFSDigital_v6.controller.mapApp", {
		onInit: function () {
			//CR61 - Priority editable
			var oDataPriority = {
				"SelectedPriority": "5",
				"PriorityCollection": [{
					"PriorityId": "1",
					"Name": "Critical",
					"Icon": "sap-icon://alert"
				}, {
					"PriorityId": "2",
					"Name": "Major",
					"Icon": "sap-icon://error"
				}, {
					"PriorityId": "3",
					"Name": "Urgent",
					"Icon": "sap-icon://message-error"
				}, {
					"PriorityId": "5",
					"Name": "Normal",
					"Icon": "sap-icon://message-warning"
				}]
			};

			// set explored app's demo model on this sample
			var oPriorityModel = new sap.ui.model.json.JSONModel(oDataPriority);
			var oselectPriority = sap.ui.getCore().byId("selectPriority");
			oselectPriority.setModel(oPriorityModel);
			//initialise with Normal - 5
			oselectPriority.setSelectedKey("5");

			if (this.getView().byId("iFrameContent")) {
				this.getView().byId("iFrameContent").addEventDelegate({
					"onAfterRendering": function () {
						if (window.addEventListener) {
							window.addEventListener("message", this.displayMessage.bind(this), false);
						} else {
							window.attachEvent("onmessage", this.displayMessage.bind(this));
						}
					}
				}, this);
			}
			//in case of edit/re-determination of existing RFS
			mapUtilities.readRFS($.sap.sObjectId);
		},

		bindEvent: function (element, eventName, eventHandler) {
			if (element.addEventListener) {
				element.addEventListener(eventName, eventHandler, false);
			} else if (element.attachEvent) {
				element.attachEvent("on" + eventName, eventHandler);
			}
		},
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf bars.page
		 */
		onBeforeRendering: function () {
			//onInit() caters for the initial read
			//mapUtilities.readRFS($.sap.sObjectId);
		},
		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf bars.page
		 */
		onAfterRendering: function () {
			this.bindEvent(window, "message", function (e) {});
			if (window.addEventListener) {
				window.addEventListener("message", this.displayMessage.bind(this), false);
			} else {
				window.attachEvent("onmessage", this.displayMessage.bind(this));
			}
		},
		/*
		 *consume map event from iFrame
		 */
		displayMessage: function (oEvent) {
			if (event.data) {
				var data = null;
				try {
					data = JSON.parse(event.data);
				} catch (e) {
					data = null;
				}
				if (data) {
					if (typeof data.selectedL3Asset !== "undefined") {
						//cater for panuku assets where the sapid efectively holds L3 asset
						if (typeof data.selectedL3Asset.sapid === "undefined" || data.selectedL3Asset.sapid === null) {
							var results = data.sapid;
							var resultL2 = "";
							//ALM 518
							var sResultGISReDet = data.sapid;
							var resultL3 = results;
						} else {
							results = data.selectedL3Asset.sapid;
							resultL2 = data.sapid;
							//ALM 518
							sResultGISReDet  = data.sapid;
							resultL3 = results;
						}
						//var results = data.selectedL3Asset.sapid;
						sap.m.MessageToast.show("Asset ID:".concat(results));

						var oMapValue = sap.ui.getCore().byId("mapValue");
						oMapValue.setValue(results);
						//contextual tooltip
						oMapValue.setTooltip(data.description);

						//CUSTOMDATA write additional data to control (mapValue) customdata array
						//this is preferrable to invisible controls, need to be strings
						oMapValue.data("xCoordinate", data.x.toString(), false);
						oMapValue.data("yCoordinate", data.y.toString(), false);
						oMapValue.data("addressStr", data.address, false);
						oMapValue.data("assetL2", resultL2, false);
						//ALM 518 10072-L100/L101
						oMapValue.data("assetGISReDet", sResultGISReDet, false);

						var oPGComboBox = sap.ui.getCore().byId("PGComboBox"); //this refers to view's controller
						var oProblemComboBox = sap.ui.getCore().byId("ProblemComboBox");
						var oConditionComboBox = sap.ui.getCore().byId("ConditionMComboBox");
						var oSelectPriority = sap.ui.getCore().byId("selectPriority");

						if (oPGComboBox.getEditable() === false) {
							oPGComboBox.setEditable(true);
						}
						if (oProblemComboBox.getEditable() === false) {
							oProblemComboBox.setEditable(true);
						}
						if (oConditionComboBox.getEditable() === false) {
							oConditionComboBox.setEditable(true);
						}

						sap.ui.getCore().byId("ConfirmButton").setEnabled(true);
						sap.ui.getCore().byId("RefreshButton").setEnabled(true);

						//clear problem categorisation data
						oPGComboBox.setSelectedKey("");
						oProblemComboBox.setSelectedKey("");
						oConditionComboBox.removeAllSelectedItems();
						oSelectPriority.setSelectedKey("5");

						var oDataModel = sap.ui.getCore().getModel();
						oDataModel.setUseBatch(false);

						//special logic for 99999-999 assets, NO filtering on PGs/Problems; done in OData service

						oDataModel.attachMetadataLoaded(function () {
							var oMetadata = oDataModel.getServiceMetadata();
							//jQuery.sap.require("sap.m.MessageToast");
							if (oMetadata.version !== "" && typeof oMetadata.version !== "undefined") {
								//call worked - Categorise Problem
								sap.m.MessageToast.show("Categorise Problem");
							}
						});

						oDataModel.read("/RFSProblemMatrixSet", {
							filters: [
								new sap.ui.model.Filter({
									path: "ZassetLevel2",
									operator: sap.ui.model.FilterOperator.EQ,
									value1: resultL2
								}),
								new sap.ui.model.Filter({
									path: "ZassetLevel3",
									operator: sap.ui.model.FilterOperator.EQ,
									value1: resultL3
								})
							],
							and: true,

							success: function (oData, oResponse) {

								if (typeof oData.results !== "undefined" && oData.results.length > 0) {
									// the array is defined and has at least one element
									var aPGArray = [];

									$.each(oData.results, function (i, item) {
										aPGArray.push({
											"key": item.ZproblemGrpId,
											"text": item.ZproblemGrpShDesc,
											"info": item.ZproblemGrpDesc + " (" + item.ZproblemGrpId + ")"
										});
									});
									//PROBLEM GROUP - unique groups
									// convert the array content to JSON string, then reverse it (to check from end to begining)
									aPGArray = aPGArray.map(JSON.stringify).reverse()
										.filter(function (item, index, arr) {
											return arr.indexOf(item, index + 1) === -1;
										}) // check if there is any occurence of the item in whole array
										.reverse().map(JSON.parse); // revert it to original state

									var oPGModel = new sap.ui.model.json.JSONModel(aPGArray);

									oPGComboBox.bindAggregation("items", {
										path: "/",
										template: new sap.ui.core.ListItem({
											key: "{key}",
											text: "{text}",
											tooltip: "{info}"
										})
									});
									//Give the Dropdown Box data by setting it to a Model, the Array
									oPGComboBox.setModel(oPGModel);

									//PROBLEM OData to Array
									var aProblemArray = [];
									$.each(oData.results, function (i, item) {
										if (item.ZproblemCode !== "") {
											aProblemArray.push({
												"key": item.ZproblemCode,
												"text": item.ZprbCodeShTxt,
												"info": item.ZprbCodeTxt + " (" + item.ZproblemCode + ")",
												"keyPG": item.ZproblemGrpId, //filter
												"defPrio": item.ZdefPrio
											});
										}
									});
									// Unique problems: convert the array content to JSON string, then reverse it (to check from end to begining)
									aProblemArray = aProblemArray.map(JSON.stringify).reverse()
										.filter(function (item, index, arr) {
											return arr.indexOf(item, index + 1) === -1;
										}) // check if there is any occurence of the item in whole array
										.reverse().map(JSON.parse); // revert it to original state

									var oProblemModel = new sap.ui.model.json.JSONModel(aProblemArray);
									oProblemComboBox.bindAggregation("items", {
										path: "/",
										template: new sap.ui.core.ListItem({
											key: "{key}",
											text: "{text}",
											tooltip: "{info}",
											customdata: [("keyPG", "{keyPG}"), ("defPrio", "{defPrio}")] //filter
										})
									});
									//Give the Dropdown Box data by setting it to a Model, the Array
									oProblemComboBox.setModel(oProblemModel);

									//CONDITIONS OData to Array
									var aConditionArray = [];
									$.each(oData.results, function (i, item) {
										if (item.Zconditions !== "") {
											aConditionArray.push({
												"key": item.Zconditions,
												"text": item.ZcondShText,
												//"info": item.ZcondText,
												"info": item.ZcondText + " (" + item.Zconditions + ")",
												"keyPG": item.ZproblemGrpId, //filter
												"keyP": item.ZproblemCode, //filter
												"defPrio": item.ZdefPrio,
												"condPrio": item.ZcondPrio
											});
										}
									});
									// Unique conditions: convert the array content to JSON string , then reverse it (to check from end to begining)
									aConditionArray = aConditionArray.map(JSON.stringify).reverse()
										.filter(function (item, index, arr) {
											return arr.indexOf(item, index + 1) === -1;
										}) // check if there is any occurence of the item in whole array
										.reverse().map(JSON.parse); // revert it to original state

									var oConditionModel = new sap.ui.model.json.JSONModel(aConditionArray);
									oConditionComboBox.bindAggregation("items", {
										path: "/",
										template: new sap.ui.core.ListItem({
											key: "{key}",
											text: "{text}",
											tooltip: "{info}",
											customdata: [("keyPG", "{keyPG}"), ("keyP", "{keyP}"), ("defPrio", "{defPrio}"), ("condPrio", "{condPrio}")]
										})
									});
									//Give the Dropdown Box data by setting it to a Model, the Array
									oConditionComboBox.setModel(oConditionModel);

									sap.m.MessageToast.show("Categorise Problem");
									//check data
								} else {
									//remove 'old' entries
									sap.m.MessageToast.show("No Problem Group/Problem found for Asset:".concat(results));
									oPGComboBox.setModel(new sap.ui.model.json.JSONModel({
										data: []
									}));
									oProblemComboBox.setModel(new sap.ui.model.json.JSONModel({
										data: []
									}));
									oConditionComboBox.setModel(new sap.ui.model.json.JSONModel({
										data: []
									}));
								}
							},

							error: function (oError) {
								// sap.ui.m.MessageBox.alert("Error ! OData Service !");
								var errorObject = JSON.parse(oError.responseText);
								jQuery.sap.require("sap.m.MessageToast");
								sap.m.MessageToast.show(errorObject.error.message.value);
							}

						});
					}
				}
			}
		},
		//MapValue Input Field
		onMapValueChange: function (oEvent) {
			sap.ui.getCore().byId("PGComboBox").setSelectedKey("");
			sap.ui.getCore().byId("ProblemComboBox").setSelectedKey("");
			sap.ui.getCore().byId("ConditionMComboBox").removeAllSelectedItems();

		},
		//MapValue Input Field
		onMapValueSubmit: function (oEvent) {
			//get value
			var oEnteredValue = oEvent.getParameter("value");
			sap.m.MessageToast.show(oEnteredValue);
			sap.ui.getCore().byId("PGComboBox").setSelectedKey("");
			sap.ui.getCore().byId("ProblemComboBox").setSelectedKey("");
			sap.ui.getCore().byId("ConditionMComboBox").removeAllSelectedItems();
			$.sap.problemMatrixRead = false;
			if ($.sap.problemMatrixRead !== true && oEnteredValue !== null && typeof oEnteredValue !== "undefined") {
				mapUtilities.readProblemMatrix(oEnteredValue);
			}
		},
		//Problem Group combobox events
		onProblemGroupSelectionChange: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			sap.m.MessageToast.show(oSelectedItem.getText());
			var oProblemComboBox = sap.ui.getCore().byId("ProblemComboBox");
			var ofilter = oEvent.getParameter("selectedItem").getKey();
			var oBindingProblemComboBox = oProblemComboBox.getBinding("items");
			var aFiltersProblemComboBox = [];
			var oFilterProblemComboBox = new sap.ui.model.Filter("keyPG", sap.ui.model.FilterOperator.EQ, ofilter);
			aFiltersProblemComboBox.push(oFilterProblemComboBox);
			oBindingProblemComboBox.filter(aFiltersProblemComboBox);
		},
		onProblemGroupBeforeRendering: function () {
			var oSelectedPGKey = sap.ui.getCore().byId("PGComboBox").getSelectedKey();
			var oProblemComboBox = sap.ui.getCore().byId("ProblemComboBox");
			var ofilter = oSelectedPGKey;
			var oBindingProblemComboBox = oProblemComboBox.getBinding("items");
			var aFiltersProblemComboBox = [];
			var oFilterProblemComboBox = new sap.ui.model.Filter("keyPG", sap.ui.model.FilterOperator.EQ, ofilter);
			aFiltersProblemComboBox.push(oFilterProblemComboBox);
			oBindingProblemComboBox.filter(aFiltersProblemComboBox);
		},
		onProblemGroupChange: function (oEvent) {
			var oPGComboBox = sap.ui.getCore().byId("PGComboBox");
			oPGComboBox.setTooltip(oEvent.getParameter("value") + " (" + oPGComboBox.getSelectedKey() + ")");
		},
		//Problem combobox events
		onProblemChange: function (oEvent) {
			var oProblemComboBox = sap.ui.getCore().byId("ProblemComboBox");
			oProblemComboBox.setTooltip(oEvent.getParameter("value") + " (" + oProblemComboBox.getSelectedKey() + ")");
		},
		onProblemSelectionChange: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			sap.m.MessageToast.show(oSelectedItem.getText());
			var oConditionComboBox = sap.ui.getCore().byId("ConditionMComboBox");
			var ofilter = oEvent.getParameter("selectedItem").getKey();
			var oBindingConditionComboBox = oConditionComboBox.getBinding("items");
			var aFiltersConditionComboBox = [];
			var oFilterConditionComboBox = new sap.ui.model.Filter("keyP", sap.ui.model.FilterOperator.EQ, ofilter);
			aFiltersConditionComboBox.push(oFilterConditionComboBox);
			oBindingConditionComboBox.filter(aFiltersConditionComboBox);
			//default priority per problem
			var oBindingProblemComboBox = sap.ui.getCore().byId("ProblemComboBox").getBinding("items");
			//priority 1,2,3,5 ,codPrio,defPrio N,C,M,U | arrow function needs es6=true in project setting
			//arrow function is not supported in IE11
			//var aResult = oBindingProblemComboBox.oList.find(({ key }) => key === ofilter);
			var aResult = [];
			aResult = oBindingProblemComboBox.oList.filter(function (problemMatrix) {
				return problemMatrix.key === ofilter;
			});

			//include special case problem SOME which might not have a defPrio (check defPrio is not empty string)
			if (aResult[0].defPrio !== "undefined" && aResult[0].defPrio !== null && aResult[0].defPrio !== "") {
				var sDefPriority = translatePriority(aResult[0].defPrio);
			} else {
				sDefPriority = "5";
			}
			sap.ui.getCore().byId("selectPriority").setSelectedKey(sDefPriority);
		},
		onConditionsSelectionChange: function (oEvent) {
			var oChangedItem = oEvent.getParameter("changedItem");
			var bCurrentItemIsSelected = oEvent.getParameter("selected");
			var oBindingConditionComboBox = sap.ui.getCore().byId("ConditionMComboBox").getBinding("items");
			//custom data (condPrio, defPrio) is not present in oChangedItem => read from collection of items
			//var aResult = oBindingConditionComboBox.oList.find(({ key }) => key === oChangedItem.getKey());
			var aResult = [];
			aResult = oBindingConditionComboBox.oList.filter(function (problemMatrix) {
				return problemMatrix.key === oChangedItem.getKey();
			});

			//condition priority found and selected => potentially change priority
			if (aResult[0].condPrio !== "undefined" && aResult[0].condPrio !== null) {
				var sCondPriority = translatePriority(aResult[0].condPrio);
			}
			//evaluate highest priority (lowest number!!) of selected conditions; normal < critical (5 > 1)
			if (bCurrentItemIsSelected === true && sCondPriority !== null && (parseInt(sap.ui.getCore().byId("selectPriority").getSelectedKey(),
						10) >
					parseInt(sCondPriority, 10))) {
				sap.ui.getCore().byId("selectPriority").setSelectedKey(sCondPriority);
			}
		},
		onConditionsSelectionFinish: function (oEvent) {
			var oBindingConditionComboBox = sap.ui.getCore().byId("ConditionMComboBox").getBinding("items");
			var aSelectedCondKeysAll = sap.ui.getCore().byId("ConditionMComboBox").getSelectedKeys();
			//initial value
			var sDeterminedPriority = "5";
			//Precaution - remove value(s) = "" from array
			var aSelectedCondKeys = aSelectedCondKeysAll.filter(function (value, index, arr) {
				return value !== "";
			});
			if (aSelectedCondKeys !== "undefined" && aSelectedCondKeys !== null && aSelectedCondKeys.length !== 0) {
				//check if priority has to change
				var fnCurrentPriority = function fEvaluatePriority(value, index, array) {
					//var aResult = oBindingConditionComboBox.oList.find(({ key }) => key === value);
					var aResult = [];
					aResult = oBindingConditionComboBox.oList.filter(function (problemMatrix) {
						return problemMatrix.key === value;
					});

					if (aResult[0].condPrio !== "undefined" && aResult[0].condPrio !== null) {
						var sCondPriority = translatePriority(aResult[0].condPrio);
					}
					//evaluate highest priority (lowest number!!) of selected conditions; normal < critical (5 > 1)
					if (sCondPriority !== null && (parseInt(sDeterminedPriority, 10) >= parseInt(sCondPriority, 10))) {
						sDeterminedPriority = sCondPriority;
					}
				};
				//check if priority has to change
				aSelectedCondKeys.forEach(fnCurrentPriority);
			} else {
				//problem related default priority
				var sSelectedProblemKey = sap.ui.getCore().byId("ProblemComboBox").getSelectedKey();
				var oBindingProblemComboBox = sap.ui.getCore().byId("ProblemComboBox").getBinding("items");
				//priority 1,2,3,5 ,codPrio,defPrio N,C,M,U
				//var aResult = oBindingProblemComboBox.oList.find(({ key	}) => key === sSelectedProblemKey);
				var aResult = [];
				aResult = oBindingProblemComboBox.oList.filter(function (problemMatrix) {
					return problemMatrix.key === sSelectedProblemKey;
				});

				if (aResult[0].defPrio !== "undefined" && aResult[0].defPrio !== null) {
					var sDefPriority = translatePriority(aResult[0].defPrio);
				} else {
					sDefPriority = "5";
				}
				sDeterminedPriority = sDefPriority;
			}
			//set the value
			sap.ui.getCore().byId("selectPriority").setSelectedKey(sDeterminedPriority);
		},
		//Refresh Button
		onRefreshButtonPress: function (oEvent) {
			mapUtilities.refreshApp();
		},
		//Duplicate heck table
		onCreateDuplicateDialogColumns: function () {
			return [
				new sap.m.Column({
					hAlign: "Begin",
					vAlign: sap.ui.core.VerticalAlign.Middle,
					width: "13%",
					header: new sap.m.Label({
						text: "Object ID"
					})
				}),
				new sap.m.Column({
					hAlign: "Center",
					vAlign: sap.ui.core.VerticalAlign.Middle,
					width: "45%",
					popinDisplay: "Inline",
					header: new sap.m.Label({
						text: "Description"
					}),
					minScreenWidth: "Medium",
					demandPopin: true
				}),
				new sap.m.Column({
					hAlign: "Begin",
					vAlign: sap.ui.core.VerticalAlign.Middle,
					width: "20%",
					header: new sap.m.Label({
						text: "Created"
					}),
					minScreenWidth: "Tablet",
					demandPopin: true
				}),
				new sap.m.Column({
					hAlign: "End",
					vAlign: sap.ui.core.VerticalAlign.Middle,
					width: "10%",
					header: new sap.m.Label({
						text: "Priority"
					}),
					minScreenWidth: "Tablet",
					demandPopin: true
				}),
				new sap.m.Column({
					hAlign: "End",
					vAlign: sap.ui.core.VerticalAlign.Middle,
					width: "12%",
					popinDisplay: "Inline",
					header: new sap.m.Label({
						text: "Status"
					}),
					minScreenWidth: "Tablet",
					demandPopin: true
				})
			];
		},
		onSortDuplicateDialogColumns: function (sPath) {
			var oSorter = new sap.ui.model.Sorter(sPath, true);
			// override compare function only for posting dates

			if (sPath === "created") {
				oSorter.fnCompare = function (a, b) {

					// parse to Date object
					var aDate = new Date(a);
					var bDate = new Date(b);

					if (bDate === null) {
						return -1;
					}
					if (aDate === null) {
						return 1;
					}
					if (aDate < bDate) {
						return -1;
					}
					if (aDate > bDate) {
						return 1;
					}
					return 0;
				};
			}
			//return oSorter;
		},
		//CreateRFS in Duplicate
		onCreateUpdateRFSButtonPress: function (oRFSEntry) {
			//connection UI5 -> Web UI through shared memory id-> timestamp + user id
			oRFSEntry.ZsharedMemoryId = $.sap.sSharedMemoryId;

			if (typeof $.sap.sObjectId === "undefined" || $.sap.sObjectId === null) {
				oRFSEntry.ZobjectId = "";
			} else {
				oRFSEntry.ZobjectId = $.sap.sObjectId;
			}
			//should check update mode
			if (oRFSEntry.ZobjectId !== "" && oRFSEntry.ZobjectId !== null && typeof oRFSEntry.ZobjectId !== "undefined") {
				sap.m.MessageToast.show("Update RFS");
				sap.ui.core.BusyIndicator.show();
				//set update mode
				oRFSEntry.ZupdateMode = "Redeterm";

				if ((oRFSEntry.ZassetLvl2 === "" || oRFSEntry.ZassetLvl2 === null) && oRFSEntry.ZassetLvl3 !== "") {
					oRFSEntry.ZassetLvl2 = oRFSEntry.ZassetLvl3.slice(0, 10);
				}
				//make update button and refresh button available by default
				sap.ui.getCore().byId("ConfirmButton").setEnabled(true);
				sap.ui.getCore().byId("RefreshButton").setEnabled(true);

				var oRFSUpdateModel = sap.ui.getCore().getModel();
				oRFSUpdateModel.setUseBatch(false);
				oRFSUpdateModel.setHeaders({
					"content-type": "application/json;charset=utf-8"
				});
				oRFSUpdateModel.update("/RFSRecordSet('" + oRFSEntry.ZobjectId + "')", oRFSEntry, null, {
					method: "PUT",
					async: false,
					success: function () {
						sap.m.MessageToast.show("Update successful");
					},
					error: function () {
						sap.m.MessageToast.show("Update failed");
					}
				});
				//model event for testing
				oRFSUpdateModel.attachRequestSent(function (oEvent) {
					sap.m.MessageToast.show("Update RFS - Sent to CRM");
				});
				//don't show new window as RFS is already IC main object
				oRFSUpdateModel.attachRequestCompleted(function (oRFSUpdateEvent) {
					var oEventParameter = oRFSUpdateEvent.getParameter("url");
					if (oEventParameter.includes("/RFSRecordSet") && !oEventParameter.includes("$filter")) {
						var sObjectId = $.sap.sObjectId;
						if (sObjectId !== "" && typeof sObjectId !== "undefined") {
							sap.m.MessageToast.show("Update RFS - Completed: " + sObjectId);
							var topwindow = window.top;
							topwindow.close();
							//this needs to take care of cross origin etc parent: CRM; child GW
							//parent.window.self.unloadPage();
							//window.close();
						} else {
							sap.m.MessageToast.show("No Transaction returned");
						}
					}
					sap.ui.core.BusyIndicator.hide();
				});
				oRFSUpdateModel.attachRequestFailed(function (oEvent) {
					sap.m.MessageToast.show("Update RFS - Failed");
					sap.ui.core.BusyIndicator.hide();
				});

			} else {
				//provide L2 as well for creation call
				if ((oRFSEntry.ZassetLvl2 === "" || oRFSEntry.ZassetLvl2 === null) && oRFSEntry.ZassetLvl3 !== "") {
					oRFSEntry.ZassetLvl2 = oRFSEntry.ZassetLvl3.slice(0, 10);
				}
				sap.m.MessageToast.show("Create RFS");
				sap.ui.core.BusyIndicator.show();
				//new create
				var oRFSDataCreateModel = sap.ui.getCore().getModel();
				oRFSDataCreateModel.setUseBatch(false);
				oRFSDataCreateModel.setHeaders({
					"content-type": "application/json;charset=utf-8"
				});
				oRFSDataCreateModel.create("/RFSRecordSet", oRFSEntry, null, {
					method: "POST",
					async: false,
					success: function (oData, oResponse) {
						// Success
						sap.m.MessageToast.show(" Created Successfully");
					},
					error: function (oError) {
						// Error
						sap.m.MessageToast.show(" Creation failed");
					}
				});
				//model event for testing
				oRFSDataCreateModel.attachRequestSent(function (oRFSCreateEvent) {
					sap.m.MessageToast.show("Create RFS - Sent to CRM");
				});

				oRFSDataCreateModel.attachRequestCompleted(function (oRFSCreateEvent) {
					//checking for duplicates we need to ensure it's the correct request which has been completed
					var oResponse = oRFSCreateEvent.getParameter("response");
					var oParsedResult = JSON.parse(oResponse.responseText);
					var oEventParameter = oRFSCreateEvent.getParameter("url");
					//creation NOT duplicate->!$filter
					if (oEventParameter.includes("/RFSRecordSet") && !oEventParameter.includes("$filter")) {
						var sObjectId = oParsedResult.d.ZobjectId;
						if (sObjectId !== "" && typeof sObjectId !== "undefined") {
							sap.m.MessageToast.show("Create RFS - Completed: " + sObjectId);
							//this needs to take care of cross origin etc parent: CRM; child GW
							var topwindow = window.top;
							topwindow.close();
						} else {
							sap.m.MessageToast.show("No Transaction returned");
							sap.ui.core.BusyIndicator.hide();
						}
					}
				});
				oRFSDataCreateModel.attachRequestFailed(function (oEvent) {
					sap.m.MessageToast.show("Create RFS - Failed");
					sap.ui.core.BusyIndicator.hide();
				});
			}
		},
		//Update selected RFS in Duplicate table (This is still create)
		onUpdateSelectedRfsPress: function (oRFSEntry) {
			//connection UI5 -> Web UI through shared memory id-> timestamp + user id
			oRFSEntry.ZsharedMemoryId = $.sap.sSharedMemoryId;
			//get RFS object ID
			sap.ui.core.BusyIndicator.show();
			var oDuplicateItemSelect = sap.ui.getCore().byId("IdDuplicateTableSelect").getSelectedItem();
			//object id is first column
			var arrObjectId = [];
			if (oDuplicateItemSelect === null || typeof oDuplicateItemSelect === "undefined") {
				sap.m.MessageToast.show("Please select an item for update");
				return;
			} else {
				arrObjectId = oDuplicateItemSelect.getCells();
			}
			if (arrObjectId.length > 0 && arrObjectId !== "undefined") {
				var sObjectId = arrObjectId[0].getProperty("text");
				oRFSEntry.ZobjectId = sObjectId;
			} else {
				sap.m.MessageToast.show("Please select an item for update");
				return;
			}
			if (oRFSEntry.ZcustomerId === "" || oRFSEntry.ZcustomerID === "undefined") {
				oRFSEntry.ZcustomerId = jQuery.sap.getUriParameters().get("customer");
			}

			var oRFSDataUpdateModel = sap.ui.getCore().getModel();
			oRFSDataUpdateModel.setUseBatch(false);
			oRFSDataUpdateModel.setHeaders({
				"content-type": "application/json;charset=utf-8"
			});
			//only 1 key no name needed (CHECK - currently ZobjectId, ZassetLvl3)
			//Update mode
			oRFSEntry.ZupdateMode = "Duplicate";

			oRFSDataUpdateModel.update("/RFSRecordSet('" + oRFSEntry.ZobjectId + "')", oRFSEntry, null, {
				method: "PUT",
				async: false,
				success: function () {
					sap.m.MessageToast.show("Update successful");
				},
				error: function () {
					sap.m.MessageToast.show("Update failed");
				}
			});
			//model event for testing
			oRFSDataUpdateModel.attachRequestSent(function (oEvent) {
				sap.m.MessageToast.show("Update RFS - Sent to CRM");
			});

			oRFSDataUpdateModel.attachRequestCompleted(function (oEvent) {
				sap.ui.core.BusyIndicator.hide();
				sObjectId = oRFSEntry.ZobjectId;
				if (sObjectId !== "" && sObjectId !== "undefined") {
					sap.m.MessageToast.show("Update RFS - Completed: " + sObjectId);
					//this needs to take care of cross origin etc parent: CRM; child GW
					var topwindow = window.top;
					topwindow.close();
				} else {
					sap.m.MessageToast.show("No Transaction returned");
				}
				sap.ui.core.BusyIndicator.hide();
			});

			oRFSDataUpdateModel.attachRequestFailed(function (oEvent) {
				sap.ui.core.BusyIndicator.hide();
				sap.m.MessageToast.show("Update RFS - Failed");
				sap.ui.core.BusyIndicator.hide();
			});
		},
		//Dialog for creating rfs without PG/P/Cs
		onRFSCreateDialogMissingData: function (assetL3, problemGroupCount) {
			// if (problemGroupCount > 0) {
			// 	var sProblemGroupCount = problemGroupCount;
			// } else {
			// 	sProblemGroupCount = "No";
			// }
			return new Promise(function (resolve, reject) {
				sap.m.MessageBox.confirm(
					"Problem Group,Problem or Conditions haven't been selected for asset " + assetL3 + ". " +
					//+ sProblemGroupCount + " Problem Groups have been found." + 
					" Do you still want to proceed?", {
						icon: sap.m.MessageBox.Icon.WARNING,
						title: "Missing Data",
						actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
						onClose: function (oAction) {
							if (oAction === sap.m.MessageBox.Action.CANCEL) {
								reject(); // return
							} else if (oAction === sap.m.MessageBox.Action.OK) {
								resolve(); // continue
							} else {
								resolve(); // continue
							}
						}
					});
			});
		},
		//get title and include customer and RFS information
		getAppTitle: function (sCustomer, sObjectId) {
			if (sCustomer === null || typeof sCustomer === "undefined") {
				var sAppTitle = "Confirmed Customer: No customer has been confirmed yet | ";
			} else {
				var sAccountDescription = jQuery.sap.getUriParameters().get("account_description");
				if (sAccountDescription === null || typeof sAccountDescription === "undefined") {
					sAccountDescription = jQuery.sap.getUriParameters().get("ACCOUNT_DESCRIPTION");
				}
				sAppTitle = "Confirmed Customer: " + sAccountDescription + " - " + sCustomer + " | ";
			}
			if (sObjectId !== null) {
				sAppTitle = sAppTitle + "RFS: " + sObjectId;
			} else {
				sAppTitle = sAppTitle + "RFS: New";
			}
			return sAppTitle;
		},
		//get text for Create/Update
		getConfirmButtonText: function (sObjectId) {
			if (sObjectId !== null) {
				var sText = "Update RFS";
			} else {
				sText = "Create RFS";
			}
			return sText;
		},
		//generate GIS url
		setMapUrl: function (sGisBaseUrl) {
			$.sap.sAction = "";
			$.sap.sActionprops = "";
			//Panuku logic
			var sAsset = $.sap.sAssetL2;
			if (sAsset === "") {
				sAsset = $.sap.sAssetL3;
			}
			//mapUtilities.onDetermineAction($.sap.sXcoordinate, $.sap.sYcoordinate, sAsset, $.sap.sAction, $.sap.sActionprops);
			mapUtilities.onDetermineAction($.sap.sXcoordinate, $.sap.sYcoordinate, $.sap.sAssetGISReDet, $.sap.sAction, $.sap.sActionprops);

			var oAppDetailsModel = sap.ui.getCore().getModel();
			oAppDetailsModel.setUseBatch(false);
			oAppDetailsModel.read("/AppDetailsSet", {
				filters: [
					new sap.ui.model.Filter({
						path: "Name",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: "ZRFS_GIS_WEB_APP_URL"
					})
				],
				success: function (data) {
					var oJsonModel = new sap.ui.model.json.JSONModel();
					oJsonModel.setData(data);
					var appDetails = oJsonModel.getProperty("/results/0");
					$.sap.sGisBaseUrl = appDetails.Value;
				},
				error: function (oError) {
					var errorObject = JSON.parse(oError.responseText);
					sap.m.MessageToast.show(errorObject.error.message.value);
				}
			});

			oAppDetailsModel.attachRequestCompleted(function (oEvent) {

				var oEventParameter = oEvent.getParameter("url"); //&& oEventParameter.includes("/AppDetailsSet")
				if (oEventParameter.includes("/AppDetailsSet")) {
					//check for switch value in global parameters as well
					//mapUtilities.onDetermineAction($.sap.sXcoordinate, $.sap.sYcoordinate, $.sap.sAssetL2, $.sap.sAction, $.sap.sActionprops);
					mapUtilities.onDetermineAction($.sap.sXcoordinate, $.sap.sYcoordinate, $.sap.sAssetGISReDet, $.sap.sAction, $.sap.sActionprops);
					//$.sap.sGisBaseUrl = "NO_GIS_AVAILABLE";
					if ($.sap.sGisBaseUrl === "NO_GIS_AVAILABLE") {
						//make asset editable and do NOT load map url
						var oMapValue = sap.ui.getCore().byId("mapValue");
						oMapValue.setValue("");
						if (oMapValue.getEditable() === false) {
							oMapValue.setEditable(true);
						}
						//make problem framework available
						var sNoGISAvailableURL = "noGISAvailable.html";
						mapUtilities.onIFrameAfterRendering(sNoGISAvailableURL);
					} else {
						$.sap.sGisUrl = mapUtilities.buildMapUrl($.sap.sGisBaseUrl, "12345", "normal", "csr", "", $.sap.sAction, $.sap.sActionprops);
						//change is in comparison to create/existing RFS
						mapUtilities.onIFrameAfterRendering($.sap.sGisUrl);
					}
				}
			});
			oAppDetailsModel.attachRequestFailed(function (oEvent) {
				sap.m.MessageToast.show("Determine GIS URL failed");
			});
		}
	});
});