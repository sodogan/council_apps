sap.ui.define([], function () {
	"use strict";

	function updateRFSDataToApp(oRFSData) {
		if (($.sap.sAssetL3 === "" || typeof $.sap.sAssetL3 === "undefined" || $.sap.sAssetL3 === null) && typeof $.sap.oResultData !==
			"undefined") {
			$.sap.sAssetL3 = oRFSData.ZassetLvl3;
		}
		if (($.sap.sAssetL2 === "" || typeof $.sap.sAssetL2 === "undefined" || $.sap.sAssetL2 === null) && typeof $.sap.oResultData !==
			"undefined") {
			$.sap.sAssetL2 = oRFSData.ZassetLvl2;
		}
		if (($.sap.sAssetGISReDet === "" || typeof $.sap.sAssetGISReDet === "undefined" || $.sap.sAssetGISReDet === null) && typeof $.sap.oResultData !==
			"undefined") {
			$.sap.sAssetGISReDet = oRFSData.ZassetGISReDet;
			sap.ui.getCore().byId("mapValue").data("assetGISReDet", $.sap.sAssetGISReDet, true);
		} else {
			sap.ui.getCore().byId("mapValue").data("assetGISReDet", $.sap.sAssetGISReDet, true);
		}
		if ($.sap.sProblemGroup === "" || typeof $.sap.sProblemGroup === "undefined" || $.sap.sProblemGroup === null) {
			$.sap.sProblemGroup = oRFSData.ZprobGrp;
		}
		// ZprobCod
		if ($.sap.sProblem === "" || typeof $.sap.sProblem === "undefined" || $.sap.sProblem === null) {
			$.sap.sProblem = oRFSData.ZprobCod;
		}
		if ($.sap.sConditions === "" || typeof $.sap.sConditions === "undefined" || $.sap.sConditions === null) {
			$.sap.sConditions = oRFSData.ZProbCondStr;
		}
		//CR61 - editable priority
		if ($.sap.sPriority === "" || typeof $.sap.sPriority === "undefined" || $.sap.sPriority === null) {
			$.sap.sPriority = oRFSData.Zpriority;
		}
		if (($.sap.sXcoordinate === "" || typeof $.sap.sXcoordinate === "undefined" || $.sap.sXcoordinate === null) &&
			(oRFSData.x_coordinate !== "undefined" && oRFSData.x_coordinate !== null)) {
			$.sap.sXcoordinate = oRFSData.x_coordinate;
			sap.ui.getCore().byId("mapValue").data("xCoordinate", $.sap.sXcoordinate, true);
		} else {
			sap.ui.getCore().byId("mapValue").data("xCoordinate", $.sap.sXcoordinate, true);
		}
		if (($.sap.sYcoordinate === "" || typeof $.sap.sYcoordinate === "undefined" || $.sap.sYcoordinate === null) &&
			(oRFSData.y_coordinate !== "undefined" && oRFSData.y_coordinate !== null)) {
			$.sap.sYcoordinate = oRFSData.y_coordinate;
			sap.ui.getCore().byId("mapValue").data("yCoordinate", $.sap.sYcoordinate, true);
		} else {
			sap.ui.getCore().byId("mapValue").data("yCoordinate", $.sap.sYcoordinate, true);
		}
		//check customer  - when no confirmed customer in IC we need to transfer the exitsing one to not delete
		if (($.sap.sCustomer === "" || typeof $.sap.sCustomer === "undefined" || $.sap.sCustomer === null) &&
			($.sap.oResultData !== "undefined")) {
			$.sap.sCustomer = oRFSData.ZcustomerId;
		}
		//check contact  - when no confirmed contact in IC we need to transfer the exitsing one to not delete
		if (($.sap.sContact === "" || typeof $.sap.sContact === "undefined" || $.sap.sContact === null) &&
			($.sap.oResultData !== "undefined")) {
			$.sap.sContact = oRFSData.ZcontactId;
		}
	}

	function translatePriority(sPriority) {
		switch (sPriority) {
		case "C":
			var sPrio = "1";
			break;
		case "M":
			sPrio = "2";
			break;
		case "U":
			sPrio = "3";
			break;
		case "N":
			sPrio = "5";
			break;
		}
		return sPrio;
	}
	return {
		onDetermineAction: function (sXcoordinate, sYcoordinate, sAssetGIS, sAction, sActionprops) {
			//build GIS url for asset level 2 => sapid=assetGIS

			if ((sXcoordinate !== "" && sXcoordinate !== "undefined" && sXcoordinate !== null && sYcoordinate !== "" && sYcoordinate !==
					"undefined" && sYcoordinate !== null) && (sAssetGIS === null || typeof sAssetGIS === "undefined")) {
				//add action=zoomandcenterat&actionprops=1761490.6225479892:5913347.562423935:14
				$.sap.sAction = "zoomandcenterat";
				//var coordinateY = $("#coordinateY").val();
				var coordinateX = sXcoordinate;
				var coordinateY = sYcoordinate;
				var zoomLevel = 14;
				$.sap.sActionprops = coordinateX + ":" + coordinateY + ":" + zoomLevel;
			}
			if ((sXcoordinate !== "" && sXcoordinate !== "undefined" && sXcoordinate !== null && sYcoordinate !== "" && sYcoordinate !==
					"undefined" && sYcoordinate !== null) && (sAssetGIS !== null && typeof sAssetGIS !== "undefined")) {
				//add action=redetermination&actionprops=sapid:x:y:zoom 
				$.sap.sAction = "redetermination";
				//var assetL2 = sAssetL2.slice(0, 10);
				coordinateX = sXcoordinate;
				coordinateY = sYcoordinate;
				zoomLevel = 14;
				$.sap.sActionprops = sAssetGIS + ":" + coordinateX + ":" + coordinateY + ":" + zoomLevel;
			}
			return $.sap.sActionprops;
		},
		onIFrameAfterRendering: function (gisUrl) {
			if (gisUrl === "" || gisUrl === "undefined") {
				sap.ui.core.BusyIndicator.show();

				var oAppDetailsModel = sap.ui.getCore().getModel();
				oAppDetailsModel.setUseBatch(false);
				//get base url
				oAppDetailsModel.read("/AppDetailsSet", {
					filters: [
						new sap.ui.model.Filter({
							path: "Name",
							operator: sap.ui.model.FilterOperator.EQ,
							value1: "ZRFS_GIS_WEB_APP_URL"
						})
					],
					success: function (data) {
						var oJsonModel = new sap.ui.model.json.JSONModel();
						oJsonModel.setData(data);
						var appDetails = oJsonModel.getProperty("/results/0");
						var appValue = appDetails.Value;
						//build url here
						jQuery("#iFrameMap").attr("src", appValue);

					},
					error: function (oError) {
						var errorObject = JSON.parse(oError.responseText);
						jQuery.sap.require("sap.m.MessageToast");
						sap.m.MessageToast.show(errorObject.error.message.value);
					}
				});
			} else {
				jQuery("#iFrameMap").attr("src", gisUrl);
			}
			sap.ui.core.BusyIndicator.hide();
		},
		buildMapUrl: function (gisUrlBase, refid, layout, mode, sapid, action, actionprops) {

			if (gisUrlBase === "" || gisUrlBase === "undefined" || gisUrlBase === null) {
				sap.ui.core.BusyIndicator.show();
				var oAppDetailsModel = sap.ui.getCore().getModel();

				oAppDetailsModel.setUseBatch(false);
				//get base url
				oAppDetailsModel.read("/AppDetailsSet", {
					filters: [
						new sap.ui.model.Filter({
							path: "Name",
							operator: sap.ui.model.FilterOperator.EQ,
							value1: "ZRFS_GIS_WEB_APP_URL"
						})
					],
					success: function (data) {
						var oJsonModel = new sap.ui.model.json.JSONModel();
						oJsonModel.setData(data);
						var appDetails = oJsonModel.getProperty("/results/0");
						$.sap.sGisBaseUrl = appDetails.Value;
					},
					error: function (oError) {
						var errorObject = JSON.parse(oError.responseText);
						sap.m.MessageToast.show(errorObject.error.message.value);
					}
				});
			} else {
				//build urlwith parameters
				var url = $.sap.sGisBaseUrl;

				url += "&refid=" + refid;
				//workaround layout and mode might already be in base url
				if (url.search("&layout=") === -1) {
					url += "&layout=" + layout;
				}
				if (url.search("&mode=") === -1) {
					url += "&mode=" + mode;
				}
				url += "&action=" + action;
				url += "&actionprops=" + actionprops;
				return url;
			}
			oAppDetailsModel.attachRequestCompleted(function (oEvent) {
				//build GIS url
				url = $.sap.sGisBaseUrl;

				url += "&refid=" + refid;
				//workaround layout and mode might already be in base url
				if (url.search("&layout=") === -1) {
					url += "&layout=" + layout;
				}
				if (url.search("&mode=") === -1) {
					url += "&mode=" + mode;
				}
				url += "&action=" + action;
				url += "&actionprops=" + actionprops;
			});
			return url;
		},

		//Duplicate Check table
		onCreateDuplicateDialogColumns: function () {
			return [
				new sap.m.Column({
					hAlign: "Begin",
					vAlign: sap.ui.core.VerticalAlign.Middle,
					width: "13%",
					header: new sap.m.Label({
						text: "Object ID"
					})
				}),
				new sap.m.Column({
					hAlign: "Center",
					vAlign: sap.ui.core.VerticalAlign.Middle,
					width: "45%",
					popinDisplay: "Inline",
					header: new sap.m.Label({
						text: "Description"
					}),
					minScreenWidth: "Medium",
					demandPopin: true
				}),
				new sap.m.Column({
					hAlign: "Begin",
					vAlign: sap.ui.core.VerticalAlign.Middle,
					width: "20%",
					header: new sap.m.Label({
						text: "Created"
					}),
					minScreenWidth: "Tablet",
					demandPopin: true
				}),
				new sap.m.Column({
					hAlign: "End",
					vAlign: sap.ui.core.VerticalAlign.Middle,
					width: "10%",
					header: new sap.m.Label({
						text: "Priority"
					}),
					minScreenWidth: "Tablet",
					demandPopin: true
				}),
				new sap.m.Column({
					hAlign: "End",
					vAlign: sap.ui.core.VerticalAlign.Middle,
					width: "12%",
					popinDisplay: "Inline",
					header: new sap.m.Label({
						text: "Status"
					}),
					minScreenWidth: "Tablet",
					demandPopin: true
				})
			];
		},
		//Refresh Button
		refreshApp: function () {
			sap.ui.getCore().byId("mapValue").setValue("");
			sap.ui.getCore().byId("PGComboBox").setSelectedKey("");
			sap.ui.getCore().byId("ProblemComboBox").setSelectedKey("");
			sap.ui.getCore().byId("ConditionMComboBox").removeAllSelectedItems();
			//CR61 - priority editable - default normal (5)
			sap.ui.getCore().byId("selectPriority").setSelectedKey("5");

			sap.ui.getCore().byId("PGComboBox").setModel(new sap.ui.model.json.JSONModel({
				data: []
			}));
			sap.ui.getCore().byId("ProblemComboBox").setModel(new sap.ui.model.json.JSONModel({
				data: []
			}));
			sap.ui.getCore().byId("ConditionMComboBox").setModel(new sap.ui.model.json.JSONModel({
				data: []
			}));
		},
		readRFS: function (sObjectId) {
			//get GW url parameters for selected PG,P,Cs and transaction/asstetL3/xy to pass to GIS map url
			//and to poulate PG, P, Cs and asset in UI5 app
			if (sObjectId === null || typeof sObjectId === "undefined") {
				$.sap.sObjectId = jQuery.sap.getUriParameters().get("objectid");
				if ($.sap.sObjectId === null || typeof $.sap.sObjectId === "undefined") {
					$.sap.sObjectId = jQuery.sap.getUriParameters().get("OBJECTID");
				}
			}
			//read once
			var serviceUrl = "/sap/opu/odata/sap/ZGW_RFS_SERVICESV2_SRV/";
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(serviceUrl);

			if ($.sap.sObjectId !== "" && $.sap.sObjectId !== null && $.sap.sObjectId !== "undefined" && $.sap.rfsRead !== true) {
				//read DB for RFS record
				//var oDataModel = sap.ui.getCore().getModel();

				oDataModel.setUseBatch(false);
				oDataModel.read("/RFSRecordSet('" + $.sap.sObjectId + "')", {
					async: false,
					success: function (oData, oResponse) {
						$.sap.oResultData = oResponse.data;
					}
				});

				oDataModel.attachRequestCompleted(function (oRequestCompletedEvent) {
					//need to check if response is to /RFSRecordSet via url
					var oEventParameter = oRequestCompletedEvent.getParameter("url");
					if ($.sap.rfsRead !== true && oEventParameter.includes("/RFSRecordSet")) {
						//Redetermination - enable update button by default
						sap.ui.getCore().byId("ConfirmButton").setEnabled(true);
						sap.ui.getCore().byId("RefreshButton").setEnabled(true);
						//update App data
						updateRFSDataToApp($.sap.oResultData);

						//update the controls
						var oMapValue = sap.ui.getCore().byId("mapValue");
						var oPGComboBox = sap.ui.getCore().byId("PGComboBox");
						var oProblemComboBox = sap.ui.getCore().byId("ProblemComboBox");
						//oProblemComboBox.fireSelectionChange();
						var oConditionComboBox = sap.ui.getCore().byId("ConditionMComboBox");
						//CR61 - priority editable - default normal (5)
						var oSelectPriority = sap.ui.getCore().byId("selectPriority");

						oMapValue.setValue($.sap.sAssetL3);
						oPGComboBox.setEditable(true);
						oPGComboBox.setSelectedKey($.sap.sProblemGroup);

						oProblemComboBox.setEditable(true);
						oProblemComboBox.setSelectedKey($.sap.sProblem);

						oConditionComboBox.setEditable(true);
						oConditionComboBox.setSelectedKeys($.sap.sConditions);

						//CR61 - priority editable and set priority
						//oSelectPriority.setEditable(true);
						oSelectPriority.setSelectedKey($.sap.sPriority);

						//CUSTOMDATA write additional data to control (mapValue) customdata array
						//this is preferrable to invisible controls
						oMapValue.data("xCoordinate", $.sap.sXcoordinate, true);
						oMapValue.data("yCoordinate", $.sap.sYcoordinate, true);
						//asset level 3 is sufficient
						oDataModel.read("/RFSProblemMatrixSet", {
							filters: [
								new sap.ui.model.Filter({
									path: "ZassetLevel2",
									operator: sap.ui.model.FilterOperator.EQ,
									value1: $.sap.sAssetL2 //sAssetL3
								}),
								new sap.ui.model.Filter({
									path: "ZassetLevel3",
									operator: sap.ui.model.FilterOperator.EQ,
									value1: $.sap.sAssetL3 //sAssetL3
								})
							],
							and: true,
							success: function (oData, oResponse) {

								if (typeof oData.results !== "undefined" && oData.results.length > 0) {
									// the array is defined and has at least one element
									var aPGArray = [];

									$.each(oData.results, function (i, item) {
										aPGArray.push({
											"key": item.ZproblemGrpId,
											"text": item.ZproblemGrpShDesc,
											"info": item.ZproblemGrpDesc + " (" + item.ZproblemGrpId + ")"
										});
									});
									//PROBLEM GROUP - unique groups
									// convert the array content to JSON string , then reverse it (to check from end to begining)
									aPGArray = aPGArray.map(JSON.stringify).reverse()
										.filter(function (item, index, arr) {
											return arr.indexOf(item, index + 1) === -1;
										}) // check if there is any occurence of the item in whole array
										.reverse().map(JSON.parse); // revert it to original state

									var oPGModel = new sap.ui.model.json.JSONModel(aPGArray);

									oPGComboBox.bindAggregation("items", {
										path: "/",
										template: new sap.ui.core.ListItem({
											key: "{key}",
											text: "{text}",
											tooltip: "{info}"
										})
									});
									//Give the Dropdown Box data by setting it to a Model, the Array
									oPGComboBox.setModel(oPGModel);
									//now set the selected Key
									oPGComboBox.setSelectedKey($.sap.sProblemGroup);

									//PROBLEM OData to Array AND only selected ProblemGroup
									var aProblemArray = [];
									$.each(oData.results, function (i, item) {
										if (item.ZproblemCode !== "") {
											aProblemArray.push({
												"key": item.ZproblemCode,
												"text": item.ZprbCodeShTxt,
												"info": item.ZprbCodeTxt + " (" + item.ZproblemCode + ")",
												"keyPG": item.ZproblemGrpId, //filter
												"defPrio": item.ZdefPrio
											});
										}
									});
									// Unique problems: convert the array content to JSON string, then reverse it (to check from end to begining)
									aProblemArray = aProblemArray.map(JSON.stringify).reverse()
										.filter(function (item, index, arr) {
											return arr.indexOf(item, index + 1) === -1;
										}) // check if there is any occurence of the item in whole array
										.reverse().map(JSON.parse); // revert it to original state

									var oProblemModel = new sap.ui.model.json.JSONModel(aProblemArray);
									oProblemComboBox.bindAggregation("items", {
										path: "/",
										template: new sap.ui.core.ListItem({
											key: "{key}",
											text: "{text}",
											tooltip: "{info}",
											customdata: [("keyPG", "{keyPG}"), ("defPrio", "{defPrio}")]
										})
									});
									//Give the Dropdown Box data by setting it to a Model, the Array
									oProblemComboBox.setModel(oProblemModel);
									//now set the selected Key and filter
									var ofilter = oPGComboBox.getSelectedKey();
									var oBindingProblemComboBox = oProblemComboBox.getBinding("items");
									var aFiltersProblemComboBox = [];
									var oFilterProblemComboBox = new sap.ui.model.Filter("keyPG", sap.ui.model.FilterOperator.EQ, ofilter);
									aFiltersProblemComboBox.push(oFilterProblemComboBox);
									oBindingProblemComboBox.filter(aFiltersProblemComboBox);
									oProblemComboBox.setSelectedKey($.sap.sProblem);

									//CONDITIONS OData to Array AND only for selected ProblemGroup, Problem
									var aConditionArray = [];
									$.each(oData.results, function (i, item) {
										//if (item.Zconditions !== "" && item.ZproblemGrpId == sProblemGroup &&  item.ZproblemCode == sProblem) {
										if (item.Zconditions !== "") {
											aConditionArray.push({
												"key": item.Zconditions,
												"text": item.ZcondShText,
												//"info": item.ZcondText,
												"info": item.ZcondText + " (" + item.Zconditions + ")",
												"keyPG": item.ZproblemGrpId, //filter
												"keyP": item.ZproblemCode, //filter
												"defPrio": item.ZdefPrio,
												"condPrio": item.ZcondPrio
											});
										}
									});
									// Unique conditions: convert the array content to JSON string , then reverse it (to check from end to begining)
									aConditionArray = aConditionArray.map(JSON.stringify).reverse()
										.filter(function (item, index, arr) {
											return arr.indexOf(item, index + 1) === -1;
										}) // check if there is any occurence of the item in whole array
										.reverse().map(JSON.parse); // revert it to original state

									var oConditionModel = new sap.ui.model.json.JSONModel(aConditionArray);
									oConditionComboBox.bindAggregation("items", {
										path: "/",
										template: new sap.ui.core.ListItem({
											key: "{key}",
											text: "{text}",
											tooltip: "{info}",
											customdata: [("keyPG", "{keyPG}"), ("keyP", "{keyP}"), ("defPrio", "{defPrio}"), ("condPrio", "{condPrio}")]
										})
									});
									//Give the Dropdown Box data by setting it to a Model, the Array
									oConditionComboBox.setModel(oConditionModel);
									//now set the selected Key and filter
									ofilter = oProblemComboBox.getSelectedKey();
									var oBindingConditionComboBox = oConditionComboBox.getBinding("items");
									var aFiltersConditionComboBox = [];
									var oFilterConditionComboBox = new sap.ui.model.Filter("keyP", sap.ui.model.FilterOperator.EQ, ofilter);
									aFiltersConditionComboBox.push(oFilterConditionComboBox);
									oBindingConditionComboBox.filter(aFiltersConditionComboBox);
									oConditionComboBox.setSelectedKeys($.sap.sConditions);

									//evaluate priority

								} else {
									//remove 'old' entries
									sap.m.MessageToast.show("No Problem Group/Problem found for Asset:".concat($.sap.sAssetL3));
									oPGComboBox.setModel(new sap.ui.model.json.JSONModel({
										data: []
									}));
									oProblemComboBox.setModel(new sap.ui.model.json.JSONModel({
										data: []
									}));
									oConditionComboBox.setModel(new sap.ui.model.json.JSONModel({
										data: []
									}));
									//CR61 - set priority to normal (5)
									oSelectPriority.setSelectedKey("5");
								}
							}
						});
						oDataModel.attachRequestFailed(function (oRequestFailedEvent) {
							sap.m.MessageToast.show("Read RFS - Failed");
						});
					}
				});
			}
		},
		readProblemMatrix: function (sAssetL3) {
				//get GW url parameters for selected PG,P,Cs and transaction/asstetL3/xy to pass to GIS map url
				//and to poulate PG, P, Cs and asset in UI5 app
				// if (sAssetL3 === null || typeof sAssetL3 === "undefined") {
				// 	// $.sap.sAssetL3 = jQuery.sap.getUriParameters().get("assetl3");
				// 	if ($.sap.sAssetL3 === null || typeof $.sap.sAssetL3 === "undefined") {
				// 	// 	$.sap.sAssetL3 = jQuery.sap.getUriParameters().get("ASSETL3");
				// 	} else {
				$.sap.sAssetL3 = sAssetL3;
				//	}
				//read once

				var oDataModel = sap.ui.getCore().getModel();

				if ($.sap.sAssetL3 !== "" && $.sap.sAssetL3 !== null && typeof $.sap.sAssetL3 !== "undefined" && $.sap.problemMatrixRead !== true) {
					//read DB for Problem Matrix data of given asset
					//var oDataModel = sap.ui.getCore().getModel();

					oDataModel.setUseBatch(false);
					// oDataModel.read("/RFSProblemMatrixSet('" + $.sap.sAssetL3 + "')", {
					// 	async: false,
					// 	success: function (oData, oResponse) {
					// 		$.sap.oResultData = oResponse.data;
					// 	}
					// });

					//	oDataModel.attachRequestCompleted(function (oRequestCompletedEvent) {
					//	$.sap.problemMatrixRead = true;
					//need to check if response is to /RFSRecordSet via url
					//	var oEventParameter = oRequestCompletedEvent.getParameter("url");
					//	if ($.sap.problemMatrixRead !== true && oEventParameter.includes("/RFSProblemMatrixSet")) {
					$.sap.problemMatrixRead = true;
					//RFS w/o GIS enable update button by default
					sap.ui.getCore().byId("ConfirmButton").setEnabled(true);
					sap.ui.getCore().byId("RefreshButton").setEnabled(true);
					//update App data
					//updateRFSDataToApp($.sap.oResultData);

					//update the controls
					var oMapValue = sap.ui.getCore().byId("mapValue");
					var oPGComboBox = sap.ui.getCore().byId("PGComboBox");
					var oProblemComboBox = sap.ui.getCore().byId("ProblemComboBox");
					//oProblemComboBox.fireSelectionChange();
					var oConditionComboBox = sap.ui.getCore().byId("ConditionMComboBox");

					oMapValue.setValue($.sap.sAssetL3);
					oPGComboBox.setEditable(true);
					oPGComboBox.setSelectedKey($.sap.sProblemGroup);

					oProblemComboBox.setEditable(true);
					oProblemComboBox.setSelectedKey($.sap.sProblem);

					oConditionComboBox.setEditable(true);
					oConditionComboBox.setSelectedKeys($.sap.sConditions);

					//CUSTOMDATA write additional data to control (mapValue) customdata array
					//this is preferrable to invisible controls
					//oMapValue.data("xCoordinate", $.sap.sXcoordinate, true);
					//oMapValue.data("yCoordinate", $.sap.sYcoordinate, true);
					//asset level 3 is sufficient
					oDataModel.read("/RFSProblemMatrixSet", {
						filters: [
							new sap.ui.model.Filter({
								path: "ZassetLevel2",
								operator: sap.ui.model.FilterOperator.EQ,
								value1: $.sap.sAssetL2 //sAssetL2
							}),
							new sap.ui.model.Filter({
								path: "ZassetLevel3",
								operator: sap.ui.model.FilterOperator.EQ,
								value1: $.sap.sAssetL3 //sAssetL3
							})
						],
						and: true,
						success: function (oData, oResponse) {

							if (typeof oData.results !== "undefined" && oData.results.length > 0) {
								// the array is defined and has at least one element
								var aPGArray = [];

								$.each(oData.results, function (i, item) {
									aPGArray.push({
										"key": item.ZproblemGrpId,
										"text": item.ZproblemGrpShDesc,
										"info": item.ZproblemGrpDesc + " (" + item.ZproblemGrpId + ")"
									});
								});
								//PROBLEM GROUP - unique groups
								// convert the array content to JSON string , then reverse it (to check from end to begining)
								aPGArray = aPGArray.map(JSON.stringify).reverse()
									.filter(function (item, index, arr) {
										return arr.indexOf(item, index + 1) === -1;
									}) // check if there is any occurence of the item in whole array
									.reverse().map(JSON.parse); // revert it to original state

								var oPGModel = new sap.ui.model.json.JSONModel(aPGArray);

								oPGComboBox.bindAggregation("items", {
									path: "/",
									template: new sap.ui.core.ListItem({
										key: "{key}",
										text: "{text}",
										tooltip: "{info}"
									})
								});
								//Give the Dropdown Box data by setting it to a Model, the Array
								oPGComboBox.setModel(oPGModel);
								//now set the selected Key
								oPGComboBox.setSelectedKey($.sap.sProblemGroup);

								//PROBLEM OData to Array AND only selected ProblemGroup
								var aProblemArray = [];
								$.each(oData.results, function (i, item) {
									if (item.ZproblemCode !== "") {
										aProblemArray.push({
											"key": item.ZproblemCode,
											"text": item.ZprbCodeShTxt,
											"info": item.ZprbCodeTxt + " (" + item.ZproblemCode + ")",
											"keyPG": item.ZproblemGrpId, //filter
											"defPrio": item.ZdefPrio
										});
									}
								});
								// Unique problems: convert the array content to JSON string, then reverse it (to check from end to begining)
								aProblemArray = aProblemArray.map(JSON.stringify).reverse()
									.filter(function (item, index, arr) {
										return arr.indexOf(item, index + 1) === -1;
									}) // check if there is any occurence of the item in whole array
									.reverse().map(JSON.parse); // revert it to original state

								var oProblemModel = new sap.ui.model.json.JSONModel(aProblemArray);
								oProblemComboBox.bindAggregation("items", {
									path: "/",
									template: new sap.ui.core.ListItem({
										key: "{key}",
										text: "{text}",
										tooltip: "{info}",
										customdata: [("keyPG", "{keyPG}"), ("defPrio", "{defPrio}")]
									})
								});
								//Give the Dropdown Box data by setting it to a Model, the Array
								oProblemComboBox.setModel(oProblemModel);
								//now set the selected Key and filter
								var oBindingProblemComboBox = oProblemComboBox.getBinding("items");
								var aFiltersProblemComboBox = [];
								var oFilterProblemComboBox = new sap.ui.model.Filter("keyPG", sap.ui.model.FilterOperator.EQ, oPGComboBox.getSelectedKey());
								aFiltersProblemComboBox.push(oFilterProblemComboBox);
								oBindingProblemComboBox.filter(aFiltersProblemComboBox);
								oProblemComboBox.setSelectedKey($.sap.sProblem);

								//CONDITIONS OData to Array AND only for selected ProblemGroup, Problem
								var aConditionArray = [];
								$.each(oData.results, function (i, item) {
									//if (item.Zconditions !== "" && item.ZproblemGrpId == sProblemGroup &&  item.ZproblemCode == sProblem) {
									if (item.Zconditions !== "") {
										aConditionArray.push({
											"key": item.Zconditions,
											"text": item.ZcondShText,
											//"info": item.ZcondText,
											"info": item.ZcondText + " (" + item.Zconditions + ")",
											"keyPG": item.ZproblemGrpId, //filter
											"keyP": item.ZproblemCode, //filter
											"defPrio": item.ZdefPrio,
											"condPrio": item.ZcondPrio
										});
									}
								});
								// Unique conditions: convert the array content to JSON string , then reverse it (to check from end to begining)
								aConditionArray = aConditionArray.map(JSON.stringify).reverse()
									.filter(function (item, index, arr) {
										return arr.indexOf(item, index + 1) === -1;
									}) // check if there is any occurence of the item in whole array
									.reverse().map(JSON.parse); // revert it to original state

								var oConditionModel = new sap.ui.model.json.JSONModel(aConditionArray);
								oConditionComboBox.bindAggregation("items", {
									path: "/",
									template: new sap.ui.core.ListItem({
										key: "{key}",
										text: "{text}",
										tooltip: "{info}",
										customdata: [("keyPG", "{keyPG}"), ("keyP", "{keyP}"), ("defPrio", "{defPrio}"), ("condPrio", "{condPrio}")]
									})
								});
								//Give the Dropdown Box data by setting it to a Model, the Array
								oConditionComboBox.setModel(oConditionModel);
								//now set the selected Key and filter
								//ofilter = oProblemComboBox.getSelectedKey();
								var oBindingConditionComboBox = oConditionComboBox.getBinding("items");
								var aFiltersConditionComboBox = [];
								var oFilterConditionComboBox = new sap.ui.model.Filter("keyP", sap.ui.model.FilterOperator.EQ, oProblemComboBox.getSelectedKey());
								aFiltersConditionComboBox.push(oFilterConditionComboBox);
								oBindingConditionComboBox.filter(aFiltersConditionComboBox);
								oConditionComboBox.setSelectedKeys($.sap.sConditions);

								//var sDefPriority = oProblemComboBox.data("defPrio");
								//sap.ui.getCore().byId("selectPriority").setSelectedKey(translatePriority(sDefPriority));

							} else {
								//remove 'old' entries
								sap.m.MessageToast.show("No Problem Group/Problem found for Asset:".concat($.sap.sAssetL3));
								oPGComboBox.setModel(new sap.ui.model.json.JSONModel({
									data: []
								}));
								oProblemComboBox.setModel(new sap.ui.model.json.JSONModel({
									data: []
								}));
								oConditionComboBox.setModel(new sap.ui.model.json.JSONModel({
									data: []
								}));
								//CR61 - set priority to normal (5)
								sap.ui.getCore().byId("selectPriority").setSelectedKey("5");
							}
						}
					});
					// 	oDataModel.attachRequestFailed(function (oRequestFailedEvent) {
					// 		sap.m.MessageToast.show("Read Problem Matrix data failed for Asset:".concat($.sap.sAssetL3));
					// 	});
					// }

					//	});
				}
			}
			//}
	};
});