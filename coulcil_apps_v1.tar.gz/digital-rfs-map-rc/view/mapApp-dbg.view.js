sap.ui.jsview("ZRFSDigital.ZRFSDigital_v6.view.mapApp", {

	/** Specifies the Controller belonging to this View. 
	 * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	 * @memberOf controller.mapApp
	 * @returns {}
	 */
	getControllerName: function () {
		return "ZRFSDigital.ZRFSDigital_v6.controller.mapApp";
	},

	/** 
	 * Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	 * Since the Controller is given to this method, its event handlers can be attached right away.
	 * @memberOf controller.mapApp
	 * @returns {}
	 */
	createContent: function (oController) {
		var oPage = new sap.m.Page({
			//confirmed customer

			// title: "{i18n>title}" + " (Confirmed Customer: " + jQuery.sap.getUriParameters().get("account_description") + " - " + jQuery.sap.getUriParameters()
			// 	.get("customer") + ")",
			title: "{i18n>title}",
			id: "page",
			content: [
				new sap.m.VBox({
					items: [
						new sap.ui.layout.form.Form({
							layout: new sap.ui.layout.form.ResponsiveGridLayout({

							}), //grid layout
							formContainers: [
									new sap.ui.layout.form.FormContainer({
										formElements: [
												new sap.ui.layout.form.FormElement({
													fields: [new sap.m.ComboBox({
															id: "PGComboBox",
															tooltip: "Select Problem Group",
															placeholder: "Problem Group",
															value: "",
															required: true,
															editable: false,
															init: function (oEvent) {
																var oPGComboBox = sap.ui.getCore().byId("PGComboBox");
																oPGComboBox.setColTooltip(oEvent.getParameter("value") + " (" + ")");
																$("#PGComboBox").css("background-color", "#ffffff");
															},
															//change
															change: oController.onProblemGroupChange,
															selectionChange: oController.onProblemGroupSelectionChange,
															//beforeRendering: oController.onProblemGroupBeforeRendering,
															layoutData: new sap.ui.layout.GridData({
																span: "XL2 L2 M1 S1"
															}),
															width: "100%"
														}),
														new sap.m.ComboBox({
															id: "ProblemComboBox",
															tooltip: "Select Problem",
															placeholder: "Problem",
															value: "",
															required: true,
															editable: false,
															//Events
															change: oController.onProblemChange,
															selectionChange: oController.onProblemSelectionChange,
															//Layout
															layoutData: new sap.ui.layout.GridData({
																span: "XL2 L2 M1 S1"
															}),
															width: "100%"
														}),
														new sap.m.MultiComboBox({
															id: "ConditionMComboBox",
															tooltip: "Select Conditions Applicable",
															placeholder: "Applicable Conditions",
															editable: false,
															//value: "",
															required: true,
															//Events
															//change: oController.onConditionsSelectionChange,
															selectionChange: oController.onConditionsSelectionChange,
															selectionFinish: oController.onConditionsSelectionFinish,
															//Layout
															layoutData: new sap.ui.layout.GridData({
																span: "XL3 L2 M1 S1"
															}),
															width: "100%"
														}),
														//CR61 - Priority editable
														new sap.m.Select({
															id: "selectPriority",
															tooltip: "Review Priority Applicable",
															placeholder: "Priority",
															value: "",
															required: true,
															editable: false,
															items: {
																path: "/PriorityCollection",
																sorter: {
																	path: "PriorityId"
																},
																template: new sap.ui.core.ListItem({
																	key: "{PriorityId}",
																	text: "{Name}",
																	icon: "{Icon}"
																})
															},
															//Events
															selectionChange: function (oEvent) {
																//var oSelectedItem = oEvent.getParameter("selectedItem");
															},
															//Layout
															layoutData: new sap.ui.layout.GridData({
																span: "XL1 L1 M1 S1"
															}),
															width: "100%"
														}),
														new sap.m.Input({
															id: "mapValue",
															placeholder: "Location/Asset...",
															tooltip: "Location/Asset selected in the Map",
															value: "",
															enabled: true,
															editable: false,
															//Events
															change: oController.onMapValueChange,
															submit: oController.onMapValueSubmit,
															//Layout
															layoutData: new sap.ui.layout.GridData({
																span: "XL2 L2 M1 S1"
															}),
															width: "100%"
														}),
														new sap.m.Button({
															//text: "SAPUI5",
															id: "ConfirmButton",
															icon: "sap-icon://accept",
															text: "Create RFS",
															tooltip: "Confirm Problem, Conditions and Asset Selection. Create/Update RFS",
															enabled: false,
															// press: "handleConfirmSelection",
															press: function (oEvent) {
																var promises = [];
																//self = this;
																//   Promise.all(promises).then(function() {};

																var oRFSDataModel = sap.ui.getCore().getModel();
																oRFSDataModel.setUseBatch(false);

																var oRFSEntry = {};
																//get confirmed BP ID from URL or from record
																if ($.sap.sCustomerId !== "" && typeof $.sap.sCustomerId !== "undefined" && $.sap.sCustomerId !== null) {
																	var sCustomerId = $.sap.sCustomerId;
																} else {
																	sCustomerId = jQuery.sap.getUriParameters().get("customer");
																	if (sCustomerId === null || typeof sCustomerId === "undefined") {
																		sCustomerId = jQuery.sap.getUriParameters().get("CUSTOMER");
																	}
																}
																if (sCustomerId !== "" && typeof sCustomerId !== "undefined" && sCustomerId !== null) {
																	oRFSEntry.ZcustomerId = sCustomerId;
																}
																if ($.sap.sContactId !== "" && typeof $.sap.sContactId !== "undefined" && $.sap.sContactId !== null) {
																	var sContactId = $.sap.sContactId;
																} else {
																	sContactId = jQuery.sap.getUriParameters().get("contact");
																	if (sContactId === null || typeof sContactId === "undefined") {
																		sContactId = jQuery.sap.getUriParameters().get("CONTACT");
																	}
																}
																if (sContactId !== "" && typeof sContactId !== "undefined" && sContactId !== null) {
																	oRFSEntry.ZcontactId = sContactId;
																}
																oRFSEntry.ZassetLvl3 = sap.ui.getCore().byId("mapValue").getValue();
																if (oRFSEntry.ZassetLvl3 === "" || oRFSEntry.ZassetLvl3 === "undefined") {
																	sap.m.MessageToast.show("Confirm asset selection in map");
																	return;
																}
																oRFSEntry.ZassetLvl2 = sap.ui.getCore().byId("mapValue").data("assetL2");
																//oRFSEntry.ZassetLvl2 = sap.ui.getCore().byId("assetL2").getValue();
																if (oRFSEntry.ZassetLvl2 === "" && oRFSEntry.ZassetLvl3 !== "") {
																	oRFSEntry.ZassetLvl2 = oRFSEntry.ZassetLvl3.slice(0, 10);
																}
																oRFSEntry.ZprobGrp = sap.ui.getCore().byId("PGComboBox").getSelectedKey();
																oRFSEntry.ZprobCod = sap.ui.getCore().byId("ProblemComboBox").getSelectedKey();
																//check that problem group, problem are filled for selected asset
																if (oRFSEntry.ZprobGrp === "" || oRFSEntry.ZprobGrp === "undefined" || oRFSEntry.ZprobCod === "" || oRFSEntry
																	.ZprobCod === "undefined") {
																	//sap.m.MessageToast.show("Note that Problem Group," +
																	//	"Problem or Conditions haven't been selected for asset" + oRFSEntry.ZassetLvl3);
																	//return; allow creation without full data set
																	//get count of PG found, i.e. a user can actually select if > 0
																	var oPGComboBox = sap.ui.getCore().byId("PGComboBox");
																	var sProblemGroupCount = oPGComboBox.getItems().length;
																	promises.push(oController.onRFSCreateDialogMissingData(oRFSEntry.ZassetLvl3, sProblemGroupCount));
																}
																//custom data holds x,y and address
																var xCoordinate = sap.ui.getCore().byId("mapValue").data("xCoordinate");
																if (xCoordinate !== "" && typeof xCoordinate !== "undefined" && xCoordinate !== null) {
																	// oRFSEntry.x_coordinate = xCoordinate.toFixed(4);
																	oRFSEntry.x_coordinate = parseFloat(xCoordinate).toFixed(2);
																}
																var yCoordinate = sap.ui.getCore().byId("mapValue").data("yCoordinate");
																if (yCoordinate !== "" && typeof yCoordinate !== "undefined" && yCoordinate !== null) {
																	oRFSEntry.y_coordinate = parseFloat(yCoordinate).toFixed(2);
																}
																// address string from GIS
																var addressStr = sap.ui.getCore().byId("mapValue").data("addressStr");
																if (addressStr !== "" && typeof addressStr !== "undefined" && addressStr !== null) {
																	oRFSEntry.ZaddressStr = addressStr;
																}
																// Redetermination asset from GIS 
																var sAssetGISReDet = sap.ui.getCore().byId("mapValue").data("assetGISReDet");
																if (sAssetGISReDet !== "" && typeof sAssetGISReDet !== "undefined" && sAssetGISReDet !== null) {
																	oRFSEntry.ZassetGISReDet = sAssetGISReDet;
																}
																oRFSEntry.Zdescription = sap.ui.getCore().byId("ProblemComboBox").getValue();

																//create string of selected condition keys
																var aProbCond = [];
																aProbCond = sap.ui.getCore().byId("ConditionMComboBox").getSelectedKeys();
																oRFSEntry.ZProbCondStr = aProbCond.toString();

																//CR61 direct priority input
																oRFSEntry.Zpriority = sap.ui.getCore().byId("selectPriority").getSelectedKey();

																//only if promises are resolved
																Promise.all(promises).then(function () {

																	//create mode->can be duplicate
																	if (typeof $.sap.sObjectId === "undefined" || $.sap.sObjectId === null) {
																		sap.ui.core.BusyIndicator.show();

																		oRFSDataModel.setHeaders({
																			"content-type": "application/json;charset=utf-8"
																		});
																		//differnt ways: create with return of duplicates

																		//call duplicate check only if not in 'NON' GIS mode
																		if ($.sap.sGisBaseUrl !== "NO_GIS_AVAILABLE") {
																			oRFSDataModel.read("/RFSRecordSet", {
																				filters: [
																					new sap.ui.model.Filter({
																						path: "ZassetLvl3",
																						operator: sap.ui.model.FilterOperator.EQ,
																						value1: oRFSEntry.ZassetLvl3
																					}),
																					//removeasset L2 dependency from call
																					new sap.ui.model.Filter({
																						path: "ZprobGrp",
																						operator: sap.ui.model.FilterOperator.EQ,
																						value1: oRFSEntry.ZprobGrp
																					}),
																					new sap.ui.model.Filter({
																						path: "ZprobCod",
																						operator: sap.ui.model.FilterOperator.EQ,
																						value1: oRFSEntry.ZprobCod
																					}),
																					new sap.ui.model.Filter({
																						path: "x_coordinate",
																						operator: sap.ui.model.FilterOperator.EQ,
																						value1: oRFSEntry.x_coordinate
																					}),
																					new sap.ui.model.Filter({
																						path: "y_coordinate",
																						operator: sap.ui.model.FilterOperator.EQ,
																						value1: oRFSEntry.y_coordinate
																					})
																				],
																				and: true,

																				success: function (oData, oResponse) {
																					//show popup
																					if (typeof oData.results !== "undefined" && oData.results.length > 0) {

																						var aRFSRecordsArray = [];
																						var sPriorityText = [];
																						sap.m.MessageToast.show("Duplicates found: " + oData.results.length);
																						//display fragement dialog
																						$.each(oData.results, function (i, item) {
																							switch (item.Zpriority) {
																							case "0":
																								sPriorityText[i] = "Undefined";
																								break;
																							case "1":
																								sPriorityText[i] = "Critical";
																								break;
																							case "2":
																								sPriorityText[i] = "Major";
																								break;
																							case "3":
																								sPriorityText[i] = "Urgent";
																								break;
																							case "5":
																								sPriorityText[i] = "Normal";
																								break;
																							}

																							aRFSRecordsArray.push({
																								//RFS data set
																								"objectID": item.ZobjectId,
																								"description": item.Zdescription,
																								"status": item.Zstatus,
																								//"priority": item.Zpriority,
																								//text
																								"priorityText": sPriorityText[i],
																								//value of priority needed for duplicate check
																								"priority": item.Zpriority,
																								"created": item.Zcreated
																									// item.Zcompleted,
																									// item.Zclosed,
																									// item.ZestimatedEnd,
																									// item.ZassetLvl3,
																									// item.ZassetLvl2,
																									// item.ZprobGrp,
																									// item.ZprobCod,
																									// item.ZhybrisId,
																									// item.Zsla_Flag,
																									// item.Zsla_msg,
																									// item.Zsub_status,
																									// item.x_coordinate,
																									// item.y_coordinate

																							});
																						});
																						// create the model to hold the data
																						var oRFSRecordsModel = new sap.ui.model.json.JSONModel();
																						oRFSRecordsModel.setDefaultBindingMode("OneWay");
																						oRFSRecordsModel.setData(aRFSRecordsArray);

																						var oDuplicateDialog = new sap.m.Dialog({
																							id: "IdDuplicateDialog",
																							title: "Existing RFS",
																							type: "Message",
																							content: [
																								new sap.m.Table({
																									id: "IdDuplicateTableSelect",
																									mode: sap.m.ListMode.SingleSelectLeft,
																									enableColumnFreeze: true,
																									enableColumnReordering: true,
																									enableCellFilter: true,
																									columns: [
																										oController.onCreateDuplicateDialogColumns()
																									],
																									//sorter:[
																									//assuming posting date and objetcid have same order
																									sorter: new sap.ui.model.Sorter("objectID", true),
																									//	oController.onSortDuplicateDialogColumns("created")
																									//	],
																									//afterRendering: oController.onAfterRenderingDuplicateTable(),
																									items: {
																										path: "/",
																										template: new sap.m.ColumnListItem({
																											type: "Active",
																											press: "onItemPressed",
																											cells: [
																												new sap.m.Text({
																													text: "{objectID}",
																													press: "onSelectionChange"
																												}),
																												new sap.m.Text({
																													text: "{description}"
																												}),
																												new sap.m.DateTimeInput({
																													editable: false,
																													value: "{created}",
																													valueFormat: "yyyyMMddHHmmiiss",
																													displayFormat: "dd.MM.yyyy HH:mm" //24hr
																														//displayFormat: "dd.MM.yyyy hh:mm"
																												}),
																												new sap.m.Text({
																													//text: "{priority}"
																													text: "{priorityText}"
																												}),
																												new sap.m.Text({
																													text: "{status}"
																												})
																											]

																										})

																									}
																								})
																							],
																							//need 3 buttons; that's why we don't use TableSelect Dialog
																							buttons: [
																								new sap.m.Button({
																									text: "Create new RFS",
																									id: "CreateRFSButton",
																									press: function () {
																										//create RFS - use generated GUID from data flow
																										oRFSEntry.ZrfsGuid = $.sap.sRfsGuid;
																										oRFSEntry.ZobjectId = "";
																										oRFSEntry.ZupdateMode = "Create";
																										oController.onCreateUpdateRFSButtonPress(oRFSEntry);
																										oDuplicateDialog.close();
																									}
																								}),
																								new sap.m.Button({
																									text: "Update selected RFS",
																									press: function () {
																										oRFSEntry.ZupdateMode = "Duplicate";
																										oController.onUpdateSelectedRfsPress(oRFSEntry);
																										oDuplicateDialog.close();
																									}
																								}),
																								new sap.m.Button({
																									text: "Cancel",
																									press: function () {
																										oDuplicateDialog.close();
																									}
																								})
																							],
																							afterClose: function () {
																								oDuplicateDialog.destroy();
																							}
																						});

																						oDuplicateDialog.setTitle("RFS Duplicates found: " + oData.results.length);
																						oDuplicateDialog.setModel(oRFSRecordsModel);

																						//takes time?
																						sap.ui.core.BusyIndicator.hide();
																						oDuplicateDialog.open();

																					} else {
																						//create 
																						sap.ui.core.BusyIndicator.hide();
																						oRFSEntry.ZrfsGuid = $.sap.sRfsGuid;
																						oController.onCreateUpdateRFSButtonPress(oRFSEntry);
																					}
																				},
																				error: function (oError) {
																					sap.ui.core.BusyIndicator.hide();
																					var errorObject = JSON.parse(oError.responseText);
																					sap.m.MessageToast.show(errorObject.error.message.value);
																				}
																			});
																		} else {
																			//NO GIS -direct creation
																			sap.ui.core.BusyIndicator.hide();
																			oRFSEntry.ZupdateMode = "Create";
																			oController.onCreateUpdateRFSButtonPress(oRFSEntry);
																		}
																	} else {
																		sap.ui.core.BusyIndicator.hide();
																		oRFSEntry.ZupdateMode = "Redeterm";
																		oController.onCreateUpdateRFSButtonPress(oRFSEntry);
																	}
																});
															},
															//end Create RFS
															layoutData: new sap.ui.layout.GridData({
																span: "XL1 L1 M1 S1"
															}),
															width: "100%"
														}),
														new sap.m.Button({
															id: "RefreshButton",
															icon: "sap-icon://sys-cancel",
															tooltip: "Clear Problem, Conditions and Asset Selection",
															enabled: false,
															//Events
															press: oController.onRefreshButtonPress,
															//Layout
															layoutData: new sap.ui.layout.GridData({
																span: "XL1 L1 M1 S1"
															}),
															width: "50%"
														})
													]
												})

											] //form elements
									})
								] //form container

						}) //form

					]
				}),
				new sap.ui.core.HTML({
					preferDOM: true,
					//url in content needs to be escaped
					//"https://rfsstoragedev.z26.web.core.windows.net/?webmap=5c5e96db0ae440109f9c5ea601544f0a&amp;mode=csr&amp;layout=normal"
					//oveflow needed for confirming location selection
					content: "<iframe src='about:blank' id='iFrameMap' height='90%' width='100%' overflow='auto'></iframe>",
					//get the map url, for edit this needs to take x,y into account
					afterRendering: function () {
						//set title for page to indicate create/edit mode
						sap.ui.core.BusyIndicator.show();
						sap.ui.getCore().byId("page").setTitle(oController.getAppTitle($.sap.sCustomer, $.sap.sObjectId));
						sap.ui.getCore().byId("ConfirmButton").setText(oController.getConfirmButtonText($.sap.sObjectId));
						//distinguish availability of GIS
						oController.setMapUrl($.sap.sGisBaseUrl);
						sap.ui.core.BusyIndicator.hide();
					}
				})
			]
		});

		var app = new sap.m.App(this.createId("app"), {
			initialPage: "page"
		});
		app.addPage(oPage);
		return app;
	}
});