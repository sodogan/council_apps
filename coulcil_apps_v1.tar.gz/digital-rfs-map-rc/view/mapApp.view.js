sap.ui.jsview("ZRFSDigital.ZRFSDigital_v6.view.mapApp", {
	getControllerName: function () {
		return "ZRFSDigital.ZRFSDigital_v6.controller.mapApp"
	},
	createContent: function (e) {
		var t = new sap.m.Page({
			title: "{i18n>title}",
			id: "page",
			content: [new sap.m.VBox({
				items: [new sap.ui.layout.form.Form({
					layout: new sap.ui.layout.form.ResponsiveGridLayout({}),
					formContainers: [new sap.ui.layout.form.FormContainer({
						formElements: [new sap.ui.layout.form.FormElement({
							fields: [new sap.m.ComboBox({
								id: "PGComboBox",
								tooltip: "Select Problem Group",
								placeholder: "Problem Group",
								value: "",
								required: true,
								editable: false,
								change: e.onProblemGroupChange,
								selectionChange: e.onProblemGroupSelectionChange,
								layoutData: new sap.ui.layout.GridData({
									span: "XL2 L2 M1 S1"
								}),
								width: "100%"
							}), new sap.m.ComboBox({
								id: "ProblemComboBox",
								tooltip: "Select Problem",
								placeholder: "Problem",
								value: "",
								required: true,
								editable: false,
								change: e.onProblemChange,
								selectionChange: e.onProblemSelectionChange,
								layoutData: new sap.ui.layout.GridData({
									span: "XL2 L2 M1 S1"
								}),
								width: "100%"
							}), new sap.m.MultiComboBox({
								id: "ConditionMComboBox",
								tooltip: "Select Conditions Applicable",
								placeholder: "Applicable Conditions",
								editable: false,
								required: true,
								selectionChange: e.onConditionsSelectionChange,
								selectionFinish: e.onConditionsSelectionFinish,
								layoutData: new sap.ui.layout.GridData({
									span: "XL3 L2 M1 S1"
								}),
								width: "100%"
							}), 
							
							new sap.m.ComboBox({
								id: "selectPriority",
								tooltip: "Review Priority Applicable",
								placeholder: "Priority",
								value: "",
								required: true,
								editable: true,
								items: {
									path: "/PriorityCollection",
									sorter: {
										path: "PriorityId"
									},
									template: new sap.ui.core.ListItem({
										key: "{PriorityId}",
										text: "{Name}",
										icon: "{Icon}"
									})
								},
								change: function (e) {},
								layoutData: new sap.ui.layout.GridData({
									span: "XL1 L1 M1 S1"
								}),
								width: "100%"
							}),
							
								new sap.m.Input({
								id: "mapValue",
								placeholder: "Location/Asset...",
								tooltip: "Location/Asset selected in the Map",
								value: "",
								enabled: true,
								editable: false,
								change: e.onMapValueChange,
								submit: e.onMapValueSubmit,
								layoutData: new sap.ui.layout.GridData({
									span: "XL2 L2 M1 S1"
								}),
								width: "100%"
							}), new sap.m.Button({
								id: "ConfirmButton",
								icon: "sap-icon://accept",
								text: "Create RFS",
								tooltip: "Confirm Problem, Conditions and Asset Selection. Create/Update RFS",
								enabled: false,
								press: function (t) {
									var a = [];
									var o = sap.ui.getCore().getModel();
									o.setUseBatch(false);
									var s = {};
									if ($.sap.sCustomerId !== "" && typeof $.sap.sCustomerId !== "undefined" && $.sap.sCustomerId !== null) {
										var i = $.sap.sCustomerId
									} else {
										i = jQuery.sap.getUriParameters().get("customer");
										if (i === null || typeof i === "undefined") {
											i = jQuery.sap.getUriParameters().get("CUSTOMER")
										}
									}
									if (i !== "" && typeof i !== "undefined" && i !== null) {
										s.ZcustomerId = i
									}
									if ($.sap.sContactId !== "" && typeof $.sap.sContactId !== "undefined" && $.sap.sContactId !== null) {
										var r = $.sap.sContactId
									} else {
										r = jQuery.sap.getUriParameters().get("contact");
										if (r === null || typeof r === "undefined") {
											r = jQuery.sap.getUriParameters().get("CONTACT")
										}
									}
									if (r !== "" && typeof r !== "undefined" && r !== null) {
										s.ZcontactId = r
									}
									s.ZassetLvl3 = sap.ui.getCore().byId("mapValue").getValue();
									if (s.ZassetLvl3 === "" || s.ZassetLvl3 === "undefined") {
										sap.m.MessageToast.show("Confirm asset selection in map");
										return
									}
									s.ZassetLvl2 = sap.ui.getCore().byId("mapValue").data("assetL2");
									if (s.ZassetLvl2 === "" && s.ZassetLvl3 !== "") {
										s.ZassetLvl2 = s.ZassetLvl3.slice(0, 10)
									}
									s.ZprobGrp = sap.ui.getCore().byId("PGComboBox").getSelectedKey();
									s.ZprobCod = sap.ui.getCore().byId("ProblemComboBox").getSelectedKey();
									if (s.ZprobGrp === "" || s.ZprobGrp === "undefined" || s.ZprobCod === "" || s.ZprobCod === "undefined") {
										var n = sap.ui.getCore().byId("PGComboBox");
										var l = n.getItems().length;
										a.push(e.onRFSCreateDialogMissingData(s.ZassetLvl3, l))
									}
									var p = sap.ui.getCore().byId("mapValue").data("xCoordinate");
									if (p !== "" && typeof p !== "undefined" && p !== null) {
										s.x_coordinate = parseFloat(p).toFixed(2)
									}
									var d = sap.ui.getCore().byId("mapValue").data("yCoordinate");
									if (d !== "" && typeof d !== "undefined" && d !== null) {
										s.y_coordinate = parseFloat(d).toFixed(2)
									}
									var u = sap.ui.getCore().byId("mapValue").data("addressStr");
									if (u !== "" && typeof u !== "undefined" && u !== null) {
										s.ZaddressStr = u
									}
									var c = sap.ui.getCore().byId("mapValue").data("assetGISReDet");
									if (c !== "" && typeof c !== "undefined" && c !== null) {
										s.ZassetGISReDet = c
									}
									s.Zdescription = sap.ui.getCore().byId("ProblemComboBox").getValue();
									var m = [];
									m = sap.ui.getCore().byId("ConditionMComboBox").getSelectedKeys();
									s.ZProbCondStr = m.toString();
									s.Zpriority = sap.ui.getCore().byId("selectPriority").getSelectedKey();
									Promise.all(a).then(function () {
										if (typeof $.sap.sObjectId === "undefined" || $.sap.sObjectId === null) {
											sap.ui.core.BusyIndicator.show();
											o.setHeaders({
												"content-type": "application/json;charset=utf-8"
											});
											if ($.sap.sGisBaseUrl !== "NO_GIS_AVAILABLE") {
												o.read("/RFSRecordSet", {
													filters: [new sap.ui.model.Filter({
														path: "ZassetLvl3",
														operator: sap.ui.model.FilterOperator.EQ,
														value1: s.ZassetLvl3
													}), new sap.ui.model.Filter({
														path: "ZprobGrp",
														operator: sap.ui.model.FilterOperator.EQ,
														value1: s.ZprobGrp
													}), new sap.ui.model.Filter({
														path: "ZprobCod",
														operator: sap.ui.model.FilterOperator.EQ,
														value1: s.ZprobCod
													}), new sap.ui.model.Filter({
														path: "x_coordinate",
														operator: sap.ui.model.FilterOperator.EQ,
														value1: s.x_coordinate
													}), new sap.ui.model.Filter({
														path: "y_coordinate",
														operator: sap.ui.model.FilterOperator.EQ,
														value1: s.y_coordinate
													})],
													and: true,
													success: function (t, a) {
														if (typeof t.results !== "undefined" && t.results.length > 0) {
															var o = [];
															var i = [];
															sap.m.MessageToast.show("Duplicates found: " + t.results.length);
															$.each(t.results, function (e, t) {
																switch (t.Zpriority) {
																case "0":
																	i[e] = "Undefined";
																	break;
																case "1":
																	i[e] = "Critical";
																	break;
																case "2":
																	i[e] = "Major";
																	break;
																case "3":
																	i[e] = "Urgent";
																	break;
																case "5":
																	i[e] = "Normal";
																	break
																}
																o.push({
																	objectID: t.ZobjectId,
																	description: t.Zdescription,
																	status: t.Zstatus,
																	priorityText: i[e],
																	priority: t.Zpriority,
																	created: t.Zcreated
																})
															});
															var r = new sap.ui.model.json.JSONModel;
															r.setDefaultBindingMode("OneWay");
															r.setData(o);
															var n = new sap.m.Dialog({
																id: "IdDuplicateDialog",
																title: "Existing RFS",
																type: "Message",
																content: [new sap.m.Table({
																	id: "IdDuplicateTableSelect",
																	mode: sap.m.ListMode.SingleSelectLeft,
																	enableColumnFreeze: true,
																	enableColumnReordering: true,
																	enableCellFilter: true,
																	columns: [e.onCreateDuplicateDialogColumns()],
																	sorter: new sap.ui.model.Sorter("objectID", true),
																	items: {
																		path: "/",
																		template: new sap.m.ColumnListItem({
																			type: "Active",
																			press: "onItemPressed",
																			cells: [new sap.m.Text({
																				text: "{objectID}",
																				press: "onSelectionChange"
																			}), new sap.m.Text({
																				text: "{description}"
																			}), new sap.m.DateTimeInput({
																				editable: false,
																				value: "{created}",
																				valueFormat: "yyyyMMddHHmmiiss",
																				displayFormat: "dd.MM.yyyy HH:mm"
																			}), new sap.m.Text({
																				text: "{priorityText}"
																			}), new sap.m.Text({
																				text: "{status}"
																			})]
																		})
																	}
																})],
																buttons: [new sap.m.Button({
																	text: "Create new RFS",
																	id: "CreateRFSButton",
																	press: function () {
																		s.ZrfsGuid = $.sap.sRfsGuid;
																		s.ZobjectId = "";
																		s.ZupdateMode = "Create";
																		e.onCreateUpdateRFSButtonPress(s);
																		n.close()
																	}
																}), new sap.m.Button({
																	text: "Update selected RFS",
																	press: function () {
																		s.ZupdateMode = "Duplicate";
																		e.onUpdateSelectedRfsPress(s);
																		n.close()
																	}
																}), new sap.m.Button({
																	text: "Cancel",
																	press: function () {
																		n.close()
																	}
																})],
																afterClose: function () {
																	n.destroy()
																}
															});
															n.setTitle("RFS Duplicates found: " + t.results.length);
															n.setModel(r);
															sap.ui.core.BusyIndicator.hide();
															n.open()
														} else {
															sap.ui.core.BusyIndicator.hide();
															s.ZrfsGuid = $.sap.sRfsGuid;
															e.onCreateUpdateRFSButtonPress(s)
														}
													},
													error: function (e) {
														sap.ui.core.BusyIndicator.hide();
														var t = JSON.parse(e.responseText);
														sap.m.MessageToast.show(t.error.message.value)
													}
												})
											} else {
												sap.ui.core.BusyIndicator.hide();
												s.ZupdateMode = "Create";
												e.onCreateUpdateRFSButtonPress(s)
											}
										} else {
											sap.ui.core.BusyIndicator.hide();
											s.ZupdateMode = "Redeterm";
											e.onCreateUpdateRFSButtonPress(s)
										}
									})
								},
								layoutData: new sap.ui.layout.GridData({
									span: "XL1 L1 M1 S1"
								}),
								width: "100%"
							}), new sap.m.Button({
								id: "RefreshButton",
								icon: "sap-icon://sys-cancel",
								tooltip: "Clear Problem, Conditions and Asset Selection",
								enabled: false,
								press: e.onRefreshButtonPress,
								layoutData: new sap.ui.layout.GridData({
									span: "XL1 L1 M1 S1"
								}),
								width: "50%"
							})]
						})]
					})]
				})]
			}), new sap.ui.core.HTML({
				preferDOM: true,
				content: "<iframe src='about:blank' id='iFrameMap' height='90%' width='100%' overflow='auto'></iframe>",
				afterRendering: function () {
					sap.ui.core.BusyIndicator.show();
					sap.ui.getCore().byId("page").setTitle(e.getAppTitle($.sap.sCustomer, $.sap.sObjectId));
					sap.ui.getCore().byId("ConfirmButton").setText(e.getConfirmButtonText($.sap.sObjectId));
					e.setMapUrl($.sap.sGisBaseUrl);
					sap.ui.core.BusyIndicator.hide()
				}
			})]
		});
		var a = new sap.m.App(this.createId("app"), {
			initialPage: "page"
		});
		a.addPage(t);
		return a;
    }
});