sap.ui.define(["sap/ui/core/UIComponent", "sap/ui/Device", "ZRFSDigital/ZRFSDigital_v6/model/models"], function (e, s, a) {
	"use strict";
	return e.extend("ZRFSDigital.ZRFSDigital_v6.Component", {
		metadata: {
			manifest: "json",
			fullWidth: true
		},
		init: function () {
			e.prototype.init.apply(this, arguments);
			var s = {
				json: true
			};
			var t = "/sap/opu/odata/sap/ZGW_RFS_SERVICESV2_SRV/";
			var r = new sap.ui.model.odata.v2.ODataModel(t, s);
			sap.ui.getCore().setModel(r);
			r.setUseBatch(false);
			r.read("/AppDetailsSet", {
				filters: [new sap.ui.model.Filter({
					path: "Name",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: "ZRFS_GIS_WEB_APP_URL"
				})],
				success: function (e) {
					var s = new sap.ui.model.json.JSONModel;
					s.setData(e);
					var a = s.getProperty("/results/0");
					$.sap.sGisBaseUrl = a.Value
				},
				error: function (e) {
					var s = JSON.parse(e.responseText);
					sap.m.MessageToast.show(s.error.message.value)
				}
			});
			$.sap.sObjectId = jQuery.sap.getUriParameters().get("objectid");
			if ($.sap.sObjectId === null || typeof $.sap.sObjectId === "undefined") {
				$.sap.sObjectId = jQuery.sap.getUriParameters().get("OBJECTID")
			}
			$.sap.sRfsGuid = jQuery.sap.getUriParameters().get("rfsguid");
			if ($.sap.sRfsGuid === null || typeof $.sap.sRfsGuid === "undefined") {
				$.sap.sRfsGuid = jQuery.sap.getUriParameters().get("RFSGUID")
			}
			$.sap.sSharedMemoryId = jQuery.sap.getUriParameters().get("sharedmemoryid");
			if ($.sap.sSharedMemoryId === null || typeof $.sap.sSharedMemoryId === "undefined") {
				$.sap.sSharedMemoryId = jQuery.sap.getUriParameters().get("SHAREDMEMORYID")
			}
			$.sap.sAssetL3 = jQuery.sap.getUriParameters().get("assetl3");
			if ($.sap.sAssetL3 === null || typeof $.sap.sAssetL3 === "undefined") {
				$.sap.sAssetL3 = jQuery.sap.getUriParameters().get("ASSETL3")
			}
			if ($.sap.sAssetL3 !== null && $.sap.sAssetL3 !== "undefined") {
				$.sap.sAssetL2 = $.sap.sAssetL3.slice(0, 10)
			}
			$.sap.sAssetGISReDet = jQuery.sap.getUriParameters().get("assetgisredet");
			if ($.sap.sAssetGISReDet === null || typeof $.sap.sAssetGISReDet === "undefined") {
				$.sap.sAssetGISReDet = jQuery.sap.getUriParameters().get("ASSETGISREDET")
			}
			$.sap.sXcoordinate = jQuery.sap.getUriParameters().get("xcoordinate");
			if ($.sap.sXcoordinate === null || typeof $.sap.sXcoordinate === "undefined") {
				$.sap.sXcoordinate = jQuery.sap.getUriParameters().get("XCOORDINATE")
			}
			$.sap.sYcoordinate = jQuery.sap.getUriParameters().get("ycoordinate");
			if ($.sap.sYcoordinate === null || typeof $.sap.sYcoordinate === "undefined") {
				$.sap.sYcoordinate = jQuery.sap.getUriParameters().get("YCOORDINATE")
			}
			$.sap.sCustomer = jQuery.sap.getUriParameters().get("customer");
			if ($.sap.sCustomer === null || typeof $.sap.sCustomer === "undefined") {
				$.sap.sCustomer = jQuery.sap.getUriParameters().get("CUSTOMER")
			}
			$.sap.sContact = jQuery.sap.getUriParameters().get("contact");
			if ($.sap.sContact === null || typeof $.sap.sContact === "undefined") {
				$.sap.sContact = jQuery.sap.getUriParameters().get("CONTACT")
			}
			this.getRouter().initialize();
			this.setModel(a.createDeviceModel(), "device")
		}
	})
});