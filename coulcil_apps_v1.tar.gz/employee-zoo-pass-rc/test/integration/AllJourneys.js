jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 PERNR_ZOOSet in the list

sap.ui.require([
	"sap/ui/test/Opa5",
	"z03_pass_v6/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"z03_pass_v6/test/integration/pages/App",
	"z03_pass_v6/test/integration/pages/Browser",
	"z03_pass_v6/test/integration/pages/Master",
	"z03_pass_v6/test/integration/pages/Detail",
	"z03_pass_v6/test/integration/pages/Create",
	"z03_pass_v6/test/integration/pages/NotFound"
], function(Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "z03_pass_v6.view."
	});

	sap.ui.require([
		"z03_pass_v6/test/integration/MasterJourney",
		"z03_pass_v6/test/integration/NavigationJourney",
		"z03_pass_v6/test/integration/NotFoundJourney",
		"z03_pass_v6/test/integration/BusyJourney",
		"z03_pass_v6/test/integration/FLPIntegrationJourney"
	], function() {
		QUnit.start();
	});
});