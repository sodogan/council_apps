jQuery.sap.require("sap.ui.commons.MessageBox");
jQuery.sap.require("sap.m.MessageToast");

jQuery.sap.require("nz.co.aklc.OnePlus.util.Helper")
jQuery.sap.require("nz.co.aklc.OnePlus.dao.EquipmentDAO");
jQuery.sap.require("nz.co.aklc.OnePlus.dao.EquipmentFieldsDAO");
jQuery.sap.require("nz.co.aklc.OnePlus.dto.EquipmentRequest");
jQuery.sap.require("nz.co.aklc.OnePlus.dto.EquipmentFieldRequest");
jQuery.sap.require("nz.co.aklc.OnePlus.dto.CharAttribute");
jQuery.sap.require("nz.co.aklc.OnePlus.dto.GisEquipmentParameter");
jQuery.sap.require("nz.co.aklc.OnePlus.dto.GisBusinessRuleParameter");

jQuery.sap.require("nz.co.aklc.OnePlus.mock.EquipmentDAO");
jQuery.sap.require("nz.co.aklc.OnePlus.mock.EquipmentFieldsDAO");

sap.ui.controller("nz.co.aklc.OnePlus.view.Main", {

    _protectedParameters: ["RESOURCEID", "GISID", "GEOMETRYTYPE", "LOCALBOARDCODE", "OPERATIONALAREACODE", "FACILITYID", "PARENTID", "SOURCEDOCURL"],
    _gisParameters: {},
    _formLabels: {},
    _formInputs: {},
    _formFields: [],
    _fieldSettingsBatchVisibility: {},
    _needsBusinessRulesRefresh: false,
    _registerForDestruction: [],
    _isNotesVisible: false,
    _inProcessEquipmentData: null,
    _textFieldFocusValue: "",

    /**
    * Called when a controller is instantiated and its View controls (if available) are already created.
    * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
    * @memberOf nz.co.aklc.OnePlus.view.Main
    */
	onInit: function() {
        // jQuery.sap.log.setLevel(4);
        jQuery.sap.log.debug("onInit()");
        window.document.domain = "aklc.govt.nz";
	},

    /**
    * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
    * (NOT before the first rendering! onInit() is used for that one!).
    * @memberOf nz.co.aklc.OnePlus.view.Main
    */
    onBeforeRendering: function() {
        jQuery.sap.log.debug("onBeforeRendering()");
        this.setBusy(true);
        this._prepareGisParametersMap();
        var oEquipmentRequest = this._getEquipmentRequestFromGisParameters();
        this.findEquipment(oEquipmentRequest);
	},

    /**
    * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
    * This hook is the same one that SAPUI5 controls get after being rendered.
    * @memberOf nz.co.aklc.OnePlus.view.Main
    */
	onAfterRendering: function() {
        jQuery.sap.log.debug("onAfterRendering()");
	},

    /**
    * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
    * @memberOf nz.co.aklc.OnePlus.view.Main
    */
	onExit: function() {
        jQuery.sap.log.debug("onExit()");
        var that = this;
        this._registerForDestruction.forEach(function(oElement) {
            that.getView().byId(oElement.elementName).detachBrowserEvent(oElement.eventName, oElement.fnHandler, this);
        });
	},
	
    _isFormFieldCreated: function(sFieldName) {
        jQuery.sap.log.debug("_isFormFieldCreated(" + sFieldName + ")");
        return (this._formFields.indexOf(sFieldName) !== -1);
    },
    
    _getFieldValueForInput: function(sFieldName) {
        jQuery.sap.log.debug("_getFieldValueForInput(" + sFieldName + ")");
        var oFormField = this._formInputs[sFieldName];
        if (oFormField) {
            switch (oFormField.type) {
                case "sap.ui.commons.DropdownBox":
                    return oFormField.instance.getSelectedKey();
                case "sap.m.Select":
                    return oFormField.instance.getSelectedKey();
                case "sap.ui.commons.TextField":
                    return oFormField.instance.getValue();
                case "sap.ui.commons.DatePicker":
                    return oFormField.instance.getYyyymmdd();
            }
        }
        return null;
    },

    _getEquipmentFieldSettingsRequestControls: function() {
        jQuery.sap.log.debug("_getEquipmentFieldSettingsRequestControls()");
        var aControls = [];
        for (var i = 0; i < this._formFields.length; i++) {
            var sFieldName = this._formFields[i];
            var sInputFieldId = util.Helper.getInputFieldId(sFieldName);
            var sFieldValue = this._getFieldValueForInput(sInputFieldId);
            var oControl = dto.EquipmentFieldRequest.getEquipmentFieldControl(sFieldName, sFieldValue);
            aControls.push(oControl);
        }
        return aControls;
    },
    
    _getInProcessEquipmentField: function(oEquipmentField) {
        var aCharAttributes = this._inProcessEquipmentData.d.charAttributes.results;
        for (var i = 0; i < aCharAttributes.length; i++) {
            if (aCharAttributes[i].name === oEquipmentField.name) {
                return aCharAttributes[i];
            }
        }
        return null;
    },

    _prepareGisParametersMap: function() {
        jQuery.sap.log.debug("_prepareGisParametersMap()");
        for (var sProperty in jQuery.sap.getUriParameters().mParams) {
            this._gisParameters[sProperty.toUpperCase()] = jQuery.sap.getUriParameters().get(sProperty);
        }
	},
	
	_getEquipmentRequestFromGisParameters: function() {
        jQuery.sap.log.debug("_getEquipmentRequestFromGisParameters()");
        var sResourceId = this._gisParameters["resourceId".toUpperCase()];
        var sGisId = this._gisParameters["gisId".toUpperCase()];
        var sGeometryType = this._gisParameters["geometryType".toUpperCase()];
        var sLocalBoardCode = this._gisParameters["localBoardCode".toUpperCase()];
        var sOperationalAreaCode = this._gisParameters["operationalAreaCode".toUpperCase()];
        var sFacilityId = this._gisParameters["facilityId".toUpperCase()];
        var sSourceDocUrl = this._gisParameters["sourceDocUrl".toUpperCase()];
        if (sSourceDocUrl !== null) {
            sSourceDocUrl = decodeURIComponent(sSourceDocUrl);
        }
        var bIsSplit = this._gisParameters["split".toUpperCase()] === "true";
        return dto.EquipmentRequest.getEquipmentRequest("", sGisId, sOperationalAreaCode, sLocalBoardCode, sResourceId, sGeometryType, sFacilityId, sSourceDocUrl, "", bIsSplit);
	},

    setBusy: function(bIsBusy) {
        jQuery.sap.log.debug("setBusy(" + bIsBusy + ")");
        if (bIsBusy) {
            this._closeSelectInputs();
        }
        this.getView().byId("pMain").setBusy(bIsBusy);
        this.getView().byId("bFooter").setBusy(bIsBusy);
    },
    
    _closeSelectInputs: function() {    // IE Issue!
        var that = this;
        this._formFields.forEach(function(sFieldName) {
            var sInputFieldName = util.Helper.getInputFieldId(sFieldName);
            var oInput = that._formInputs[sInputFieldName];
            if (oInput && oInput.type === "sap.ui.commons.DropdownBox") {
                setTimeout(function() {
                    oInput.instance._close();
                }, 0);
            }
        });
    },
    
	onNumericFieldKeyDown: function(oEvent) {
        jQuery.sap.log.debug("onNumericFieldKeyDown(" + oEvent + ")");
        if ($.inArray(oEvent.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 || 
            (oEvent.keyCode === 65 && (oEvent.ctrlKey === true || oEvent.metaKey === true )) || 
                (oEvent.keyCode === 67 && oEvent.ctrlKey === true) ||
                    (oEvent.keyCode === 86 && oEvent.ctrlKey === true) || 
                        (oEvent.keyCode === 88 && oEvent.ctrlKey === true) || 
                            (oEvent.keyCode >= 35 && oEvent.keyCode <= 40)) {
            return;
        }
        if ((oEvent.shiftKey || (oEvent.keyCode < 48 || oEvent.keyCode > 57)) && (oEvent.keyCode < 96 || oEvent.keyCode > 105)) {
            oEvent.preventDefault();
        }
	},

    onTextFieldFocus: function(oEvent) {
        jQuery.sap.log.debug("onTextFieldFocus(" + oEvent + ")");
        var sValue = oEvent.target.value.toString();
        this._textFieldFocusValue = sValue;
	},

    createElementsForEquipmentField: function(oEquipmentField) {
        jQuery.sap.log.debug("createElementsForEquipmentField(" + oEquipmentField + ")");
        var that = this;
        var sEquipmentFieldName = oEquipmentField.name;
        if (this._inProcessEquipmentData !== null && (this._inProcessEquipmentData.d["class"].controlCharName === sEquipmentFieldName || this._inProcessEquipmentData.d["class"].statusCharName === sEquipmentFieldName)) {
            var oInProcessEquipmentField = this._getInProcessEquipmentField(oEquipmentField);
            if (oInProcessEquipmentField ===  null) {
                jQuery.sap.log.fatal("createElementsForEquipmentField -- fatal when creating equipment field elements for inProcess equipment field (" + oEquipmentField + ")");
                return;
            }
            oEquipmentField = oInProcessEquipmentField;
        }
        var isDesktop = sap.ui.Device.system.desktop;
        var oLabel, oInput, sLabelType, sInputType;
        var aSelectItems = [];
        if (isDesktop) {
            sLabelType = "sap.ui.commons.Label";
            oLabel = new sap.ui.commons.Label(util.Helper.getLabelFieldId(sEquipmentFieldName), { text: oEquipmentField.label, required: false, labelFor: util.Helper.getInputFieldId(sEquipmentFieldName) });
            oLabel.addStyleClass("fLabel");
        }
        else {
            sLabelType = "sap.m.Label";
            oLabel = new sap.m.Label(util.Helper.getLabelFieldId(sEquipmentFieldName), { text: oEquipmentField.label, required: false, labelFor: util.Helper.getInputFieldId(sEquipmentFieldName) });
        }
        switch (oEquipmentField.type) {
            case "number":
                if (isDesktop) {
                    sInputType = "sap.ui.commons.TextField";
                    oInput = new sap.ui.commons.TextField(util.Helper.getInputFieldId(sEquipmentFieldName), {
                        type: sap.m.InputType.Number,
                        value: {
                            type: "sap.ui.model.type.Float", 
                            formatOptions: { 
                                maxIntegerDigits: parseInt(oEquipmentField.length),
                                maxFractionDigits: parseInt(oEquipmentField.decimals)
                            }
                        },
                        maxLength: (oEquipmentField.decimals !== "" ? parseInt(oEquipmentField.length) + 1 : parseInt(oEquipmentField.length)),
                        change: jQuery.proxy(this.onEquipmentFieldChanged, that),
                        liveChange: jQuery.proxy(this.onEquipmentFieldLiveChange, that),
                        width: util.Helper.getWidthForElement(oEquipmentField.length)
                    }).setValue(oEquipmentField.value !== "" ? parseFloat(oEquipmentField.value) : "");
                }
                else {
                    sInputType = "sap.ui.commons.TextField";
                    oInput = new sap.m.Input(util.Helper.getInputFieldId(sEquipmentFieldName), {
                        type: sap.m.InputType.Number,
                        value: {
                            type: "sap.ui.model.type.Float", 
                            formatOptions: { 
                                maxIntegerDigits: parseInt(oEquipmentField.length),
                                maxFractionDigits: parseInt(oEquipmentField.decimals)
                            }
                        },
                        maxLength: (oEquipmentField.decimals !== "" ? parseInt(oEquipmentField.length) + 1 : parseInt(oEquipmentField.length)),
                        change: jQuery.proxy(this.onEquipmentFieldChanged, that),
                        liveChange: jQuery.proxy(this.onEquipmentFieldLiveChange, that),
                        width: util.Helper.getWidthForElement(oEquipmentField.length)
                    }).setValue(oEquipmentField.value !== "" ? parseFloat(oEquipmentField.value) : "");
                }
                oInput.attachBrowserEvent("keydown", this.onNumericFieldKeyDown, this);
                oInput.attachBrowserEvent("focus", this.onTextFieldFocus, this);
                this._registerForDestruction.push({elementName: util.Helper.getInputFieldId(sEquipmentFieldName), eventName: "keydown", fnHandler: this.onNumericFieldKeyDown});
                this._registerForDestruction.push({elementName: util.Helper.getInputFieldId(sEquipmentFieldName), eventName: "focus", fnHandler: this.onTextFieldFocus});
                break;
            case "date":
                if (isDesktop) {
                    sInputType = "sap.ui.commons.DatePicker";
                    oInput = new sap.ui.commons.DatePicker(util.Helper.getInputFieldId(sEquipmentFieldName), {
                        value: util.Helper.getDate(oEquipmentField.value), 
                        locale: "en-NZ",
                        change: jQuery.proxy(this.onEquipmentFieldChanged, that),
                        width: util.Helper.getWidthForDatePicker()
                    });
                }
                else {
                    sInputType = "sap.m.DatePicker";
                    oInput = new sap.m.DatePicker(util.Helper.getInputFieldId(sEquipmentFieldName), { 
                        value: oEquipmentField.value, 
                        valueFormat: "dd/MM/yyyy", 
                        displayFormat: "dd/MM/yyyy",
                        change: jQuery.proxy(this.onEquipmentFieldChanged, that),
                        width: util.Helper.getWidthForDatePicker()
                    });
                }
                break;
            case "text":
                if (oEquipmentField.listItems && oEquipmentField.listItems.results && oEquipmentField.listItems.results.length) { // DropDrown List..
                    var sSelectedKey = "";
                    var iItemLength = 0;
                    if (isDesktop) {
                        aSelectItems.push(new sap.ui.core.ListItem(util.Helper.getListItemResetFieldId(sEquipmentFieldName), { key: "", text: "" }));
                        sSelectedKey = "";
                        iItemLength = 0;
                        oEquipmentField.listItems.results.forEach(function(oValue, iIndex) {
                            iItemLength = (oValue.description.length > iItemLength ? oValue.description.length : iItemLength);
                            aSelectItems.push(new sap.ui.core.ListItem(util.Helper.getListItemFieldId(sEquipmentFieldName, iIndex), { key: oValue.value, text: oValue.description }));
                            if (!sSelectedKey && oValue.isSelected) {
                                sSelectedKey = oValue.value;
                            }
                        });
                        sInputType = "sap.ui.commons.DropdownBox";
                        oInput = new sap.ui.commons.DropdownBox(util.Helper.getInputFieldId(sEquipmentFieldName), {
                            items: aSelectItems, 
                            selectedKey: sSelectedKey, 
                            change: jQuery.proxy(this.onEquipmentFieldChanged, that),
                            width: util.Helper.getWidthForElement(iItemLength)
                        });
                    }
                    else {
                        aSelectItems.push(new sap.ui.core.Item(util.Helper.getListItemResetFieldId(sEquipmentFieldName), { key: "", text: "" }));
                        sSelectedKey = "";
                        iItemLength = 0;
                        oEquipmentField.listItems.results.forEach(function(oValue, iIndex) {
                            iItemLength = (oValue.description.length > iItemLength ? oValue.description.length : iItemLength);
                            aSelectItems.push(new sap.ui.core.Item(util.Helper.getListItemFieldId(sEquipmentFieldName, iIndex), { key: oValue.value, text: oValue.description }));
                            if (!sSelectedKey && oValue.isSelected) {
                                sSelectedKey = oValue.value;
                            }
                        });
                        sInputType = "sap.m.Select";
                        oInput = new sap.m.Select(util.Helper.getInputFieldId(sEquipmentFieldName), { 
                            items: aSelectItems, 
                            selectedKey: sSelectedKey, 
                            change: jQuery.proxy(this.onEquipmentFieldChanged, that),
                            width: util.Helper.getWidthForElement(iItemLength)
                        });
                    }
                }
                else {
                    if (isDesktop) {
                        sInputType = "sap.ui.commons.TextField";
                        oInput = new sap.ui.commons.TextField(util.Helper.getInputFieldId(sEquipmentFieldName), { 
                            maxLength: parseInt(oEquipmentField.length), 
                            value: oEquipmentField.value, 
                            description: oEquipmentField.unit,
                            change: jQuery.proxy(this.onEquipmentFieldChanged, that),
                            liveChange: jQuery.proxy(this.onEquipmentFieldLiveChange, that),
                            width: util.Helper.getWidthForElement(oEquipmentField.length)
                        });
                    }
                    else {
                        sInputType = "sap.m.Input";
                        oInput = new sap.m.Input(util.Helper.getInputFieldId(sEquipmentFieldName), { 
                            maxLength: parseInt(oEquipmentField.length), 
                            value: oEquipmentField.value, 
                            description: oEquipmentField.unit,
                            change: jQuery.proxy(this.onEquipmentFieldChanged, that),
                            liveChange: jQuery.proxy(this.onEquipmentFieldLiveChange, that),
                            width: util.Helper.getWidthForElement(oEquipmentField.length)
                        });
                    }
                    oInput.attachBrowserEvent("focus", this.onTextFieldFocus, this);
                    this._registerForDestruction.push({elementName: util.Helper.getInputFieldId(sEquipmentFieldName), eventName: "focus", fnHandler: this.onTextFieldFocus});
                }
                break;
        }
        if (oLabel && oInput && sLabelType && sInputType) {
            this.createInitialEquipmentField(oLabel, oInput, sLabelType, sInputType, false, (aSelectItems.length ? aSelectItems : null), oEquipmentField);
        }
    },
	
	labelById: function(sLabelId) {
        jQuery.sap.log.debug("labelById(" + sLabelId + ")");
        return (this._formLabels[sLabelId] && this._formLabels[sLabelId].instance);
	},
	
	inputById: function(sInputId) {
        jQuery.sap.log.debug("inputById(" + sInputId + ")");
        return (this._formInputs[sInputId] && this._formInputs[sInputId].instance); 
	},

	inputSelectItemsById: function(sInputId) {
        jQuery.sap.log.debug("inputSelectItemsById(" + sInputId + ")");
        return (this._formInputs[sInputId] && this._formInputs[sInputId].selectItems); 
	},
	
	createInitialEquipmentField: function(oLabel, oInput, sLabelType, sInputType, bVisible, aSelectItems, oEquipmentField) {
        jQuery.sap.log.debug("createInitialEquipmentField(" + oLabel + "," + oInput + "," + sLabelType + "," + sInputType + "," + bVisible + "," + aSelectItems + "," + oEquipmentField + ")");
        oLabel.setVisible(false);
        oInput.setVisible(false);
        var sLabelId = oLabel.getId();
        this._formLabels[sLabelId] = {type: sLabelType, instance: oLabel}; 
        var sInputId = oInput.getId();
        var iMaxFractionDigits = (oEquipmentField.decimals !== "" ? parseInt(oEquipmentField.decimals) : 0);
        var iMaxIntegerDigits = parseInt(oEquipmentField.length) - iMaxFractionDigits;
        this._formInputs[sInputId] = {type: sInputType, instance: oInput, selectItems: aSelectItems, charType: oEquipmentField.type, maxIntegerDigits: iMaxIntegerDigits, maxFractionDigits: iMaxFractionDigits };
	},

    addEquipmentField: function(sFieldName, oLabel, oInput) {
        jQuery.sap.log.debug("addEquipmentField(" + sFieldName + "," + oLabel + "," + oInput + ")");
        var fAsset = this.getView().byId("fAsset");
        fAsset.addContent(oLabel);
        fAsset.addContent(oInput);
        this._formFields.push(sFieldName);
    },

    removeEquipmentField: function(sFieldName) {
        jQuery.sap.log.debug("removeEquipmentField(" + sFieldName + ")");
        var sLabelId = util.Helper.getLabelFieldId(sFieldName);
        var sInputId = util.Helper.getInputFieldId(sFieldName);
        var oLabel = this.labelById(sLabelId);
        var oInput = this.inputById(sInputId);
        var fAsset = this.getView().byId("fAsset");
        fAsset.removeContent(oLabel);
        fAsset.removeContent(oInput);
        oInput.setValue("");
        this._formFields.splice(this._formFields.indexOf(sFieldName), 1);
    },
    
	findEquipment: function(oEquipmentRequest, bForceRequest) {
        jQuery.sap.log.debug("findEquipment(" + oEquipmentRequest + "," + bForceRequest + ")");
        var opFindEquipmentData = sap.ui.getCore().getModel("opFindEquipmentData");
        if (!opFindEquipmentData || bForceRequest) {
            dao.EquipmentDAO.findEquipment(oEquipmentRequest, null, this.onFindEquipmentCompleted, this.onFindEquipmentFailed, this);
        }
    },

	onFindEquipmentCompleted: function() {
        jQuery.sap.log.debug("onFindEquipmentCompleted()");
        var opFindEquipmentData = sap.ui.getCore().getModel("opFindEquipmentData");
        if (opFindEquipmentData) {
            var oData = opFindEquipmentData.getData();
            if (oData && oData.d && oData.d.findEquipment) {
                var sId = oData.d.findEquipment.id;
                var sResourceId = this._gisParameters["resourceId".toUpperCase()];
                var bIsSplit = this._gisParameters["split".toUpperCase()] === "true";
                var oEquipmentRequest = dto.EquipmentRequest.getEquipmentKey(sId, sResourceId, bIsSplit);
                this.fetchFieldsForEquipment(oEquipmentRequest);
            }
        }
	},
	
	onFindEquipmentFailed: function(oEvent, oEquipmentRequest) {
        jQuery.sap.log.debug("onFindEquipmentFailed(" + oEvent + "," + oEquipmentRequest + ")");
        this.setBusy(false);
        var sStatusText = oEvent.getParameter("statusText");
        var iStatusCode = oEvent.getParameter("statusCode");
        var oResponse = JSON.parse(oEvent.getParameter("responseText")) || {};
        var sError = oResponse.error.message.value;
        var that = this;
        var aActions = (iStatusCode === 400 ? [sap.ui.commons.MessageBox.Action.CLOSE] : [sap.ui.commons.MessageBox.Action.RETRY, sap.ui.commons.MessageBox.Action.CLOSE]);
        sap.ui.commons.MessageBox.show(sError, sap.ui.commons.MessageBox.Icon.ERROR, sStatusText, aActions, 
            function(sResult) {
                that.onFindEquipmentFailedActionSelected(sResult, oEquipmentRequest);
            }, sap.ui.commons.MessageBox.Action.CLOSE);
	},

    onFindEquipmentFailedActionSelected: function(sResult, oEquipmentRequest) {
        jQuery.sap.log.debug("onFindEquipmentFailedActionSelected(" + sResult + "," + oEquipmentRequest + ")");
        if (sResult === "RETRY") {
            this.findEquipment(oEquipmentRequest, true);
        }
    },

	fetchFieldsForEquipment: function(oEquipmentRequest, bForceRequest) {
        jQuery.sap.log.debug("fetchFieldsForEquipment(" + oEquipmentRequest + "," + bForceRequest + ")");
        var opEquipmentData = sap.ui.getCore().getModel("opEquipmentData");
        if (!opEquipmentData || bForceRequest) {
            dao.EquipmentDAO.getEquipmentFields(oEquipmentRequest, null, this.onFetchFieldsForEquipmentCompleted, this.onFetchFieldsForEquipmentFailed, this);
        }
	},

	onFetchFieldsForEquipmentCompleted: function() {
        jQuery.sap.log.debug("onFetchFieldsForEquipmentCompleted()");
        var that = this;
        var opEquipmentData = sap.ui.getCore().getModel("opEquipmentData");
        if (opEquipmentData) {
            var oData = opEquipmentData.getData();
            var sParentId = this._gisParameters["parentId".toUpperCase()];
            if (oData.d.isInProcess && sParentId !== null && sParentId !== "") {
                this._inProcessEquipmentData = oData;
                var sResourceId = this._gisParameters["resourceId".toUpperCase()];
                var oEquipmentRequest = dto.EquipmentRequest.getEquipmentKey(sParentId, sResourceId);
                this.fetchFieldsForEquipment(oEquipmentRequest, true);
            }
            else {
                if (oData && oData.d && oData.d.charAttributes && oData.d.charAttributes.results) {
                    oData.d.charAttributes.results.forEach(function(oEquipmentField) {
                        that.createElementsForEquipmentField(oEquipmentField);
                    });
                    this.fetchFieldSettings(true);    // Initialize Form Data..
                }
                if (oData && oData.d && oData.d.notes) {
                    this.getView().byId("sNotes").setValue(oData.d.notes);
                }
            }
        }
	},
	
	onFetchFieldsForEquipmentFailed: function(oEvent, oEquipmentRequest) {
        jQuery.sap.log.debug("onFetchFieldsForEquipmentFailed(" + oEvent + "," + oEquipmentRequest + ")");
        this.setBusy(false);
        var sStatusText = oEvent.getParameter("statusText");
        var iStatusCode = oEvent.getParameter("statusCode");
        var oResponse = JSON.parse(oEvent.getParameter("responseText"));
        var sError = oResponse.error.message.value;
        var that = this;
        var aActions = (iStatusCode === 400 ? [sap.ui.commons.MessageBox.Action.CLOSE] : [sap.ui.commons.MessageBox.Action.RETRY, sap.ui.commons.MessageBox.Action.CLOSE]);
        sap.ui.commons.MessageBox.show(sError, sap.ui.commons.MessageBox.Icon.ERROR, sStatusText, aActions, 
            function(sResult) {
                that.onFetchFieldsForEquipmentActionSelected(sResult, oEquipmentRequest);
            }, sap.ui.commons.MessageBox.Action.CLOSE);
	},
	
    onFetchFieldsForEquipmentActionSelected: function(sResult, oEquipmentRequest) {
        jQuery.sap.log.debug("onFetchFieldsForEquipmentActionSelected(" + sResult + "," + oEquipmentRequest + ")");
        if (sResult === "RETRY") {
            this.fetchFieldsForEquipment(oEquipmentRequest, true);
        }
    },

	fetchFieldSettings: function(bIsSettingUp) {
        jQuery.sap.log.debug("fetchFieldSettings(" + bIsSettingUp + ")");
        var oEquipmentData = sap.ui.getCore().getModel("opEquipmentData").getData();
        var sClassId = oEquipmentData.d["class"].id;
        var sControlCharName = oEquipmentData.d["class"].controlCharName;
        var sControlCharInputId = util.Helper.getInputFieldId(sControlCharName);
        var sControlCharVal = this._getFieldValueForInput(sControlCharInputId);
        var aControls = (bIsSettingUp ? [dto.EquipmentFieldRequest.getEquipmentFieldControl(sControlCharName, sControlCharVal)] : this._getEquipmentFieldSettingsRequestControls());
        var aGisParameters = this._getBusinessRuleGisAttributes(sClassId);
        var oEquipmentFieldRequest = dto.EquipmentFieldRequest.getEquipmentFieldRequest(sClassId, sControlCharVal, aControls, aGisParameters);
        dao.EquipmentFieldsDAO.getEquipmentFieldSettings(oEquipmentFieldRequest, null, this.onFetchFieldSettingsForEquipmentCompleted, this.onFetchFieldSettingsForEquipmentFailed, this);
	},
	
	onFetchFieldSettingsForEquipmentCompleted: function() {
        jQuery.sap.log.debug("onFetchFieldSettingsForEquipmentCompleted()");
        var that = this;
        var _processedFields = [];
        var opEquipmentFieldsData = sap.ui.getCore().getModel("opEquipmentFieldsData");
        if (opEquipmentFieldsData) {
            var oData = opEquipmentFieldsData.getData();
            if (oData && oData.d && oData.d.fieldRules && oData.d.fieldRules.results) {
                oData.d.fieldRules.results.forEach(function(oEquipmentFieldSettings) {
                    that.setFieldSettings(oEquipmentFieldSettings.charName, true, (oEquipmentFieldSettings.isMandatory === "X"), oEquipmentFieldSettings.dropValuesFromList);
                    _processedFields.push(oEquipmentFieldSettings.charName);
                });
            }
        }
        var _removedFields = [];
        this._formFields.forEach(function(sFieldName) {
            if (_processedFields.indexOf(sFieldName) === -1) {
                _removedFields.push(sFieldName);
            }
        });
        _removedFields.forEach(function(sFieldName) {
            that.removeEquipmentField(sFieldName);
        });
        if (this._needsBusinessRulesRefresh) {
            this.fetchFieldSettings(false);
            this._needsBusinessRulesRefresh = false;
        }
        else {
            for (var sProperty in this._fieldSettingsBatchVisibility) {
                this._fieldSettingsBatchVisibility[sProperty]();
            }
            var oNotes = this.getView().byId("sNotes");
            oNotes.setVisible(this._isNotesVisible);
            this._fieldSettingsBatchVisibility = {};
            this.refreshClearButton();
            this.refreshSaveButton();
            this.setBusy(false);
        }
	},

	onFetchFieldSettingsForEquipmentFailed: function(oEvent, oEquipmentFieldRequest) {
        jQuery.sap.log.debug("onFetchFieldSettingsForEquipmentFailed(" + oEvent + "," + oEquipmentFieldRequest + ")");
        this.setBusy(false);
        var sStatusText = oEvent.getParameter("statusText");
        var iStatusCode = oEvent.gegetParameter("statusCode");
        var oResponse = JSON.parse(oEvent.getParameter("responseText"));
        var sError = oResponse.error.message.value;
        var that = this;
        var aActions = (iStatusCode === 400 ? [sap.ui.commons.MessageBox.Action.CLOSE] : [sap.ui.commons.MessageBox.Action.RETRY, sap.ui.commons.MessageBox.Action.CLOSE]);        
        sap.ui.commons.MessageBox.show(sError, sap.ui.commons.MessageBox.Icon.ERROR, sStatusText, aActions, 
            function(sResult) {
                that.onFieldSettingsForEquipmentFailedActionSelected(sResult, oEquipmentFieldRequest);
            }, sap.ui.commons.MessageBox.Action.CLOSE);
	},

    onFieldSettingsForEquipmentFailedActionSelected: function(sResult, oEquipmentFieldRequest) {
        jQuery.sap.log.debug("onFieldSettingsForEquipmentFailedActionSelected(" + sResult + "," + oEquipmentFieldRequest + ")");
        if (sResult === "RETRY") {
            var bIsSettingUp = (oEquipmentFieldRequest.charNameIn === "");
            this.fetchFieldSettings(bIsSettingUp);
        }
    },
    
    setFieldSettings: function(sFieldName, bVisible, bMandatory, sDropValuesFromList) {
        jQuery.sap.log.debug("setFieldSettings(" + sFieldName + "," + bVisible + "," + bMandatory + "," + sDropValuesFromList + ")");
        var sLabelId = util.Helper.getLabelFieldId(sFieldName);
        var sInputId = util.Helper.getInputFieldId(sFieldName);
        var oLabel = this.labelById(sLabelId);
        var oInput = this.inputById(sInputId);
        if (oLabel && oInput) {
            if (!this._isFormFieldCreated(sFieldName)) {
                this.addEquipmentField(sFieldName, oLabel, oInput);
            }
            var aInitialItems = this.inputSelectItemsById(sInputId);
            if (aInitialItems && aInitialItems.length) {
                var aCurrentItems = oInput.getItems();
                if (aInitialItems.length !== aCurrentItems.length) {
                    var sCurrentInputValue = oInput.getSelectedKey();
                    oInput.removeAllItems();
                    aInitialItems.forEach(function(oSelectItem, iIndex) {
                        oInput.addItem(oSelectItem);
                    });
                    if (sCurrentInputValue !== null && sCurrentInputValue !== "") {
                        oInput.setSelectedKey(sCurrentInputValue);
                    }
                }
            }
            if (sDropValuesFromList !== null && sDropValuesFromList !== "") {
                var aDropValues = sDropValuesFromList.split(",");
                aDropValues.forEach(function(sKey, iIndex) {
                    var oItemByKey = util.Helper.getSelectValueByKey(oInput, sKey);
                    if (oItemByKey) {
                        oInput.removeItem(oItemByKey);
                    }
                });
            }
            oLabel.setRequired(bMandatory);
            if (sap.ui.Device.system.desktop) {
                oInput.setRequired(bMandatory);
            }
            var bIsFieldVisible = (oLabel.getVisible() && oInput.getVisible());
            if (!this._needsBusinessRulesRefresh && !bIsFieldVisible && !this._fieldSettingsBatchVisibility[sFieldName] && oInput.getValue() !== "") {
                this._needsBusinessRulesRefresh = true;
            }
            this._fieldSettingsBatchVisibility[sFieldName] = function() {
                oLabel.setVisible(bVisible);
                oInput.setVisible(bVisible);
            };
        }
	},

    _isFieldValid: function(oEvent) {
        var bIsValid = true;
        var oSource = oEvent.getSource();
        var sEventSourceId = oSource.getId();
        var oFormField = this._formInputs[sEventSourceId];
        if (oFormField) {
            switch (oFormField.charType) {
                case "number":
                    var sFieldValue = this._getFieldValueForInput(sEventSourceId);
                    var oRegExp = new RegExp(oFormField.maxFractionDigits !== 0 ? "^\\d{0," + oFormField.maxIntegerDigits + "}(\\.\\d{1," + oFormField.maxFractionDigits + "})?$" : "^\\d{0," + oFormField.maxIntegerDigits + "}?$");
                    bIsValid = oRegExp.test(sFieldValue);
                    break;
                default:
                    bIsValid = !oEvent.getParameter("invalidValue");
                    break;
            }
        }
        return bIsValid;
    },
    
	onEquipmentFieldChanged: function(oEvent) {
        jQuery.sap.log.debug("onEquipmentFieldChanged(" + oEvent + ")");
        var oSource = oEvent.getSource();
        var sEventSourceId = oSource.getId();
        var bIsValid = this._isFieldValid(oEvent);
        if (sEventSourceId && bIsValid) {
            oSource.setValueState(sap.ui.core.ValueState.None);
            this.setBusy(true);
            var oEquipmentData = sap.ui.getCore().getModel("opEquipmentData").getData();
            var sControlCharName = oEquipmentData && oEquipmentData.d["class"].controlCharName;
            var sFieldName = util.Helper.getFieldIdForInput(sEventSourceId);
            var sFieldValue = this._getFieldValueForInput(sEventSourceId);
            var bIsSettingUp = (sFieldName === sControlCharName && sFieldValue === "");
            this.fetchFieldSettings(bIsSettingUp);
            if (sFieldName === sControlCharName) {
                this._isNotesVisible = (sFieldValue !== "");
            }
        }
        else {
            oSource.setValueState(sap.ui.core.ValueState.Error);
            oSource.focus();
            this.refreshSaveButton();
        }
	},

	onEquipmentFieldLiveChange: function(oEvent) {
        jQuery.sap.log.debug("onEquipmentFieldLiveChange(" + oEvent + ")");
        var sValue = this._textFieldFocusValue;
        var sLiveValue = oEvent.getParameters().liveValue;
        var bIsSaveEnabled = (sLiveValue === sValue);
        this.getView().byId("bSaveButton").setEnabled(bIsSaveEnabled);
	},
	
	refreshClearButton: function() {
        jQuery.sap.log.debug("refreshClearButton()");
        var bIsClearVisible = (this._gisParameters["parentId".toUpperCase()] !== null && this._gisParameters["parentId".toUpperCase()].trim() !== "");
        this.getView().byId("bClearButton").setVisible(bIsClearVisible);
	},

	refreshSaveButton: function() {
        jQuery.sap.log.debug("refreshSaveButton()");
        var bIsSaveEnabled = false;
        if (this._formFields && this._formFields.length) {
            bIsSaveEnabled = true;
            for (var i = 0; i < this._formFields.length; i++) {
                var sFieldName = this._formFields[i];
                var sLabelId = util.Helper.getLabelFieldId(sFieldName);
                var oLabel = this.labelById(sLabelId);
                var isRequired = oLabel.getRequired();
                if (isRequired) {
                    var sFieldValue = this._getFieldValueForInput(util.Helper.getInputFieldId(sFieldName));
                    if (sFieldValue === null || sFieldValue.trim() === "") {
                        bIsSaveEnabled = false;
                        break;
                    }
                }
                var sInputName = util.Helper.getInputFieldId(sFieldName);
                var oFormField = this._formInputs[sInputName];
                var bIsValid = (oFormField.instance.getValueState() !== sap.ui.core.ValueState.Error);
                if (!bIsValid) {
                    bIsSaveEnabled = false;
                }
            }
        }
        this.getView().byId("bSaveButton").setEnabled(bIsSaveEnabled);
	},

	onClearAsset: function() {
        jQuery.sap.log.debug("onClearAsset()");
        var that = this;
        sap.ui.commons.MessageBox.show("This action will clear all asset attributes. Do you want to continue?", sap.ui.commons.MessageBox.Icon.WARNING, "Clear Asset Attributes?", [sap.ui.commons.MessageBox.Action.YES, sap.ui.commons.MessageBox.Action.CANCEL], 
            function(sResult) {
                that.onClearAssetActionSelected(sResult);
            }, sap.ui.commons.MessageBox.Action.CANCEL);
	},

    onClearAssetActionSelected: function(sResult) {
        jQuery.sap.log.debug("onClearAssetActionSelected(" + sResult + ")");
        if (sResult === "YES") {
            this._clearAsset();
        }
    },
	
	_clearAsset: function() {
        jQuery.sap.log.debug("_clearAsset()");
        var oEquipmentData = sap.ui.getCore().getModel("opEquipmentData").getData();
        if (oEquipmentData && oEquipmentData.d.charAttributes && oEquipmentData.d.charAttributes.results) {
            var sControlCharName = oEquipmentData.d["class"].controlCharName;
            for (var sProperty in this._formInputs) {
                if (sProperty !== "i" + sControlCharName) {
                    this._formInputs[sProperty].instance.setValue("");
                }
            }
            this.fetchFieldSettings(true);
        }	    
	},
	
	onSaveAsset: function() {
        jQuery.sap.log.debug("onSaveAsset()");
        this.setBusy(true);
        var oEquipmentRequest = this.prepareSaveEquipmentRequest();
        dao.EquipmentDAO.saveEquipmentFields(oEquipmentRequest, null, this.onSaveFieldsForEquipmentCompleted, this.onSaveFieldsForEquipmentFailed, this);
	},

	onSaveFieldsForEquipmentCompleted: function(oEvent, oEquipmentRequest) {
        jQuery.sap.log.debug("onSaveFieldsForEquipmentCompleted(" + oEvent + "," + oEquipmentRequest + ")");
        var bSuccess = oEvent.getParameter("success");
        if (bSuccess) {
            sap.m.MessageToast.show("Saved!", { duration: 1000 });
            this._notifyArcGIS(true)
            this._refreshEquipmentData(oEquipmentRequest);
        }
        this.setBusy(false);
	},
	
	onSaveFieldsForEquipmentFailed: function(oEvent) {
        jQuery.sap.log.debug("onSaveFieldsForEquipmentFailed(" + oEvent + ")");
        this.setBusy(false);
        var sStatusText = oEvent.getParameter("statusText");
        var iStatusCode = oEvent.getParameter("statusCode");
        var oResponse = JSON.parse(oEvent.getParameter("responseText"));
        var sError = oResponse.error.message.value;
        var that = this;
        var aActions = (iStatusCode === 400 ? [sap.ui.commons.MessageBox.Action.CLOSE] : [sap.ui.commons.MessageBox.Action.RETRY, sap.ui.commons.MessageBox.Action.CLOSE]);        
        sap.ui.commons.MessageBox.show(sError, sap.ui.commons.MessageBox.Icon.ERROR, sStatusText, aActions, 
            function(sResult) {
                that.onSaveSettingsForEquipmentFailedActionSelected(sResult);
            }, sap.ui.commons.MessageBox.Action.CLOSE);
        this._notifyArcGIS(false);
	},
	
    onSaveSettingsForEquipmentFailedActionSelected: function(sResult) {
        jQuery.sap.log.debug("onSaveSettingsForEquipmentFailedActionSelected(" + sResult + ")");
        if (sResult === "RETRY") {
            this.onSaveAsset();
        }
    },
    
	prepareSaveEquipmentRequest: function() {
        jQuery.sap.log.debug("prepareSaveEquipmentRequest()");
        var oEquipmentRequest = this._getEquipmentRequestFromGisParameters();
        var opFindEquipmentData = sap.ui.getCore().getModel("opFindEquipmentData");
        if (opFindEquipmentData) {
            var oData = opFindEquipmentData.getData();
            if (oData && oData.d && oData.d.findEquipment) {
                oEquipmentRequest.id = oData.d.findEquipment.id;
            }
        }
        oEquipmentRequest.notes = this.getView().byId("sNotes").getValue();
        oEquipmentRequest.gisParameters = this._getEquipmentGisAttributes(oEquipmentRequest.id, oEquipmentRequest.resourceId);
        oEquipmentRequest.charAttributes = this._getEquipmentCharAttributes(oEquipmentRequest.id, oEquipmentRequest.resourceId);
        return oEquipmentRequest;
	},
	
	_getEquipmentGisAttributes: function(sEquipmentId, sResourceId) {
        jQuery.sap.log.debug("_getEquipmentGisAttributes(" + sEquipmentId + "," + sResourceId + ")");
        var aGisParameters = [];
        for (var sParameterName in this._gisParameters) {
            if (this._protectedParameters.indexOf(sParameterName) === -1) {
                aGisParameters.push(dto.GisEquipmentParameter.getGisEquipmentParameter(sEquipmentId, sResourceId, sParameterName, this._gisParameters[sParameterName]));
            }
        }
        return aGisParameters;
	},

	_getBusinessRuleGisAttributes: function(sClassId) {
        jQuery.sap.log.debug("_getBusinessRuleGisAttributes(" + sClassId + ")");
        var aGisParameters = [];
        for (var sParameterName in this._gisParameters) {
            if (this._protectedParameters.indexOf(sParameterName) === -1) {
                aGisParameters.push(dto.GisBusinessRuleParameter.getGisBusinessRuleParameter(sClassId, sParameterName, this._gisParameters[sParameterName]));
            }
        }
        return aGisParameters;
	},
	
    _getEquipmentCharAttributes: function(sEquipmentId, sResourceId) {
        jQuery.sap.log.debug("_getEquipmentCharAttributes(" + sEquipmentId + "," + sResourceId + ")");
        var aControls = [];
        for (var i = 0; i < this._formFields.length; i++) {
            var sFieldName = this._formFields[i];
            var sInputFieldId = util.Helper.getInputFieldId(sFieldName);
            var sFieldValue = this._getFieldValueForInput(sInputFieldId);
            var sFieldType = this._formInputs[sInputFieldId].charType;
            var bIsCopying = (this._gisParameters["parentId".toUpperCase()] !== null && this._gisParameters["parentId".toUpperCase()].trim() !== "");
            var bModified = (bIsCopying || this._wasEquipmentCharAttributeModified(sFieldName, sFieldValue, sFieldType));
            if (bModified) {
                var oControl = dto.CharAttribute.getCharAttribute(sEquipmentId, sResourceId, sFieldName, sFieldValue, sFieldType);
                aControls.push(oControl);
            }
        }
        return aControls;
    },
    
    _wasEquipmentCharAttributeModified: function(sName, sValue, sType) {
        jQuery.sap.log.debug("_notifyArcGIS(" + sName + "," + sValue + "," + sType + ")");
        var oEquipmentData = sap.ui.getCore().getModel("opEquipmentData").getData();
        if (oEquipmentData && oEquipmentData.d.charAttributes && oEquipmentData.d.charAttributes.results) {
            var oCharAttribute;
            for (var i = 0; i < oEquipmentData.d.charAttributes.results.length; i++) {
                oCharAttribute = oEquipmentData.d.charAttributes.results[i];
                if (oCharAttribute.name === sName) {
                    return (sType === "number" ? parseFloat($.isNumeric(oCharAttribute.value) ? oCharAttribute.value : 0) !== parseFloat($.isNumeric(sValue) ? sValue : 0) : oCharAttribute.value !== sValue);
                }
            }
        }
        return false;
    },
    
    _notifyArcGIS: function(bSaveEquipmentResult) {
        jQuery.sap.log.debug("_notifyArcGIS(" + bSaveEquipmentResult + ")");
        if (window.top.postMessage) {
            window.top.postMessage({"succeeded": bSaveEquipmentResult}, "*");
        }
    },
    
    _refreshEquipmentData: function(oEquipmentRequest) {
        jQuery.sap.log.debug("_refreshEquipmentData(" + oEquipmentRequest + ")");
        var oEquipmentData = sap.ui.getCore().getModel("opEquipmentData").getData();
        if (oEquipmentData && oEquipmentData.d.charAttributes && oEquipmentData.d.charAttributes.results) {
            var sControlCharName = oEquipmentData.d["class"].controlCharName;
            var aCharAttributeNames = [];
            var aCharAttributeValues = [];
            for (var i = 0; i < oEquipmentRequest.charAttributes.length; i++) {
                var oCharAttribute = oEquipmentRequest.charAttributes[i];
                if (sControlCharName !== oCharAttribute.name) {
                    aCharAttributeNames.push(oCharAttribute.name);
                    aCharAttributeValues.push(oCharAttribute.value);
                }
            }
            oEquipmentData.d.charAttributes.results.forEach(function(oCharAttribute) {
                var iAttributeIndex = aCharAttributeNames.indexOf(oCharAttribute.name);
                if (iAttributeIndex !== -1) {
                    oCharAttribute.value = aCharAttributeValues[iAttributeIndex];
                }
            });
        }
    }

});