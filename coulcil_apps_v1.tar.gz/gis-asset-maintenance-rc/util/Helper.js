jQuery.sap.declare("util.Helper");

util.Helper = {

    getWindowParameter: function(sParameterName) {
        var aResults = new RegExp('[\\?&]' + sParameterName + '=([^&#]*)', 'i').exec(window.location.href);
        if (aResults && aResults.length ===  2) {
            return aResults[1];
        }
        return null;
    },

    getLabelFieldId: function(sFieldName) {
        return "l" + sFieldName;
    },
    
    getInputFieldId: function(sFieldName) {
        return "i" + sFieldName;
    },

    getFieldIdForInput: function(sInputId) {
        return sInputId.substring(1, sInputId.length);
    },

    getListItemResetFieldId: function(sFieldName) {
        return "iItem_" + sFieldName + "_Reset";
    },
    
    getListItemFieldId: function(sFieldName, iIndex) {
        return "iItem_" + sFieldName + "_" + iIndex;
    },
    
    getInputFieldValue: function(sFieldName) {
        var oInput = sap.ui.getCore().byId(this.getInputFieldId(sFieldName));
        return (oInput ? oInput.getValue() : null);
    },
    
    getWidthForElement: function(sMaxLength) {
        var iWidth = ((8 * parseInt(sMaxLength)) + 26);
        return (iWidth > $(window).width() - 44 ? "auto" : iWidth + "px");
    },

    getWidthForDatePicker: function() {
        return "160px";
    },
    
    getSelectValueByKey: function(oInput, sKey) {
        if (oInput) {
            var aSelectItems = oInput.getItems();
            for (var i = 0; i < aSelectItems.length; i++) {
                if (aSelectItems[i].getKey() === sKey) {
                    return aSelectItems[i];
                }
            }
        }
        return null;
    },
    
    getDate: function(sDate) {
        return (sDate !== "" ? sDate.substr(6, 2) + "/" + sDate.substr(4, 2) + "/" + sDate.substr(0, 4) : "");
    }
    
}