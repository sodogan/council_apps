jQuery.sap.declare("util.Mock");



util.Mock = {



}