jQuery.sap.declare("mock.EquipmentDAO");

mock.EquipmentDAO = {

    getServicePath: function(oEquipmentRequest) {
        if (oEquipmentRequest) {
            if (oEquipmentRequest.gisId === "{7672aac8-fa0b-464c-b0b8-3efa9ae9cd88}" && oEquipmentRequest.operationalAreaCode === "C" && oEquipmentRequest.localBoardCode === "100" && oEquipmentRequest.resourceId === "002" && oEquipmentRequest.geometryType === "POLYGON") {
                return "/mock/getEquipment-Step01.json";
            }
        }
        return "/mock/getEquipment-NotFound.json";
    },
    
    postHeaders: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": "Basic R0lTX0RFVjphQyQkZ2lzJCRkMQ==",
        "X-Requested-With": "XMLHttpRequest"
    },
    
    getEquipmentFields: function(oEquipmentRequest, fnRequestSent, fnRequestCompleted, fnRequestFailed, oContext) {
        var oEquipmentModel = new sap.ui.model.json.JSONModel();
        if (fnRequestSent) {
            oEquipmentModel.attachRequestSent(null, fnRequestSent, oContext);
        }
        if (fnRequestCompleted) {
            oEquipmentModel.attachRequestCompleted(null, fnRequestCompleted, oContext);
        }
        if (fnRequestFailed) {
            oEquipmentModel.attachRequestFailed(oEquipmentRequest, fnRequestFailed, oContext);
        }
        sap.ui.getCore().setModel(oEquipmentModel, "opEquipmentData");
        if (oEquipmentRequest) {
            var endPoint = this.getServicePath(oEquipmentRequest);
            oEquipmentModel.loadData(endPoint, JSON.stringify(oEquipmentRequest), true, "GET", false, false, this.postHeaders);
        }
        return oEquipmentModel; // Allow Method-Chaining..
    }

}