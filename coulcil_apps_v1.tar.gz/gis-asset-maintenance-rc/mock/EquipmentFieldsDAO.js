jQuery.sap.declare("mock.EquipmentFieldsDAO");



mock.EquipmentFieldsDAO = {



    getServicePath: function(oEquipmentFieldRequest) {

        if (oEquipmentFieldRequest) {

            switch (oEquipmentFieldRequest["class"]) {

                case "ZSW_CPIT":

                    if (oEquipmentFieldRequest.controlCharVal === "" && oEquipmentFieldRequest.charNameIn === "" && oEquipmentFieldRequest.charVal === "") {

                        return "/mock/getEquipmentFieldSettings-Step01.json";

                    }

                    if (oEquipmentFieldRequest.controlCharVal === "VALI" && oEquipmentFieldRequest.charNameIn === "" && oEquipmentFieldRequest.charVal === "") {

                        return "/mock/getEquipmentFieldSettings-Step02.json";

                    }

                    if (oEquipmentFieldRequest.controlCharVal === "VALI" && oEquipmentFieldRequest.charNameIn === "SW_MATERIAL_CPIT" && oEquipmentFieldRequest.charVal === "CONC") {

                        return "/mock/getEquipmentFieldSettings-Step03.json";

                    }

                    if (oEquipmentFieldRequest.controlCharVal === "VALI" && oEquipmentFieldRequest.charNameIn === "SW_MATERIAL_CPIT" && oEquipmentFieldRequest.charVal === "") {

                        return "/mock/getEquipmentFieldSettings-Step04.json";

                    }

                    break;

            }

        }

        return "/mock/getEquipmentFieldSettings-NotFound.json";

    },

    

    postHeaders: {

        "Content-Type": "application/json",

        "Accept": "application/json",

        "Authorization": "Basic R0lTX0RFVjphQyQkZ2lzJCRkMQ==",

        "X-Requested-With": "XMLHttpRequest"

    },

    

    getEquipmentFieldSettings: function(oEquipmentFieldRequest, fnRequestSent, fnRequestCompleted, fnRequestFailed, oContext) {

        console.debug("getEquipmentFieldSettings[" + JSON.stringify(oEquipmentFieldRequest) + "]");

        var oEquipmentFieldsModel = new sap.ui.model.json.JSONModel();

        if (fnRequestSent) {

            oEquipmentFieldsModel.attachRequestSent(null, fnRequestSent, oContext);

        }

        if (fnRequestCompleted) {

            oEquipmentFieldsModel.attachRequestCompleted(null, fnRequestCompleted, oContext);

        }

        if (fnRequestFailed) {

            oEquipmentFieldsModel.attachRequestFailed(oEquipmentFieldRequest, fnRequestFailed, oContext);

        }

        sap.ui.getCore().setModel(oEquipmentFieldsModel, "opEquipmentFieldsData");

        if (oEquipmentFieldsModel) {

            var endPoint = this.getServicePath(oEquipmentFieldRequest);

            if (endPoint !== "/mock/getEquipmentFieldSettings-NotFound.json") {

                oEquipmentFieldsModel.loadData(endPoint, JSON.stringify(oEquipmentFieldRequest), true, "GET", false, false, this.postHeaders);

            }

        }

        return oEquipmentFieldsModel; // Allow Method-Chaining..

    }



}