jQuery.sap.declare("dao.EquipmentFieldsDAO");



dao.EquipmentFieldsDAO = {



    _hasCSRFToken: false,

    

    getServicePath: function(sSuffix) {

        return "/sap/opu/odata/sap/ZPM_GIS_ASSET_SRV" + sSuffix;

        // return "http://vsapxd1ap1.aklc.govt.nz:8003/sap/opu/odata/sap/ZPM_GIS_ASSET_SRV" + sSuffix;

    },

    

    postHeaders: {

        "Content-Type": "application/json",

        "Accept": "application/json",

        "X-Requested-With": "XMLHttpRequest"

    },

    

    fetchCSRFToken: function(oEquipmentFieldRequest) {

        var that = this;

        var endPoint = this.getServicePath("/businessRuleSet('" + oEquipmentFieldRequest.classId + "')");

        $.ajax({

            url: endPoint,

            async: false,

            beforeSend: function(oRequest) {

                oRequest.setRequestHeader("X-CSRF-Token", "Fetch");

            }

        })

        .always(

            function(oResponseText, statusText, oResponse) {

                that.postHeaders["X-CSRF-Token"] = oResponse.getResponseHeader("X-CSRF-Token")

                that._hasCSRFToken = true;

            }

        );

    }, 

    

    getEquipmentFieldSettings: function(oEquipmentFieldRequest, fnRequestSent, fnRequestCompleted, fnRequestFailed, oContext) {

        if (!this._hasCSRFToken) {

            this.fetchCSRFToken(oEquipmentFieldRequest);

        }

        var oEquipmentFieldsModel = new sap.ui.model.json.JSONModel();

        if (fnRequestSent) {

            oEquipmentFieldsModel.attachRequestSent(null, fnRequestSent, oContext);

        }

        if (fnRequestCompleted) {

            oEquipmentFieldsModel.attachRequestCompleted(null, fnRequestCompleted, oContext);

        }

        if (fnRequestFailed) {

            oEquipmentFieldsModel.attachRequestFailed(oEquipmentFieldRequest, fnRequestFailed, oContext);

        }

        sap.ui.getCore().setModel(oEquipmentFieldsModel, "opEquipmentFieldsData");

        if (oEquipmentFieldsModel) {

            var endPoint = this.getServicePath("/businessRuleSet");

            oEquipmentFieldsModel.loadData(endPoint, JSON.stringify(oEquipmentFieldRequest), true, "POST", false, false, this.postHeaders);

        }

        return oEquipmentFieldsModel; // Allow Method-Chaining..

    }



}