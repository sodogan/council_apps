jQuery.sap.declare("dao.EquipmentDAO");

dao.EquipmentDAO = {

    getServicePath: function(sSuffix) {
        return "/sap/opu/odata/sap/ZPM_GIS_ASSET_SRV" + sSuffix;
        // return "http://vsapxd1ap1.aklc.govt.nz:8003/sap/opu/odata/sap/ZPM_GIS_ASSET_SRV" + sSuffix;
    },
    
    postHeaders: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-Requested-With": "XMLHttpRequest"
    },
    
    fetchCSRFToken: function(oEquipmentRequest) {
        var that = this;
        var endPoint = this.getServicePath("/equipmentUpdateSet(id='" + oEquipmentRequest.id + "',resourceId='" + oEquipmentRequest.resourceId + "')");
        $.ajax({
            url: endPoint,
            async: false,
            beforeSend: function(oRequest) {
                oRequest.setRequestHeader("X-CSRF-Token", "Fetch");
            }
        })
        .always(
            function(oResponseText, statusText, oResponse) {
                that.postHeaders["X-CSRF-Token"] = oResponse.getResponseHeader("X-CSRF-Token")
            }
        );
    },
    
    getEquipmentFields: function(oEquipmentRequest, fnRequestSent, fnRequestCompleted, fnRequestFailed, oContext) {
        var oEquipmentModel = new sap.ui.model.json.JSONModel();
        if (fnRequestSent) {
            oEquipmentModel.attachRequestSent(null, fnRequestSent, oContext);
        }
        if (fnRequestCompleted) {
            oEquipmentModel.attachRequestCompleted(null, fnRequestCompleted, oContext);
        }
        if (fnRequestFailed) {
            oEquipmentModel.attachRequestFailed(oEquipmentRequest, fnRequestFailed, oContext);
        }
        sap.ui.getCore().setModel(oEquipmentModel, "opEquipmentData");
        if (oEquipmentRequest) {
            var endPoint = this.getServicePath("/equipmentSet(id='" + oEquipmentRequest.id + "',resourceId='" + oEquipmentRequest.resourceId + "')");
            oEquipmentModel.loadData(endPoint, "$filter=(isSplit eq " + oEquipmentRequest.isSplit + ")&$expand=charAttributes,charAttributes/listItems", true, "GET", false, false, this.postHeaders);
        }
        return oEquipmentModel; // Allow Method-Chaining..
    },

    saveEquipmentFields: function(oEquipmentRequest, fnRequestSent, fnRequestCompleted, fnRequestFailed, oContext) {
        this.fetchCSRFToken(oEquipmentRequest);
        var oEquipmentModel = new sap.ui.model.json.JSONModel();
        if (fnRequestSent) {
            oEquipmentModel.attachRequestSent(null, fnRequestSent, oContext);
        }
        if (fnRequestCompleted) {
            oEquipmentModel.attachRequestCompleted(oEquipmentRequest, fnRequestCompleted, oContext);
        }
        if (fnRequestFailed) {
            oEquipmentModel.attachRequestFailed(oEquipmentRequest, fnRequestFailed, oContext);
        }
        sap.ui.getCore().setModel(oEquipmentModel, "opSavedEquipmentData");
        if (oEquipmentRequest) {
            var endPoint = this.getServicePath("/equipmentUpdateSet");
            oEquipmentModel.loadData(endPoint, JSON.stringify(oEquipmentRequest), true, "POST", false, false, this.postHeaders);
        }
        return oEquipmentModel; // Allow Method-Chaining..
    },

    findEquipment: function(oEquipmentRequest, fnRequestSent, fnRequestCompleted, fnRequestFailed, oContext) {
        var oEquipmentModel = new sap.ui.model.json.JSONModel();
        if (fnRequestSent) {
            oEquipmentModel.attachRequestSent(null, fnRequestSent, oContext);
        }
        if (fnRequestCompleted) {
            oEquipmentModel.attachRequestCompleted(null, fnRequestCompleted, oContext);
        }
        if (fnRequestFailed) {
            oEquipmentModel.attachRequestFailed(oEquipmentRequest, fnRequestFailed, oContext);
        }
        sap.ui.getCore().setModel(oEquipmentModel, "opFindEquipmentData");
        if (oEquipmentRequest) {
            var endPoint = this.getServicePath("/findEquipment");
            oEquipmentModel.loadData(endPoint, this._getFindEquipmentParameters(oEquipmentRequest), true, "GET", false, false, this.postHeaders);
        }
        return oEquipmentModel; // Allow Method-Chaining..
    },
    
    _getFindEquipmentParameters: function(oEquipmentRequest) {
        return "gisId='" + oEquipmentRequest.gisId + "'" + 
                "&operationalAreaCode='" + oEquipmentRequest.operationalAreaCode + "'" + 
                 "&localBoardCode='" + oEquipmentRequest.localBoardCode + "'" +
                  "&resourceId='" + oEquipmentRequest.resourceId + "'" + 
                   "&geometryType='" + oEquipmentRequest.geometryType + "'" + 
                    "&facilityId='" + oEquipmentRequest.facilityId + "'" + 
                     "&sourceDocUrl='" + oEquipmentRequest.sourceDocUrl + "'";
    }

}