jQuery.sap.declare("dto.GisEquipmentParameter");



dto.GisEquipmentParameter = {



    getGisEquipmentParameter: function(sEquipmentId, sResourceId, sName, sValue) {

        var oGisParameter = {};

        oGisParameter.equipmentId = sEquipmentId || "";

        oGisParameter.resourceId = sResourceId || "";

        oGisParameter.name = sName || "";

        oGisParameter.value = sValue || "";

        return oGisParameter;

    }



}