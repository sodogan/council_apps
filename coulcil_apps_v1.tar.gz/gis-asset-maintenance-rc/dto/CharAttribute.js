jQuery.sap.declare("dto.CharAttribute");



dto.CharAttribute = {



    getCharAttribute: function(sEquipmentId, sResourceId, sName, sValue, sType) {

        var oCharAttribute = {};

        oCharAttribute.equipmentId = sEquipmentId || "";

        oCharAttribute.resourceId = sResourceId || "";

        oCharAttribute.name = sName || "";

        oCharAttribute.value = sValue || "";

        oCharAttribute.type = sType || "";

        return oCharAttribute;

    }



}