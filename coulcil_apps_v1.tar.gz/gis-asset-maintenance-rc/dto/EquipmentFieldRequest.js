jQuery.sap.declare("dto.EquipmentFieldRequest");



dto.EquipmentFieldRequest = {



    getEquipmentFieldRequest: function(sClass, sControlCharVal, aControls, aGisParameters, aRules) {

        var oEquipmentFieldRequest = {};

        oEquipmentFieldRequest.classId = sClass || "";

        oEquipmentFieldRequest.controlCharValue = sControlCharVal || "";

        oEquipmentFieldRequest.fieldValues = aControls || [];

        oEquipmentFieldRequest.gisParameters = aGisParameters || [];

        oEquipmentFieldRequest.fieldRules = aRules || [];

        return oEquipmentFieldRequest;

    },

    

    getEquipmentFieldControl: function(sCharName, sCharValue) {

        var oControl = {};

        oControl.charName = sCharName || "";

        oControl.charValue = sCharValue || "";

        return oControl;

    }

    

}