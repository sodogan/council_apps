jQuery.sap.declare("dto.GisBusinessRuleParameter");



dto.GisBusinessRuleParameter = {



    getGisBusinessRuleParameter: function(sClassId, sName, sValue) {

        var oGisParameter = {};

        oGisParameter.classId = sClassId || "";

        oGisParameter.name = sName || "";

        oGisParameter.value = sValue || "";

        return oGisParameter;

    }



}