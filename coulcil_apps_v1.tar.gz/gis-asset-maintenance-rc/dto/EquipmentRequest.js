jQuery.sap.declare("dto.EquipmentRequest");

dto.EquipmentRequest = {

    getEquipmentKey: function(sId, sResourceId, bIsSplit) {
        var oEquipmentKey = {};
        oEquipmentKey.id = sId || "";
        oEquipmentKey.resourceId = sResourceId || "";
        oEquipmentKey.isSplit = bIsSplit || false;
        return oEquipmentKey;
    },
    
    getEquipmentRequest: function(sId, sGisId, sOperationalAreaCode, sLocalBoardCode, sResourceId, sGeometryType, sFacilityId, sSourceDocUrl, sNotes, bIsSplit) {
        var oEquipmentRequest = {};
        oEquipmentRequest.id = sId || "";
        oEquipmentRequest.gisId = sGisId || "";
        oEquipmentRequest.operationalAreaCode = sOperationalAreaCode || "";
        oEquipmentRequest.localBoardCode = sLocalBoardCode || "";
        oEquipmentRequest.resourceId = sResourceId || "";
        oEquipmentRequest.geometryType = sGeometryType || "";
        oEquipmentRequest.facilityId = sFacilityId || "";
        oEquipmentRequest.sourceDocUrl = sSourceDocUrl || "";
        oEquipmentRequest.notes = sNotes || "";
        oEquipmentRequest.isSplit = bIsSplit || false;
        return oEquipmentRequest;
    }

}