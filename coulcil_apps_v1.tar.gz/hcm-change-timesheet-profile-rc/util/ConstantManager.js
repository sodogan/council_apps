sap.ui.define([], function() {
	"use strict";
	return {

		/**
		 * Intializes Constant object and return itself
		 * @public
		 * @returns {nz.govt.aklc.timesheet.profilechangeutil.ConstantManager} instance of this object
		 */
		createConstantObject: function() {
			this._initialize();
			return this;
		},

		/**
		 * Get User Profile Parameter
		 * @public
		 * @returns {string} User Profile Parameter
		 */
		getUserProfileParameter: function() {
			return this.sUserProfileParam;
		},

		/**
		 * Intializes Constants
		 * @rivate
		 */
		_initialize: function() {
			this.sUserProfileParam = "CVR";
		}
	};

});