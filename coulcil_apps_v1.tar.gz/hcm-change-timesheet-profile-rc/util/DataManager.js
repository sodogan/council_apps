sap.ui.define([], function() {
	"use strict";
	return {
	 /**
	 * On Select of Item Event
	 * @param {view} oEvent the list selectionChange event
	 * @public
	 */
	 getUserParameter: function(oModel, sParid, fSuccess) {
			oModel.read("/UserParameters(Parid='" + sParid + "')", {
				async: false,
				success: fSuccess
			});

		},
		saveUserParameter: function(oModel, oData , fSuccess) {
			oModel.create("/UserParameters", oData,{
				async: false,
				success: fSuccess
			});

		},
		getProfiles: function(oModel, fSuccess) {
			oModel.read("/UserProfiles", {
				async: false,
				success: fSuccess
			});

		}
	};

});