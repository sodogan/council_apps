/*global history */
sap.ui.define([
  "nz/govt/aklc/timesheet/profilechange/controller/BaseController",
  "sap/ui/model/json/JSONModel",
  "sap/ui/core/routing/History",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/ui/Device",
  "nz/govt/aklc/timesheet/profilechange/util/DataManager",
  "nz/govt/aklc/timesheet/profilechange/util/ConstantManager",
  "nz/govt/aklc/timesheet/profilechange/controller/ErrorHandler"
], function(BaseController, JSONModel, History, Filter, FilterOperator, Device, DataManager, ConstantManager,ErrorHandler) {
  "use strict";

  return BaseController.extend("nz.govt.aklc.timesheet.profilechange.controller.ProfileList", {

    /* =========================================================== */
    /* lifecycle methods                                           */
    /* =========================================================== */

    /**
     * Called when the master list controller is instantiated. It sets up the event handling for the master/detail communication and other lifecycle tasks.
     * @public
     */
    onInit: function() {

        this._initializeAttributes();


      this.getView().addEventDelegate({
        onBeforeRendering: function() {
        this.getView().setBusy(true);
        this._oErrorHandler = new ErrorHandler(this); // Initialize error handler for window (MODEL)
        }.bind(this)
      });

      this.getView().addEventDelegate({
        onAfterRendering: function() {

          DataManager.getUserParameter(this.getModel(), this.oConstant.getUserProfileParameter(), function(oData) { // Load User parameter for Profile and initialize List
            this.sCurrentUserProfileParam = oData.Parva;
            this._initList(); // Initialize List with Filter by User.
          }.bind(this));
        }.bind(this)
      });
    },

    /* =========================================================== */
    /* event handlers                                              */
    /* =========================================================== */

    /**
     * Update List Counter after it is filled with data
     * @param {sap.ui.base.Event} oEvent the update finished event
     * @public
     */
    onUpdateFinished: function(oEvent) {
      // update the master list object counter after new data is loaded
      this._updateListItemCount(oEvent.getParameter("total"));

    },

    /**
     * Event handler for navigating back.
     * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
     * If not, it will navigate to the shell home
     * @public
     */
    onNavBack: function() {
      var sPreviousHash = History.getInstance().getPreviousHash(),
        oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

      if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
        history.go(-1);
      } else {
        oCrossAppNavigator.toExternal({
          target: {
            shellHash: "#Shell-home"
          }
        });
      }
    },

    /**
     * Event handler for show all Profiles. Removes filter from List!
     * @param {sap.ui.base.Event}
     */
    onShowAllProfiles: function(oEvent) {
      this._clearFilterList();
    },

    /**
     * Event handler for show default Profile. 
     * @public
     */
    onDefaultProfile: function(oEvent) {
      this._filterList();
    },

    /**
     * Event handler for show default Profile. 
     * @public
     */
    onSelectProfile: function(oEvent) {

      // get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
              var context = oEvent.getSource().getBindingContext();
            var dataMessage = JSON.parse(JSON.stringify(context.getObject()));



      var oDataParam = {
        Parid: this.oConstant.getUserProfileParameter(),
        Parva: dataMessage.Variant
      };

      DataManager.saveUserParameter(this.getModel(), oDataParam, function(oData) {
        var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

        oCrossAppNavigator.toExternal({
          target: {
            shellHash: "#TimeEntry-manage"
          }
        });
      }.bind(this));

    },

    /* =========================================================== */
    /* begin: internal methods                                     */
    /* =========================================================== */

    /**
     * Initialize Attributes of View Object
     * @private
     */
    _initializeAttributes: function() {
      this.oConstant = ConstantManager.createConstantObject(); // Constants
      this._oList = this.byId("list"); // List
      this.setModel(this._createViewModel(), "masterView"); // MasterView Model ( eg. Title etc )
    },

    /**
     * Create View Model ( Master )
     * @private
     */
    _createViewModel: function() {
      return new JSONModel({
        isFilterBarVisible: false,
        filterBarLabel: "",
        delay: 0,
        title: this.getResourceBundle().getText("masterTitleCount", [0]),
        noDataText: this.getResourceBundle().getText("masterListNoDataText"),
        sortBy: "Text",
        groupBy: "None"
      });
    },

    /**
     * Initializes List
     * @public
     */
    _initList: function(userparam) {

      DataManager.getProfiles(this.getModel(), function(oData) {
        var model = new JSONModel({
          profiles: oData.results
        });
        this._oList.setModel(model);

        this._oList.bindAggregation("items", "/profiles", new sap.m.StandardListItem({
          title: "{Text}",
          type: "Navigation",
          press: function(oEvent) {
            this.onSelectProfile(oEvent);
          }.bind(this)
        }));

        this._filterList();
        this.getView().setBusy(false);

      }.bind(this));
    },

    /**
     * Filter List
     * @private
     */
    _filterList: function() {
      var oFilters = [];
      var oParamFilter = new sap.ui.model.Filter("Variant", sap.ui.model.FilterOperator.EQ, this.sCurrentUserProfileParam);
      oFilters.push(oParamFilter);
      var binding = this._oList.getBinding("items");
      binding.filter(oFilters);
    },

    /**
     * Remove Filter from List
     * @private
     */
    _clearFilterList: function() {
      var binding = this._oList.getBinding("items");
      binding.filter([]);
    },

    /**
     * Sets the item count on the master list header
     * @param {integer} iTotalItems the total number of items in the list
     * @private
     */
    _updateListItemCount: function(iTotalItems) {
      var sTitle;
      // only update the counter if the length is final
      if (this._oList.getBinding("items").isLengthFinal()) {
        sTitle = this.getResourceBundle().getText("masterTitleCount", [iTotalItems]);
        this.getModel("masterView").setProperty("/title", sTitle);
      }
    }

  });

});