sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"team/zag/components/scheduling/SchedulingApp/model/models",
	"team/zag/library/scheduling/utils/MessageHelper",
	"team/zag/library/scheduling/utils/lodash.min",
	"./utils/Constants"
], function (UIComponent, Device, models, MessageHelper, lodash, Constants) {
	"use strict";

	return UIComponent.extend("team.zag.components.scheduling.SchedulingApp.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			UIComponent.prototype.init.apply(this, arguments);
			this.setModel(models.createDeviceModel(), "device");
			this.registerRequestFailedHandler();
		},

		exit: function() {
			this.unregisterRequestFailedHandler();
		},

		onBeforeRendering: function() {
			var oModel = this.getModel();
			oModel.getMetaModel().loaded()
				.then(this.initializeRouter.bind(this));
			this.onMetadataLoaded(oModel)
				.then(this.initializeRouter.bind(this))
			.catch(this.onMetadataFailed.bind(this));
			const oChangeGroups = oModel.getChangeGroups();
			oChangeGroups["Calendar"] = {
				groupId: Constants.ENROLMENT_SUBMISSION_GROUP_ID
			};
			oChangeGroups["Enrolment"] = {
				groupId: Constants.ENROLMENT_SUBMISSION_GROUP_ID
			};
			oModel.setChangeGroups(oChangeGroups);
			var aDeferredGroups = oModel.getDeferredGroups();
			oModel.setDeferredGroups(aDeferredGroups.concat(Constants.ENROLMENT_SUBMISSION_GROUP_ID));
		},

		onMetadataLoaded: function(oModel) {
			return new Promise(function(fnResolve, fnReject) {
				oModel.attachEventOnce("metadataLoaded", fnResolve);
				oModel.attachEventOnce("metadataFailed", fnReject);
			});
		},

		onMetadataFailed: function() {
			var sMetadataFailedError = this.getModel("i18n").getResourceBundle().getText("metadataFailed");
			MessageHelper.showErrorMessage({message: sMetadataFailedError, response: {}}, this.getModel("i18n").getResourceBundle().getText("appErrorTitle"));
		},

		initializeRouter: function() {
			var oRouter = this.getRouter();
			oRouter.initialize();
		},

		showErrorMessage: function(oResponse) {
			MessageHelper.showErrorMessage(oResponse, this.getModel("i18n").getResourceBundle().getText("appErrorTitle"));
		},

		registerRequestFailedHandler: function() {
			var oModel = this.getModel();
			oModel.attachRequestFailed(this._requestFailed, this);
		},

		unregisterRequestFailedHandler: function() {
			var oModel = this.getModel();
			oModel.detachRequestFailed(this._requestFailed, this);
		},

		_requestFailed: function(oError) {
			var oResourceBundle = this.getModel("i18n").getResourceBundle();
			MessageHelper.showErrorMessage(oError, oResourceBundle.getText("appErrorDialogTitle"));
		}

	});
});