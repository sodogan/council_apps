sap.ui.define([
	"sap/ui/core/Core",
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"team/zag/library/scheduling/utils/CalendarUtils",
	"team/zag/components/scheduling/SchedulingApp/utils/Formatter",
	"sap/ui/Device",
	"sap/m/MessageToast",
	"sap/ui/core/routing/History"
], function (Core, BaseController, JSONModel, Filter, CalendarUtils, Formatter, Device, MessageToast, History) {
	"use strict";

	return BaseController.extend("team.zag.components.scheduling.SchedulingApp.controller.Main", {

		Formatter: Formatter,

		_iCalendarLiveSearchDebounce: undefined,

		onInit: function() {
			Core.getConfiguration().getFormatSettings().setFirstDayOfWeek(6);
			var oViewModel = new JSONModel({
				"selectedCalendar": CalendarUtils.CALENDAR.MY_TEAM,
				"selectedCalendarViewType": -1,
				"selectedCalendarQueryFilter": "",
				"selectedInterval": {
					"startDate": undefined,
					"endDate": undefined
				},
				"selectedAppointment": undefined,
				"selectedEmployee": undefined,
				"currentEmployee": undefined
			});
			var oView = this.getView();
			oView.setModel(oViewModel, "vm");
			this.setViewBusy(true);
			var oRouter = this.getRouter();
			oRouter.attachRouteMatched(this.routeMatched.bind(this));
		},

		onBeforeRendering: function() {

		},

		onAfterRendering: function() {

		},

		onExit: function() {
			if (this._oCalendarViewTypePopover) {
				this._oCalendarViewTypePopover.destroy();
				this._oCalendarViewTypePopover = undefined;
			}
			if (this._oAppointmentsPopover) {
				this._oAppointmentsPopover.destroy();
				this._oAppointmentsPopover = undefined;
			}
		},

		routeMatched: function(oEvent) {
			var sRoute = oEvent.getParameter("name");
			var oArguments = oEvent.getParameter("arguments");
			switch (sRoute) {
				case "Main":
					this.onMainRoute(oArguments);
					break;
				default:
					break;
			}
			return false;
		},

		onMainRoute: function(oArguments) {
			this._readAppConfiguration("EMPLOYEE")
				.then(function(oData) {
					var oViewModel = this.getModel("vm");
					oViewModel.setProperty("/currentEmployee", oData.Value);
					this._initializeView();
				}.bind(this));
		},

		_initializeView: function() {
			var oViewModel = this.getModel("vm");
			var sSelectedCalendar = oViewModel.getProperty("/selectedCalendar");
			this._getCalendar().setBuiltInViews(CalendarUtils.CALENDAR_BUILT_IN_VIEWS);
			this._bindCalendar(sSelectedCalendar);
		},

		_readAppConfiguration: function(sConfigurationId) {
			var oModel = this.getModel();
			return new Promise(function(fnResolve, fnReject) {
				var sContext = "/AppControlSet('" + sConfigurationId + "')";
				var oConfiguration = oModel.getProperty(sContext);
				if (oConfiguration) {
					fnResolve(oConfiguration);
				} else {
					oModel.read(sContext, {
						success: fnResolve,
						error: fnReject
					});
				}
			});
		},

		_bindCalendar: function(sCalendarID) {
			var oView = this.getView();
			var oCalendar = this._getCalendar();
			var oStartDate = oCalendar.getFilterStartDate();
			var oEndDate = oCalendar.getFilterEndDate();
			var aFilters = this._getEmployeeSearchFilter();
			aFilters.push(new Filter({path: "StartDate", operator: "BT", value1: oStartDate, value2: oEndDate}));
			oCalendar.getModel().invalidate();
			oCalendar.bindAggregation("rows", {
				path: "/CalendarSet(guid'" + sCalendarID + "')/EnrolmentSet",
				parameters: {
					expand: "Employee,Employee/EventSet,Employee/EventSet/EventCode"
				},
				events: {
					dataRequested: this.onPlanningCalendarRowDataRequested.bind(this),
					dataReceived: this.onPlanningCalendarRowDataReceived.bind(this)
				},
				filters: aFilters,
				template: oView.byId("mCalendarRow"),
				templateShareable: true
			});
		},

		onPlanningCalendarRowDataRequested: function(oEvent) {
			this.setViewBusy(true);
		},

		onPlanningCalendarRowDataReceived: function(oEvent) {
			var oViewModel = this.getModel("vm");
			var oCalendar = this._getCalendar();
			var sViewKey = oCalendar.getViewKey();
			var sCurrentEmployee = oViewModel.getProperty("/currentEmployee");
			if (sViewKey === "One Month") {
				var oData = oEvent.getParameter("data");
				if (oData && oData.results.length) {
					oData.results.forEach(function(oEnrolment) {
						if (oEnrolment.Employee.EmployeeId === sCurrentEmployee) {
							oCalendar.renderSmallAppointments(oEnrolment.Employee.EventSet.results);
						}
					});
				}
			}
			var oModel = this.getModel();
			CalendarUtils.waitForPendingRequests(oModel)
				.then(function() {
					this.setViewBusy(false);
				}.bind(this));
		},

		onCalendarContainerItemSelected: function(oEvent) {
			var sSelectedKey = oEvent.getParameter("selectedKey");
			var oViewModel = this.getView().getModel("vm");
			oViewModel.setProperty("/selectedCalendar", sSelectedKey);
		},

		onRequestLeavePressed: function(oEvent) {
			var oCrossAppNavigationService = sap.ushell.Container.getService("CrossApplicationNavigation");
			oCrossAppNavigationService.toExternal(CalendarUtils.CROSS_NAVIGATION_LEAVE_REQUEST);
		},

		onPlanningCalendarStartDateChanged: function(oEvent) {
			var oViewModel = this.getModel("vm");
			var sSelectedCalendar = oViewModel.getProperty("/selectedCalendar");
			this._bindCalendar(sSelectedCalendar);
		},

		formatCalendarAppointmentTitle: function(sSelectedCalendar, sTitle) {
			var oCalendar = this._getCalendar();
			if (oCalendar) {
				var sViewKey = oCalendar.getViewKey();
				switch (sViewKey) {
					case "Week":
						return null;
					default:
						return sTitle;
				}
			}
			return undefined;
		},

		formatCalendarAppointmentDescription: function(sSelectedCalendar, sDescription) {
			var oCalendar = this._getCalendar();
			if (oCalendar) {
				var sViewKey = oCalendar.getViewKey();
				switch (sViewKey) {
					case "One Month":
						return null;
					default:
						return sDescription;
				}
			}
			return undefined;
		},

		_getCalendar: function() {
			var oView = this.getView();
			return oView.byId("mCalendar");
		},

		onMyTeamCalendarButtonPressed: function(oEvent) {
			this._switchCalendar(CalendarUtils.CALENDAR.MY_TEAM);
		},

		onMeCalendarButtonPressed: function(oEvent) {
			this._switchCalendar(CalendarUtils.CALENDAR.ME);
		},


		_getEmployeeSearchFilter: function() {
			var aFilters = [];
			var sQuery = this.getModel("vm").getProperty("/selectedCalendarQueryFilter");
			if (sQuery) {
				aFilters.push(new Filter({path: "Employee/Name/FormattedName", operator: "Contains", value1: "'" + sQuery + "'"}));
			}
			return aFilters;
		},

		_switchCalendar: function(sSelectedCalendar) {
			var oViewModel = this.getModel("vm");
			oViewModel.setProperty("/selectedCalendar", sSelectedCalendar);
			oViewModel.setProperty("/selectedCalendarViewType", -1);
			oViewModel.setProperty("/selectedCalendarQueryFilter", "");
			oViewModel.setProperty("/selectedAppointment", undefined);
			oViewModel.setProperty("/selectedEmployee", undefined);
			this._bindCalendar(sSelectedCalendar);
		},

		onCalendarSearch: function(oEvent) {
			var oViewModel = this.getModel("vm");
			var sSelectedCalendar = oViewModel.getProperty("/selectedCalendar");
			this._debounce(function() {
				this._bindCalendar(sSelectedCalendar);
			}.bind(this), 500);
		},

		onCalendarSelectionChanged: function(oEvent) {
			var oViewModel = this.getModel("vm");
			var sSelectedCalendar = oViewModel.getProperty("/selectedCalendar");
			this._switchCalendar(sSelectedCalendar);
		},

		onManageCalendarsPressed: function(oEvent) {
			var oRouter = this.getRouter();
			oRouter.navTo("ManageGroup");
		},

		onCalendarViewTypePressed: function(oEvent) {
			if (!this._oCalendarViewTypePopover) {
				this._oCalendarViewTypePopover = sap.ui.xmlfragment("team.zag.components.scheduling.SchedulingApp.view.fragment.CalendarViewType", this);
				this.getView().addDependent(this._oCalendarViewTypePopover);
			}
			var oSource = oEvent.getSource();
			this._updateSelectedCalendarViewType();
			this._oCalendarViewTypePopover.openBy(oSource);
		},

		onCalendarViewTypeRadioButtonSelected: function() {
			if (this._oCalendarViewTypePopover) {
				this._oCalendarViewTypePopover.close();
			}
			jQuery.sap.delayedCall(0, this, function() {
				this._updateSelectedInterval();
				var oViewModel = this.getModel("vm");
				var sSelectedCalendar = oViewModel.getProperty("/selectedCalendar");
				this._bindCalendar(sSelectedCalendar);
			}.bind(this));
		},

		_updateSelectedCalendarViewType: function(oEvent) {
			var sViewKey = this._getCalendar().getViewKey();
			var iViewIndex = CalendarUtils.CALENDAR_VIEW_TYPES.indexOf(sViewKey);
			var oViewModel = this.getModel("vm");
			oViewModel.setProperty("/selectedCalendarViewType", iViewIndex);
		},

		onEmployeeSelected: function(oEvent) {
			this._removeSelectedAppointments();
			this._updateSelectedInterval();
			var oViewModel = this.getModel("vm");
			var sSelectedEmployee = oViewModel.getProperty("/selectedEmployee");
			var sControlId = oEvent.getParameter("row").getId();
			var sEmployeeId = Core.byId(sControlId).getBindingContext().getProperty("EmployeeId");
			var bWasPreviouslySelected = (sEmployeeId === sSelectedEmployee);
			if (bWasPreviouslySelected) {
				jQuery.sap.delayedCall(100, this, function() {
					this._removeSelectedCalendarRows();
				}.bind(this));
			}
			oViewModel.setProperty("/selectedEmployee", bWasPreviouslySelected ? undefined : sEmployeeId);
		},

		onAppointmentSelected: function(oEvent) {
			this._removeSelectedCalendarRows();
			this._updateSelectedInterval();
			var oControl = oEvent.getParameter("appointment");
			var oAppointment = oControl.getBindingContext().getObject();
			var bIsSelected = oControl.getSelected();
			var oViewModel = this.getModel("vm");
			oViewModel.setProperty("/selectedAppointment", (bIsSelected ? oAppointment : undefined));
			if (!this._oAppointmentsPopover) {
				this._oAppointmentsPopover = sap.ui.xmlfragment("team.zag.components.scheduling.SchedulingApp.view.fragment.CalendarAppointmentDetails", this);
				this.getView().addDependent(this._oAppointmentsPopover);
			}
			if (bIsSelected) {
				this._oAppointmentsPopover.openBy(oControl);
			} else {
				this.onCalendarAppointmentClosePressed();
			}
		},

		onIntervalSelected: function(oEvent) {
			var oStartDate = oEvent.getParameter("startDate");
			var oEndDate = oEvent.getParameter("endDate");
			var oViewModel = this.getModel("vm");
			oViewModel.setProperty("/selectedInterval/startDate", oStartDate);
			oViewModel.setProperty("/selectedInterval/endDate", oEndDate);
		},

		onChangeSchedulePressed: function(oEvent) {
			var oScheduleRequestRoute = CalendarUtils.CROSS_NAVIGATION_SCHEDULE_CHANGE;
			var aRoutes = this._getChangeScheduleRoutes(oScheduleRequestRoute);
			var oCrossAppNavigationService = sap.ushell.Container.getService("CrossApplicationNavigation");
			aRoutes.forEach(function(oRoute) {
				oCrossAppNavigationService.toExternal(oRoute);
			});
		},

		onPrintPressed: function(oEvent) {
			this._disableElementsBeforePrint()
				.then(function() {
					window.print();
					jQuery.sap.delayedCall(100, this, function() {
						this._enableElementsAfterPrint();
					}.bind(this));
				}.bind(this));
		},

		_disableElementsBeforePrint: function() {
			var oView = this.getView();
			var oMainView = oView.byId("mainView");
			var oCalendarLegend = oView.byId("mCalendarLegend");
			var oSubHeader = oMainView.getSubHeader();
			oSubHeader.addStyleClass("mHidden");
			oMainView.setShowFooter(false);
			oCalendarLegend.setVisible(false);
			this.setViewBusy(true);
			var oModel = this.getModel();
			return new Promise(function(fnResolve) {
				jQuery.sap.delayedCall(0, this, function() {
					CalendarUtils.waitForPendingRequests(oModel)
					.then(function() {
						this.setViewBusy(false);
						fnResolve();
					}.bind(this));
				}.bind(this));
			}.bind(this));
		},

		_enableElementsAfterPrint: function() {
			var oView = this.getView();
			var oMainView = oView.byId("mainView");
			var oCalendarLegend = oView.byId("mCalendarLegend");
			var oSubHeader = oMainView.getSubHeader();
			oSubHeader.removeStyleClass("mHidden");
			oMainView.setShowFooter(true);
			oCalendarLegend.setVisible(true);
			this.setViewBusy(true);
			var oModel = this.getModel();
			return new Promise(function(fnResolve) {
				jQuery.sap.delayedCall(0, this, function() {
					CalendarUtils.waitForPendingRequests(oModel)
					.then(function() {
						this.setViewBusy(false);
						setTimeout(fnResolve, 2000);
					}.bind(this));
				}.bind(this));
			}.bind(this));
		},

		onCalendarAppointmentClosePressed: function(oEvent) {
			if (this._oAppointmentsPopover) {
				this._oAppointmentsPopover.close();
			}
		},

		_removeSelectedAppointments: function() {
			jQuery.sap.delayedCall(0, this, function() {
				var oViewModel = this.getModel("vm");
				oViewModel.setProperty("/selectedAppointment", undefined);
				var aSelectedAppointments = this._getCalendar().getSelectedAppointments();
				aSelectedAppointments.forEach(function(sControlId) {
					Core.byId(sControlId).setSelected(false);
				});
				var aRows = this._getCalendar().getRows();
				aRows.forEach(function(oRow) {
					oRow.getCalendarRow().aSelectedAppointments = [];
				});
			}.bind(this));
		},

		_removeSelectedCalendarRows: function() {
			var aSelectedRows = this._getCalendar().getSelectedRows();
			aSelectedRows.forEach(function(oCalendarRow) {
				oCalendarRow.setSelected(false);
			});
			var oViewModel = this.getModel("vm");
			oViewModel.setProperty("/selectedEmployee", undefined);
		},

		_getChangeScheduleRoutes: function(oMainRoute) {
			var oViewModel = this.getModel("vm");
			var iStartTime = oViewModel.getProperty("/selectedInterval/startDate").getTime();
			var iEndTime = CalendarUtils.getEndDateForListSchedule(oViewModel.getProperty("/selectedInterval/endDate")).getTime();
			var sViewKey = oViewModel.getProperty("/selectedCalendarViewType");
			var aSelectedAppointments = this._getCalendar().getSelectedAppointments();
			var aSelectedRows = this._getCalendar().getSelectedRows();
			var oContext, sEmployeeId, sEventId;
			var aRoutes = [];
			if (aSelectedAppointments.length) {
				oContext = Core.byId(aSelectedAppointments[0]).getBindingContext();
				sEmployeeId = oContext.getProperty("EmployeeId");
				sEventId = oContext.getProperty("EventId");
				aRoutes.push(CalendarUtils.createAppSpecificRoute(oMainRoute, "&/ListSchedule/" + iStartTime + "/" + iEndTime + "/" + sEmployeeId + "/" + sViewKey));
				aRoutes.push(CalendarUtils.createAppSpecificRoute(oMainRoute, "&/CreateRequestWithReference/" + sEmployeeId + "/" + sEventId));
				History.getInstance().aHistory.push("/ListSchedule/" + iStartTime + "/" + iEndTime + "/" + sEmployeeId);
				History.getInstance().iHistoryPosition++;
			} else if (aSelectedRows.length) {
				oContext = aSelectedRows[0].getBindingContext();
				sEmployeeId = oContext.getProperty("EmployeeId");
				aRoutes.push(CalendarUtils.createAppSpecificRoute(oMainRoute, "&/ListSchedule/" + iStartTime + "/" + iEndTime + "/" + sEmployeeId + "/" + sViewKey));
			}
			return aRoutes;
		},

		_updateSelectedInterval: function() {
			var oCalendar = this._getCalendar();
			var oStartDate = oCalendar.getFilterStartDate();
			var oEndDate = oCalendar.getFilterEndDate();
			var oViewModel = this.getModel("vm");
			oViewModel.setProperty("/selectedInterval/startDate", oStartDate);
			oViewModel.setProperty("/selectedInterval/endDate", oEndDate);
		},

		_debounce: function(fnFunction, iDelayInMs) {
			clearTimeout(this._iCalendarLiveSearchDebounce);
			this._iCalendarLiveSearchDebounce = setTimeout(fnFunction, iDelayInMs);
		}

	});
});