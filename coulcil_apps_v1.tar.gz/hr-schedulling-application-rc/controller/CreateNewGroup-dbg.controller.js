sap.ui.define([
	"sap/ui/core/Core",
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"../model/models",
	"../utils/Constants"
], function(Core, BaseController, JSONModel, Filter, FilterOperator, MessageToast, models, Constants) {
	"use strict";

	return BaseController.extend("team.zag.components.scheduling.SchedulingApp.controller.CreateNewGroup", {

		onInit: function() {
			var oViewModel = new JSONModel({
				"newCalendar": models.createCalendar()
			});
			this.setModel(oViewModel, "vm");
			var oRouter = this.getRouter();
			oRouter.getRoute("CreateNewGroup").attachPatternMatched(this._onRouteMatched, this);
		},

		_onRouteMatched: function() {
			var oView = this.getView();
			var oViewModel = this.getModel("vm");
			oView.bindElement({
				path: "vm>/newCalendar"
			});
			oViewModel.setProperty("/newCalendar", models.createCalendar());
		},

		onSearchList: function(oEvent) {
			var aFilter = [];
			var sQuery = oEvent.getParameter("query");
			if (sQuery) {
				aFilter.push(new Filter("Employee/Name/FormattedName", FilterOperator.Contains, sQuery));
			}
			var oList = this.byId("tableList");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilter);
		},

		onAddPersonPress: function() {
			if (!this._oDialog){
				this._oDialog = sap.ui.xmlfragment("team.zag.components.scheduling.SchedulingApp.view.fragment.SelectPersonDialog", this);
			}
			this.getView().addDependent(this._oDialog);
			this._oDialog.open();
		},

		handleSearch: function(oEvent) {
			var oViewModel = this.getModel("vm");
			var sValue = oEvent.getParameter("value");
			var oControl = Core.byId("mEmployeeSelectDialog");
			oControl.setBusy(true);
			this._searchEmployee(sValue)
				.then(function(oData) {
					var aEmployeeList = [];
					if (oData && oData.results && oData.results.length) {
						oData.results.forEach(function(oEmployee) {
							aEmployeeList.push(oEmployee);
						});
					}
					oViewModel.setProperty("/employeeList", aEmployeeList);
				})
			.catch(function(oError) {
				jQuery.sap.log.error(oError);
			})
			.finally(function() {
				oControl.setBusy(false);
			});
		},

		_searchEmployee: function(sValue) {
			var oModel = this.getModel();
			return new Promise(function(fnResolve, fnReject) {
				oModel.callFunction("/EmployeeSearch", {
					method: "GET",
					urlParameters: {
						Term: sValue
					},
					success: fnResolve,
					error: fnReject
				});
			});
		},

		onSaveButtonPress: function() {
			this.setViewBusy(true);
			var oViewModel = this.getModel("vm");
			var oModel = this.getView().getModel();
			var oNewCalendar = oViewModel.getProperty("/newCalendar");
			oModel.create("/CalendarSet", _.omit(_.cloneDeep(oNewCalendar), "EnrolmentSet"), {
				groupId: Constants.ENROLMENT_SUBMISSION_GROUP_ID
			});
			var aEnrolment = oViewModel.getProperty("/newCalendar/EnrolmentSet");
			aEnrolment.forEach(function(oEnrolment) {
				oModel.create("/EnrolmentSet", _.omit(_.cloneDeep(oEnrolment), "Employee"), {
					groupId: Constants.ENROLMENT_SUBMISSION_GROUP_ID
				});
			});

			oModel.submitChanges({
				groupId: Constants.ENROLMENT_SUBMISSION_GROUP_ID
			});

			this.onBackButtonPressed();
			this.setViewBusy(false);
		},

		onCancelButtonPress: function() {
			var oModel = this.getView().getModel();
			oModel.resetChanges();
			oModel.refresh();
			this.onBackButtonPressed();
		},

		disableSaveButton: function(sGroupName) {
			return sGroupName ? true : false;
		},

		requiredToggle: function(sGroupName) {
			return sGroupName ? false : true;
		},

		handleSelection: function(oEvent) {
			var oListItem = oEvent.getParameter("selectedItem");
			var oEmployee = oListItem.getBindingContext("vm").getObject();
			var oViewModel = this.getModel("vm");
			var sCalendarId = oViewModel.getProperty("/newCalendar/CalendarId");
			var aEnrolmentSet = oViewModel.getProperty("/newCalendar/EnrolmentSet");
			var oEnrolment = models.createEnrolment(sCalendarId, oEmployee.EmployeeId);
			var sEmployeeEnrolmentId, sEmployeeSelectionId;
			oEnrolment.Employee = _.cloneDeep(oEmployee);

			for (var i = 0; i < aEnrolmentSet.length; i++){
				sEmployeeEnrolmentId = aEnrolmentSet[i].EmployeeId;
				sEmployeeSelectionId = oEnrolment.EmployeeId;
				if (sEmployeeEnrolmentId === sEmployeeSelectionId){
					break;
				}
			}

			if (sEmployeeEnrolmentId != null && sEmployeeEnrolmentId === sEmployeeSelectionId){
				MessageToast.show(this.getResourceBundle().getText("createGroupToastMessage"));
			} else {
				aEnrolmentSet.push(oEnrolment);
				oViewModel.setProperty("/newCalendar/EnrolmentSet", aEnrolmentSet);
				oViewModel.updateBindings(true);
			}

			if (this._oDialog) {
				this._oDialog.destroy(true);
				this._oDialog = null;
			}
		},

		handleFragmentClose: function() {
			if (this._oDialog) {
				this._oDialog.destroy(true);
				this._oDialog = null;
			}
		},

		deleteButtonPress: function(oEvent) {
			var oViewModel = this.getModel("vm");
			var aEnrolmentSet = oViewModel.getProperty("/newCalendar/EnrolmentSet");
			var oListItem = oEvent.getParameter("listItem");
			var iArrayPosition = oListItem.getList().indexOfItem(oListItem);
			aEnrolmentSet.splice(iArrayPosition,1);
			oViewModel.updateBindings(true);
		}
	});
});