sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"team/zag/library/scheduling/utils/MessageHelper"
], function(Controller, History, MessageHelper) {
	"use strict";

	return Controller.extend("team.zag.components.scheduling.SchedulingApp.controller.BaseController", {

		/**
		 * Convenience method for accessing the router in every controller of the application.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function() {
			return this.getOwnerComponent().getRouter();
		},

		/**
		 * Convenience method for getting the view model by name in every controller of the application.
		 * @public
		 * @param {string} sName the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function(sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model in every controller of the application.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function(oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Convenience method for getting the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function() {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		/**
		 * Event handler when the share button has been clicked
		 * @param {sap.ui.base.Event} oEvent the butten press event
		 * @public
		 */
		onSharePressed: function(oEvent) {
			var oShareSheet = this.getView().byId("shareSheet");
			this.attachControl(oShareSheet);
			oShareSheet.openBy(oEvent.getSource());
		},

		/**
		 * Utility method to attach a control, typically a dialog,
		 * to the view, and syncing the styleclass of the application
		 * @param {sap.ui.core.Control} oControl the control to be attached
		 * @public
		 */
		attachControl: function(oControl) {
			var sCompactCozyClass = this.getOwnerComponent().getContentDensityClass();
			jQuery.sap.syncStyleClass(sCompactCozyClass, this.getView(), oControl);
			this.getView().addDependent(oControl);
		},

		/**
		 * Utility method to set the view as busy
		 * @param {boolean} bIsBusy whether the view is busy or not
		 * @public
		 */
		setViewBusy: function(bIsBusy) {
			var oView = this.getView();
			oView.setBusy(bIsBusy);
		},

		/**
		 * Utility method to perform a back navigation. Should move to #Shell-home if no previous hash is found.
		 * @public
		 */
		onBackButtonPressed: function () {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oCrossApplicationNavigationService = sap.ushell.Container.getService("CrossApplicationNavigation");
				oCrossApplicationNavigationService.toExternal({
					target: {
						shellHash: "#"
					}
				});
			}
		},

		_showErrorMessage: function(oError) {
			if (oError && !oError.responseText) {
				jQuery.sap.log.error(oError);
			}
			if (oError && oError.responseText) {
				MessageHelper.showErrorMessage(oError, this.getResourceBundle().getText("appErrorDialogTitle"));
			}
		},

		_releaseViewOnRequestFailed: function() {
			var oModel = this.getModel();
			oModel.attachEventOnce("requestFailed", function(oResponse) {
				this.setViewBusy(false);
			}.bind(this));
		},

		_registerRequestFailedHandler: function() {
			this.getOwnerComponent().registerRequestFailedHandler();
		},

		_unregisterRequestFailedHandler: function() {
			this.getOwnerComponent().unregisterRequestFailedHandler();
		}

	});
});