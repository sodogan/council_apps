sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel"
], function(BaseController, JSONModel) {
	"use strict";

	return BaseController.extend("team.zag.components.scheduling.SchedulingApp.controller.App", {

		onInit: function() {
			var oViewModel = new JSONModel({busy: true, delay: 0});
			this.setModel(oViewModel, "appView");
		}

	});

});