sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, JSONModel, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("team.zag.components.scheduling.SchedulingApp.controller.CalendarGroup", {

		onInit: function() {
			var oViewModel = new JSONModel({busy: true, delay: 0});
			var oView = this.getView();
			var oRouter = this.getRouter();
			this.setViewBusy(true);
			oView.setModel(oViewModel, "vm");
			oRouter.getRoute("CalendarGroup").attachPatternMatched(this._onObjectMatched, this);
		},

		onBeforeRendering: function() {
			var oRouter = this.getRouter();
			oRouter.getRoute("CalendarGroup").attachPatternMatched(this._onObjectMatched, this);

		},

		_onObjectMatched: function (oEvent) {
			var oArgs = oEvent.getParameter("arguments");
			var sCalendarId = oArgs.CalendarId;
			var oViewModel = this.getModel("vm");
			oViewModel.setProperty("/CalendarId", sCalendarId);
			var oView = this.getView();
			oView.bindElement({
				path: "/CalendarSet(guid'" + sCalendarId + "')"
			});
			this.setViewBusy(false);
		},

		onChangeButtonPress: function() {
			var oRouter = this.getRouter();
			var oViewModel = this.getModel("vm");
			var sCalendarId =  oViewModel.getProperty("/CalendarId");
			oRouter.navTo("EditGroupDetail", {
				"CalendarId": sCalendarId
			});
		},

		tableFilter: function() {
			var oViewModel = this.getModel("vm");
			var sCalendarId = oViewModel.getProperty("/CalendarSet/CalendarId");
			var oCalendarList = this.getView().byId("calendarList");
			var oListBinding = oCalendarList.getBinding("items");
			oListBinding.filter(new Filter({
				filters: [
					new Filter({path: "CalendarId", operator: FilterOperator.EQ, value1: sCalendarId})
				],
				and: true
			}));
		},

		onSearchList: function(oEvent){
			var aFilter = [];
			var sQuery = oEvent.getParameter("query");
			if (sQuery) {
				aFilter.push(new Filter("Employee/Name/FormattedName", FilterOperator.Contains, sQuery));
			}
			var oCalendarList = this.byId("calendarList");
			var oListBinding = oCalendarList.getBinding("items");
			oListBinding.filter(aFilter);
		}

	});

});