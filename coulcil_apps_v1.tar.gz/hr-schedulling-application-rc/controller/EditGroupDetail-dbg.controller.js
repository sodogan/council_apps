sap.ui.define([
	"sap/ui/core/Core",
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"team/zag/library/scheduling/utils/CalendarUtils",
	"team/zag/components/scheduling/SchedulingApp/utils/Formatter",
	"../model/models",
	"../utils/Constants"
], function(Core, BaseController, JSONModel, Filter, FilterOperator, CalendarUtils, Formatter, models, Constants) {
	"use strict";

	return BaseController.extend("team.zag.components.scheduling.SchedulingApp.controller.EditGroupDetail", {

		Formatter: Formatter,

		_pendingRequests: [],

		onInit: function() {
			var oViewModel = new JSONModel({
				"selectedCalendar": undefined,
				"employeeList": []
			});
			this.setModel(oViewModel, "vm");
			var oRouter = this.getRouter();
			oRouter.getRoute("EditGroupDetail").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function (oEvent) {
			var oViewModel = this.getModel("vm");
			var oArgs = oEvent.getParameter("arguments");
			var sCalendarId = oArgs.CalendarId;
			this.setViewBusy(true);
			this._readCalendar(sCalendarId)
				.then(function(oCalendar) {
					oCalendar = CalendarUtils.patchODataObject(_.cloneDeep(oCalendar));
					oViewModel.setProperty("/selectedCalendar", oCalendar);
					this._cancelPendingRequests();
				}.bind(this))
				.then(this._bindView.bind(this))
			.catch(function(oError) {
				jQuery.sap.log.error(oError);
			})
			.finally(function() {
				this.setViewBusy(false);
			}.bind(this));
		},

		_bindView: function() {
			var oViewModel = this.getModel("vm");
			var oCalendar = oViewModel.getProperty("/selectedCalendar");
			if (oCalendar) {
				var oView = this.getView();
				oView.bindElement({
					path: "vm>/selectedCalendar"
				});
			}
		},

		onSearchList: function(oEvent){
			var aFilter = [];
			var sQuery = oEvent.getParameter("query");
			if (sQuery) {
				aFilter.push(new Filter("Employee/Name/FormattedName", FilterOperator.Contains, sQuery));
			}
			var oList = this.byId("tableList");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilter);
		},

		onAddPersonPress: function() {
			if (!this._oDialog){
				this._oDialog = sap.ui.xmlfragment("team.zag.components.scheduling.SchedulingApp.view.fragment.SelectPersonDialog", this);
			}
			this.getView().addDependent(this._oDialog);
			this._oDialog.open();
		},

		handleSearch: function(oEvent) {
			var oViewModel = this.getModel("vm");
			var sValue = oEvent.getParameter("value");
			var oControl = Core.byId("mEmployeeSelectDialog");
			oControl.setBusy(true);
			var aEmployeeList = [];
			this._searchEmployee(sValue)
				.then(function(oData) {
					var aEnrolments = oViewModel.getProperty("/selectedCalendar/EnrolmentSet");
					var aEnrolmentEmployees = _.map(aEnrolments, "EmployeeId");
					if (oData && oData.results && oData.results.length) {
						oData.results.forEach(function(oEmployee) {
							var iIndex = aEnrolmentEmployees.indexOf(oEmployee.EmployeeId);
							if (iIndex === -1) {
								aEmployeeList.push(oEmployee);
							}
						});
					}
					oViewModel.setProperty("/employeeList", aEmployeeList);
				})
			.catch(function(oError) {
				jQuery.sap.log.error(oError);
			})
			.finally(function() {
				oControl.setBusy(false);
			});
		},

		_searchEmployee: function(sValue) {
			var oModel = this.getModel();
			return new Promise(function(fnResolve, fnReject) {
				oModel.callFunction("/EmployeeSearch", {
					method: "GET",
					urlParameters: {
						Term: sValue
					},
					success: fnResolve,
					error: fnReject
				});
			});
		},

		onSaveButtonPress: function() {
			var oViewModel = this.getModel("vm");
			var oModel = this.getModel();
			var oNewCalendar = oViewModel.getProperty("/selectedCalendar");
			var sCalendarId = oViewModel.getProperty("/selectedCalendar/CalendarId");
			oModel.update("/CalendarSet(guid'" + sCalendarId + "')", _.omit(_.cloneDeep(oNewCalendar), "EnrolmentSet"), {
				groupId: Constants.ENROLMENT_SUBMISSION_GROUP_ID
			});
			this.setViewBusy(true);
			this._submitChanges()
				.then(function() {
					oViewModel.updateBindings(true);
					this.onBackButtonPressed();
				}.bind(this))
			.finally(function() {
				this.setViewBusy(false);
			}.bind(this));
		},

		onCancelButtonPress: function() {
			var oViewModel = this.getModel("vm");
			this._cancelPendingRequests();
			oViewModel.updateBindings(true);
			this.onBackButtonPressed();
		},

		_submitChanges: function() {
			var oModel = this.getModel();
			return new Promise(function(fnResolve, fnReject) {
				oModel.attachEventOnce("batchRequestFailed", fnReject);
				oModel.attachEventOnce("batchRequestCompleted", function(oEvent) {
					var aRequests = oEvent.getParameter("requests");
					for (var i = 0; i < aRequests.length; i++) {
						if (!aRequests[i].success) {
							return fnReject(_.cloneDeep(oEvent));
						}
					}
					return fnResolve(_.cloneDeep(oEvent));
				});
				oModel.submitChanges({groupId: Constants.ENROLMENT_SUBMISSION_GROUP_ID});
			});
		},

		handleSelection: function(oEvent) {
			var oListItem = oEvent.getParameter("selectedItem");
			var sEmployeeId = oListItem.getBindingContext("vm").getProperty("EmployeeId");
			var oViewModel = this.getModel("vm");
			var sCalendarId = oViewModel.getProperty("/selectedCalendar/CalendarId");
			var oEnrolment = models.createEnrolment(sCalendarId, sEmployeeId);

			var oEmployee = oListItem.getBindingContext("vm").getObject();
			oEnrolment.Employee = _.cloneDeep(oEmployee);
			this._createEnrolmentInViewModel(oEnrolment);

			this._createEnrolment(oEnrolment)
				.then(function(oEnrolment) {
					oViewModel.setProperty("/employeeList", []);
				});

			if (this._oDialog) {
				this._oDialog.destroy(true);
				this._oDialog = null;
				oViewModel.setProperty("/employeeList", []);
			}
		},

		_createEnrolmentInViewModel: function(oEnrolment) {
			var oViewModel = this.getModel("vm");
			var aEnrolmentSet = oViewModel.getProperty("/selectedCalendar/EnrolmentSet");
			aEnrolmentSet.push(oEnrolment);
			oViewModel.setProperty("/selectedCalendar/EnrolmentSet", aEnrolmentSet);
			oViewModel.updateBindings(true);
		},

		handleFragmentClose: function() {
			var oViewModel = this.getModel("vm");
			if (this._oDialog) {
				this._oDialog.destroy(true);
				this._oDialog = null;
				oViewModel.setProperty("/employeeList", []);
			}
		},

		deleteButtonPress: function(oEvent) {
			var oModel = this.getModel();
			var oViewModel = this.getModel("vm");
			var sCalendarId = oViewModel.getProperty("/selectedCalendar/CalendarId");
			var oListItem = oEvent.getParameter("listItem");
			var sEmployeeId = oListItem.getBindingContext("vm").getProperty("EmployeeId");

			if (oModel.getObject("/EnrolmentSet(CalendarId=guid'" + sCalendarId + "',EmployeeId='" + sEmployeeId + "')")){
				this._pendingRequests.push(oModel.remove("/EnrolmentSet(CalendarId=guid'" + sCalendarId + "',EmployeeId='" + sEmployeeId + "')",{
					groupId: Constants.ENROLMENT_SUBMISSION_GROUP_ID
				}));
			}

			var aEnrolmentSet = oViewModel.getProperty("/selectedCalendar/EnrolmentSet");
			var iArrayPosition = oListItem.getList().indexOfItem(oListItem);
			aEnrolmentSet.splice(iArrayPosition,1);
			oViewModel.updateBindings(true);
		},

		_readCalendar: function(sCalendarId) {
			var oModel = this.getModel();
			return new Promise(function(fnResolve, fnReject) {
				oModel.read("/CalendarSet(guid'" + sCalendarId + "')", {
					urlParameters: {
						"$expand": "EnrolmentSet,EnrolmentSet/Employee"
					},
					success: fnResolve,
					error: fnReject
				});
			});
		},

		_createEnrolment: function(oEnrolment) {
			var oModel = this.getModel();
			return new Promise(function(fnResolve, fnReject){
				this._pendingRequests.push(oModel.create("/EnrolmentSet", _.omit(_.cloneDeep(oEnrolment), "Employee"), {
					groupId: Constants.ENROLMENT_SUBMISSION_GROUP_ID,
					success: fnResolve,
					error: fnReject
				}));
			}.bind(this));
		},

		_cancelPendingRequests: function() {
			this._pendingRequests.forEach(function(oRequest) {
				oRequest.abort();
			});
		}

	});
});