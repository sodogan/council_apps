sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"team/zag/library/scheduling/utils/CalendarUtils",
	"team/zag/components/scheduling/SchedulingApp/utils/Formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast"
], function(BaseController, JSONModel, CalendarUtils, Formatter, Filter, FilterOperator, MessageToast) {
	"use strict";

	return BaseController.extend("team.zag.components.scheduling.SchedulingApp.controller.ManageGroup", {

		Formatter: Formatter,

		onInit: function() {
			var oViewModel = new JSONModel({});
			this.setModel(oViewModel, "vm");
		},

		onObjectListItemPress: function(oEvent) {
			var oListItem = oEvent.getParameter("listItem");
			var oContext = oListItem.getBindingContext();
			var sCalendarId = oContext.getProperty("CalendarId");
			var oRouter = this.getRouter();
			oRouter.navTo("EditGroupDetail", {
				"CalendarId": sCalendarId
			});
		},

		formatMembersCount: function(aEnrolmentSet) {
			return (aEnrolmentSet && aEnrolmentSet.length ? aEnrolmentSet.length : undefined);
		},

		onSearchList: function(oEvent){
			var aFilter = [];
			var sQuery = oEvent.getParameter("query");
			if (sQuery) {
				aFilter.push(new Filter("Title", FilterOperator.Contains, sQuery));
			}
			var oList = this.byId("manageGroupsList");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilter);
		},

		onNewGroupButtonPress: function() {
			var oRouter = this.getRouter();
			oRouter.navTo("CreateNewGroup");
		},

		onDeleteListItemPressed: function(oEvent) {
			var oListItem = oEvent.getParameter("listItem");
			var oContext = oListItem.getBindingContext();
			var sCalendarId = oContext.getProperty("CalendarId");
			this._deleteCalendar(sCalendarId)
				.then(function() {
					MessageToast.show(this.getResourceBundle().getText("calendarDeleteCompleted"), {
						at: "center center",
						closeOnBrowserNavigation: false
					});
				}.bind(this))
			.catch(function(oError) {
				MessageToast.show(this.getResourceBundle().getText("calendarDeleteFailed"), {
					at: "center center",
					closeOnBrowserNavigation: false
				});
			});
		},

		_deleteCalendar: function(sCalendarId) {
			var oModel = this.getModel();
			return new Promise(function(fnResolve, fnReject) {
				oModel.remove("/CalendarSet(guid'" + sCalendarId + "')", {
					success: fnResolve,
					error: fnReject
				});
			});
		}
	});
});