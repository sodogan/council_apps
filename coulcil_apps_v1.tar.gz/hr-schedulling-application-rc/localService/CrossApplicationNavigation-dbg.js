sap.ui.define([
	"jquery.sap.global"
], function(jQuery) {
	"use strict";

	return {

		toExternal: function(oExternal) {
			jQuery.sap.log.info("toExternal:" + JSON.stringify(oExternal));
		}

	};
});