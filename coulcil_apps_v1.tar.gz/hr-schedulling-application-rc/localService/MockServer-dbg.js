sap.ui.define([
	"sap/ui/core/util/MockServer",
	"sap/ui/model/json/JSONModel"
	], function(MockServer, JSONModel) {
	"use strict";

	return {
		_sServiceUrl: "/sap/opu/odata/sap/ZHR_SCH_APP_SRV/",
		_sModulePath: "team.zag.components.scheduling.SchedulingApp.localService",

		init: function() {
			var oUriParameters = jQuery.sap.getUriParameters();
			var oMockServer = new MockServer({rootUri: this._sServiceUrl});
			var sPath = jQuery.sap.getModulePath(this._sModulePath);

			MockServer.config({
				autoRespond: true,
				autoRespondAfter: (oUriParameters.get("serverDelay") || 100)
			});

			oMockServer.simulate(sPath + "/metadata.xml", sPath + "/data");

			var aAdditionalRequests = [
				this._GET_EmployeeSearch()
			];

			var aRequests = oMockServer.getRequests();
			oMockServer.setRequests(aRequests.concat(aAdditionalRequests));

			this._oMockServer = oMockServer;
			oMockServer.start();
		},

		getKeyByName: function(sParameterName, sPathUrl) {
			var oRegex = new RegExp("[\\(,]" + sParameterName + "='([^']*)");
			var aResults = oRegex.exec(sPathUrl);
			return (aResults ? aResults[1].replace(/\+/g, " ") : null);
		},

		getSingleKey: function(sPathUrl) {
			var oRegex = new RegExp("[\\(,]'([^']*)");
			var aResults = oRegex.exec(sPathUrl);
			return (aResults ? aResults[1].replace(/\+/g, " ") : null);
		},

		_find: function(sAttribute, value, aSearchList, bLeaveEarly) {
			var aResult = [];
			for (var i = 0; i < aSearchList.length; i++) {
				if (aSearchList[i][sAttribute] === value) {
					aResult.push(aSearchList[i]);
				}
				if (aResult.length === 1 && bLeaveEarly) {
					break;
				}
			}
			return aResult;
		},

		_findFirst: function(sAttribute, value, aSearchList) {
			var aMatches = this._find(sAttribute, value, aSearchList, true);
			if (aMatches.length > 0) {
				return aMatches[0];
			}
			return null;
		},

		_getNewItemId: function(aExistingItems, sAttribute) {
			var sNewId = null;
			var iItemCount = 0;
			for (var i = 0; i < aExistingItems.length; i++) {
				if (aExistingItems[i][sAttribute] && aExistingItems[i][sAttribute] !== "") {
					iItemCount++;
				}
			}
			while (sNewId === null) {
				sNewId = ((iItemCount + 1) * 10).toString();
				if (this._findFirst(sAttribute, sNewId, aExistingItems)) {
					sNewId = null;
					iItemCount++;
				}
			}
			return sNewId;
		},

		_replaceEntityInEntitySet: function(aKeys, oReplaceEntity, aEntitySet) {
			for (var i = 0; i < aEntitySet.length; i++) {
				var bFoundEntity = true;
				var oEntity = aEntitySet[i];
				for (var j = 0; j < aKeys.length; j++) {
					if (oEntity[aKeys[j]] != oReplaceEntity[aKeys[j]]) {
						bFoundEntity = false;
						break;
					}
				}
				if (bFoundEntity) {
					aEntitySet[i] = oReplaceEntity;
					aEntitySet[i]["__metadata"] = oEntity["__metadata"];
					break;
				}
			}
			return aEntitySet;
		},

		/* eslint-disable */
		_GET_EmployeeSearch: function() {
			return {
				method: "GET",
				path: new RegExp("EmployeeSearch(.*)"),
				response: function(oXhr, sQueryString) {
					var aEmployeeSet = this._oMockServer.getEntitySetData("EmployeeSet");
					var sResponse = JSON.stringify({d: { results: aEmployeeSet }});
					oXhr.respondJSON(200, {}, sResponse);
					return true;
				}.bind(this)
			};
		}
		/* eslint-enable */

	};

});