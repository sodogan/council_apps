sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"team/zag/library/scheduling/utils/Formatter"
], function (JSONModel, Device, CommonFormatter) {
	"use strict";

	function Calendar() {
		this.CalendarId = CommonFormatter.newGuid();
		this.Title = undefined;
		this.ViewType = "Week";
		this.IsEditable = true;
		this.EnrolmentSet = [];
	}

	function Enrolment(sCalendarId, sEmployeeId) {
		this.CalendarId = sCalendarId;
		this.EmployeeId = sEmployeeId;
		this.Employee = undefined;
	}

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},

		createCalendar: function() {
			return new Calendar();
		},

		createEnrolment: function(sCalendarId, sEmployeeId) {
			return new Enrolment(sCalendarId, sEmployeeId);
		}

	};
});