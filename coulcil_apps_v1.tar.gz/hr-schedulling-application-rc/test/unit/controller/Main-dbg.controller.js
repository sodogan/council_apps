/*global QUnit, sinon*/

sap.ui.define([
	"sap/ui/base/ManagedObject",
	"sap/ui/model/Binding",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/mvc/Controller",
	"team/zag/components/scheduling/SchedulingApp/controller/Main.controller",
	"team/zag/components/scheduling/SchedulingApp/controls/SchedulerPlanningCalendar",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function (ManagedObject, Binding, JSONModel, Controller, MainController, SchedulerPlanningCalendar) {
	"use strict";

	QUnit.module("Main Controller");

	QUnit.test("should initialize Main Controller..", function (assert) {
		var oAppController = new MainController();
		var oViewModel = new JSONModel({
			"selectedCalendar": null
		});
		var oView = new ManagedObject({});
		var oGetViewStub = sinon.stub(Controller.prototype, "getView").returns(oView);
		oView.byId = function(sId) {
			return {
				addEventDelegate: function(oDelegate) {

				}
			};
		};
		oView.setModel(oViewModel, "vm");
		oAppController.onInit();
		assert.ok(oAppController);
		oGetViewStub.restore();
	});

	QUnit.test("should filter My Team Calendar..", function (assert) {
		var oAppController = new MainController();
		var oGetViewKeyStub = sinon.stub(SchedulerPlanningCalendar.prototype, "getViewKey").returns("Week");
		var oFilterSpy = sinon.spy();
		var oGetRowsBindingStub = sinon.stub(SchedulerPlanningCalendar.prototype, "getBinding").returns({
			filter: oFilterSpy
		});
		var oGetStartDateStub = sinon.stub(SchedulerPlanningCalendar.prototype, "getStartDate").returns(new Date(1554838200000));
		var oEvent = {
			getSource: function() {
				return new SchedulerPlanningCalendar({});
			}
		};
		oAppController.onPlanningCalendarStartDateChanged(oEvent);
		assert.ok(oGetViewKeyStub.called);
		assert.ok(oGetRowsBindingStub.called);
		assert.ok(oGetStartDateStub.called);
		assert.ok(oFilterSpy.calledOnce);
		oGetViewKeyStub.restore();
		oGetRowsBindingStub.restore();
		oGetStartDateStub.restore();
	});

	QUnit.test("should filter Me Calendar..", function (assert) {
		var oAppController = new MainController();
		var oGetViewKeyStub = sinon.stub(SchedulerPlanningCalendar.prototype, "getViewKey").returns("One Month");
		var oFilterSpy = sinon.spy();
		var oGetRowsBindingStub = sinon.stub(SchedulerPlanningCalendar.prototype, "getBinding").returns({
			filter: oFilterSpy
		});
		var oGetStartDateStub = sinon.stub(SchedulerPlanningCalendar.prototype, "getStartDate").returns(new Date(1554838200000));
		var oEvent = {
			getSource: function() {
				return new SchedulerPlanningCalendar({});
			}
		};
		oAppController.onPlanningCalendarStartDateChanged(oEvent);
		assert.ok(oGetViewKeyStub.called);
		assert.ok(oGetRowsBindingStub.called);
		assert.ok(oGetStartDateStub.called);
		assert.ok(oFilterSpy.calledOnce);
		oGetViewKeyStub.restore();
		oGetRowsBindingStub.restore();
		oGetStartDateStub.restore();
	});

});