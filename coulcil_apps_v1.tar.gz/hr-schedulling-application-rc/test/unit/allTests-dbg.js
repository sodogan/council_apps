sap.ui.define([
	"team/zag/components/scheduling/SchedulingApp/test/unit/controller/Main.controller"
], function () {
	"use strict";
});