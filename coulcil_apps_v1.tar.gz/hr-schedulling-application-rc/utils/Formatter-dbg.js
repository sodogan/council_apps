sap.ui.define([
	"sap/ui/core/format/DateFormat",
	"team/zag/library/scheduling/utils/CalendarUtils"
], function(DateFormat, CalendarUtils) {
	"use strict";

	var oTimeFormatter = DateFormat.getDateInstance({pattern: "PTHH'H'mm'M'ss'S'", UTC: false});
	var oTimeFormatterUTC = DateFormat.getDateInstance({pattern: "PTHH'H'mm'M'ss'S'", UTC: true});

	return {

		formatMyTeamCalendarButtonType: function(sCalendarID) {
			if (sCalendarID === CalendarUtils.CALENDAR.MY_TEAM) {
				return sap.m.ButtonType.Emphasized;
			}
			return sap.m.ButtonType.Default;
		},

		formatMeCalendarButtonType: function(sCalendarID) {
			if (sCalendarID === CalendarUtils.CALENDAR.ME) {
				return sap.m.ButtonType.Emphasized;
			}
			return sap.m.ButtonType.Default;
		},

		formatCalendarViewType: function(sCalendarID, sViewType, iSelectedViewType) {
			return (iSelectedViewType !== -1 ? CalendarUtils.CALENDAR_VIEW_TYPES[iSelectedViewType] : sViewType);
		},

		isChangeScheduleActionEnabled: function(oStartDate, oEndDate, oSelectedAppointment, sSelectedEmployee) {
			if (oStartDate !== undefined && oEndDate !== undefined) {
				if (oSelectedAppointment !== undefined) {
					return oSelectedAppointment.IsEditable;
				} else {
					return sSelectedEmployee !== undefined;
				}
			}
			return false;
		},

		formatScheduledEventTitle: function(bIsPhone, iViewType, sTitle) {
			var sViewKey = CalendarUtils.CALENDAR_VIEW_TYPES[iViewType];
			if (bIsPhone && sViewKey !== "One Month") {
				return undefined;
			}
			return sTitle;
		},

		formatScheduledEventDescription: function(bIsPhone, iViewType, sTitle, sDescription) {
			var sViewKey = CalendarUtils.CALENDAR_VIEW_TYPES[iViewType];
			if (bIsPhone && sViewKey !== "One Month" && sTitle !== "" && sDescription === "") {
				return sTitle;
			}
			return sDescription;
		},

		formatEventCode: function(sEventCode) {
			if (!sEventCode || sEventCode === "") {
				return "Type20";
			}
			return sEventCode;
		},

		formatEventStartDate: function(oStartDate) {
			return new Date(new Date(oStartDate.getTime()).setHours(1, 0, 0, 0));
		},

		formatEventEndDate: function(oStartDate, oEndDate, sEventCodeId) {
			switch (sEventCodeId) {
				case CalendarUtils.EVENT_TYPE.ABSENCE:
					return new Date(new Date(oEndDate.getTime()).setHours(23, 0, 0, 0));
				default:
					return new Date(new Date(oStartDate.getTime()).setHours(23, 0, 0, 0));
			}
		},

		parseBreakTime: function(oBreakTime) {
			if (oBreakTime && oBreakTime.ms !== undefined) {
				return oTimeFormatter.parse(oTimeFormatterUTC.format(new Date(oBreakTime.ms)));
			}
			return undefined;
		},

		isCalendarEventBreaksVisible: function(bIsStandard, oStartTime1, oEndTime1, oStartTime2, oEndTime2) {
			if (!bIsStandard) {
				if (oStartTime1 && oStartTime1.ms === 0 && oStartTime2 && oStartTime2.ms === 0 && oEndTime1 && oEndTime1.ms === 0 && oEndTime2 && oEndTime2.ms === 0) {
					return false;
				}
			}
			return true;
		}

	};
});