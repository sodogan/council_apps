sap.ui.define([
    "jquery.sap.global"
], function(jQuery) {
	"use strict";

    return {
        ENROLMENT_SUBMISSION_GROUP_ID: "EnrolmentSubmissionGroup"
	};
});