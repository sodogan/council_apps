sap.ui.define([
		"sap/ui/core/UIComponent",
		"aklc/cm/components/formData/controller/ListSelector"
	],
	function(UIComponent, ListSelector) {
		"use strict";

		var Component = UIComponent.extend("aklc.cm.components.formData.Component", {

			metadata: {
				rootView: "aklc.cm.components.formData.view.Main",
				dependencies: {
					version: "1.8",
					libs: ["sap.ui.core"]
				},
				config: {
					resourceBundle: "i18n/i18n.properties"
				},
				properties: {
					componentData: "",
					eventBusSubscription: {
						name: "eventBusSubscription",
						type: "object",
						defaultValue: {
							channel: "formData",
							events: {
								contextChanged: "contextChanged",
								checkValid: "checkValid",
								formDataValidateAllFields: "formDataValidateAllFields",
								submitChanges: "submitChanges"
							}
						}
					}
				}
			}
		});

		Component.prototype.init = function() {
			var mConfig = this.getMetadata().getConfig();
			var i18nModel = new sap.ui.model.resource.ResourceModel({
				bundleUrl: [this.getRootPath(), mConfig.resourceBundle].join("/")
			});

			this.setModel(i18nModel, "i18n");
			this.listIds = [];

			var oComponentData = this.getComponentData();
			if (oComponentData) {
				this._oEventBus = oComponentData.eventBus;
				this.setModel(oComponentData.model);
			}

			this.oListSelector = new ListSelector(this);

			UIComponent.prototype.init.apply(this);
		};

		Component.prototype.getRootPath = function() {
			if (!this.rootPath) {
				this.rootPath = jQuery.sap.getModulePath("aklc.cm.components.formData");
			}
			return this.rootPath;
		};

		return Component;

	});