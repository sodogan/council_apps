(function() {
	"use strict";
	document.body.innerHTML += '<div id="content">';
	document.body.innerHTML += '<div id="qunit"></div>';
}());
