jQuery.sap.declare("hcm.myleaverequest.ZHTM_LRQ_MAN.Component");
sap.ui.component.load({
	name: "hcm.myleaverequest",
	url: "/sap/bc/ui5_ui5/sap/HCM_LRQ_CRE"
});

this.hcm.myleaverequest.Component.extend("hcm.myleaverequest.ZHTM_LRQ_MAN.Component", {
	metadata: {
		version: "1.0.0",
		config: {
			"serviceUrl": "/sap/opu/odata/sap/ZHTM_LEAVE_REQ_MANAGE_SRV/",
			"sap.ca.i18Nconfigs": {
				"bundleName": "hcm.myleaverequest.ZHTM_LRQ_MAN.i18n.i18n"
			},
			"sap.ca.serviceConfigs": [{
				"name": "My Leave Request",
				"serviceUrl": "/sap/opu/odata/sap/ZHTM_LEAVE_REQ_MANAGE_SRV/",
				"isDefault": true,
				"mockedDataSource": "./localService/metadata.xml"
			}]
		},
		customizing: {
			"sap.ui.viewReplacements": {
				"hcm.myleaverequest.view.S1": {
					"viewName": "hcm.myleaverequest.ZHTM_LRQ_MAN.view.S1Custom",
					"type": "XML"
				}
			},
			"sap.ui.controllerExtensions": {
				// "hcm.myleaverequest.Main": {
				// 	"controllerName": "hcm.myleaverequest.ZHTM_LRQ_MAN.MainCustom"
				// }					
				"hcm.myleaverequest.view.S1": {
					"controllerName": "hcm.myleaverequest.ZHTM_LRQ_MAN.view.S1Custom"
				},

				"hcm.myleaverequest.view.S3": {
					"controllerName": "hcm.myleaverequest.ZHTM_LRQ_MAN.view.S3Custom"
				},
				// "hcm.myleaverequest.view.S2": {
				// 	"controllerName": "hcm.myleaverequest.ZHTM_LRQ_MAN.view.S2Custom"
				// },
				   "hcm.myleaverequest.view.S6B": {
				   	"controllerName": "hcm.myleaverequest.ZHTM_LRQ_MAN.view.S6BCustom"
				   }
			}
		},
		routing: {
			routes: [{
					name: "fullScreen",
					targetAggregation: "pages",
					targetControl: "fioriContent",
					view: "App",
					viewPath: "sap.ca.scfld.md.view",
					subroutes: [{
						name: "change",
						pattern: "change/{requestID}",
						targetAggregation: "pages",
						targetControl: "app",
						view: "S1",
						viewLevel: 2,
						viewPath: "hcm.myleaverequest.view"
					}, {
						name: "entitlements",
						pattern: "entitlements",
						targetAggregation: "pages",
						targetControl: "app",
						view: "S2",
						viewLevel: 2,
						viewPath: "hcm.myleaverequest.view"
					}, {
						name: "home",
						pattern: "home/{pernr}/{name}",
						targetAggregation: "pages",
						targetControl: "app",
						view: "S1",
						viewLevel: 2,
						viewPath: "hcm.myleaverequest.view",
						clearTarget: true
					}, {
						name: "proxy",
						pattern: "",
						targetAggregation: "pages",
						targetControl: "app",
						view: "S0",
						viewLevel: 1,
						viewPath: "hcm.myleaverequest.ZHTM_LRQ_MAN.view"
					}]
				},
				// {
				// 	name: "master",
				// 	pattern: "history",
				// 	targetAggregation: "masterPages",
				// 	targetControl: "MainSplitContainer",
				// 	view: "S3",
				// 	viewLevel: 0,
				// 	viewPath: "hcm.myleaverequest.view",
				// 	subroutes: [{
				// 		name: "detail",
				// 		pattern: "detail/{contextPath}",
				// 		targetAggregation: "detailPages",
				// 		view: "S6B",
				// 		viewLevel: 1,
				// 		viewPath: "hcm.myleaverequest.view"
				// 	}, {
				// 		name: "noData",
				// 		pattern: "noData/{viewTitle}/{languageKey}",
				// 		targetAggregation: "detailPages",
				// 		view: "empty",
				// 		viewLevel: 1,
				// 		viewPath: "sap.ca.scfld.md.view"
				// 	}]
				// }
				{
					name: "masterDetail",
					targetAggregation: "pages",
					targetControl: "fioriContent",
					view: "MainSplitContainer",
					viewPath: "sap.ca.scfld.md.view",
					subroutes: [{
						name: "master",
						pattern: "history/{pernr}/{name}",
						targetAggregation: "masterPages",
						targetControl: "MainSplitContainer",
						view: "S3",
						viewLevel: 0,
						viewPath: "hcm.myleaverequest.view",
						subroutes: [{
							name: "detail",
							pattern: "detail/{contextPath}",
							targetAggregation: "detailPages",
							view: "S6B",
							viewLevel: 1,
							viewPath: "hcm.myleaverequest.view"
						}, {
							name: "noData",
							pattern: "noData/{viewTitle}/{languageKey}",
							targetAggregation: "detailPages",
							view: "empty",
							viewLevel: 1,
							viewPath: "sap.ca.scfld.md.view"
						}]
					}]
				}
			]
		}
	}
});