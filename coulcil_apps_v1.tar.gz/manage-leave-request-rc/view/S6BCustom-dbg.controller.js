jQuery.sap.require("sap.ca.scfld.md.controller.BaseDetailController");
jQuery.sap.require("hcm.myleaverequest.utils.Formatters");
jQuery.sap.require("hcm.myleaverequest.utils.UIHelper");
jQuery.sap.require("hcm.myleaverequest.ZHTM_LRQ_MAN.utils.DataManager");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.ca.ui.dialog.factory");
jQuery.sap.require("hcm.myleaverequest.ZHTM_LRQ_MAN.utils.ConcurrentEmployment");
sap.ui.controller("hcm.myleaverequest.ZHTM_LRQ_MAN.view.S6BCustom", {
	    extHookChangeFooterButtons: null,
	    extHookWithdrawDialogContent: null,
	    extHookDetailView: null,
	    onInit: function () {
	        sap.ca.scfld.md.controller.BaseDetailController.prototype.onInit.call(this);
	        this.oApplication = this.oApplicationFacade.oApplicationImplementation;
	        this.resourceBundle = this.oApplicationFacade.getResourceBundle();
	        this.oDataModel = this.oApplicationFacade.getODataModel();
	        hcm.myleaverequest.ZHTM_LRQ_MAN.utils.DataManager.init(this.oDataModel, this.resourceBundle);
	        hcm.myleaverequest.utils.Formatters.init(this.resourceBundle);
	        this._buildHeaderFooter();
	        this.oRouter.attachRouteMatched(this._handleRouteMatched, this);
	    },
	    _handleRouteMatched: function (e) {
	        if (e.getParameter("name") === "detail") {
	            hcm.myleaverequest.ZHTM_LRQ_MAN.utils.DataManager.init(this.oDataModel, this.resourceBundle);
	            e.getParameter("arguments").contextPath = decodeURIComponent(e.getParameter("arguments").contextPath);
	            var _ = this;
	            var c = decodeURIComponent(e.getParameter("arguments").contextPath);
	            var a = null;
	            var b = null;
	            var s = function () {
	                hcm.myleaverequest.utils.UIHelper.setRoutingProperty(b);
	                b = hcm.myleaverequest.utils.UIHelper.getRoutingProperty();
	                if (b !== null) {
	                    for (var i = 0; i < b.length; i++) {
	                        if (b[i]._navProperty === c) {
	                            a = i;
	                            break;
	                        }
	                    }
	                }
	                var d = b[a];
	                if (d) {
	                    _.currntObj = d;
	                    var f = _.byId("LRS6B_HEADER");
	                    var g = _.byId("LRS6B_ICNTABBAR");
	                    var l = _.byId("LRS6B_LBL_ORIGINAL_DATE");
	                    var h = _.byId("LRS6B_HEADER_START_DATE");
	                    var j = _.byId("LRS6B_HEADER_END_DATE");
	                    var k = _.byId("LRS6B_LBL_CHANGED_DATE");
	                    var m = _.byId("LRS6B_NEW_HEADER_START_DATE");
	                    var n = _.byId("LRS6B_NEW_HEADER_END_DATE");
	                    var o = _.byId("LRS6B_HEADER_STATUS");
	                    var q = _.byId("LRS6B_HEADER_STATUS2");
	                    if (_.currntObj.Notes === "") {
	                        g.setVisible(false);
	                    } else {
	                        g.setVisible(true);
	                    }
	                    f.setTitle(d.AbsenceTypeName);
	                    f.setNumber(hcm.myleaverequest.utils.Formatters.adjustSeparator(d.WorkingHoursDuration));
	                    f.setNumberUnit(_.resourceBundle.getText("LR_LOWERCASE_HOURS"));
	                    l.setVisible(hcm.myleaverequest.utils.Formatters.SET_RELATED_VISIBILITY(d.aRelatedRequests));
	                    h.setText(hcm.myleaverequest.utils.Formatters.DATE_ODATA_EEEdMMMyyyyLong(d.StartDate));
	                    j.setText(hcm.myleaverequest.utils.Formatters.FORMAT_ENDDATE_LONG(_.resourceBundle.getText("LR_HYPHEN"), d.WorkingDaysDuration, d.StartTime, d.EndDate, d.EndTime));
	                    k.setVisible(hcm.myleaverequest.utils.Formatters.SET_RELATED_VISIBILITY(d.aRelatedRequests));
	                    m.setVisible(hcm.myleaverequest.utils.Formatters.SET_RELATED_START_DATE_VISIBILITY(d.aRelatedRequests));
	                    m.setText(hcm.myleaverequest.utils.Formatters.FORMAT_RELATED_START_DATE_LONG(d.aRelatedRequests));
	                    n.setVisible(hcm.myleaverequest.utils.Formatters.SET_RELATED_END_DATE_VISIBILITY(d.aRelatedRequests));
	                    n.setText(hcm.myleaverequest.utils.Formatters.FORMAT_RELATED_END_DATE_LONG(_.resourceBundle.getText("LR_HYPHEN"), d.aRelatedRequests));
	                    o.setText(d.StatusName);
	                    o.setState(hcm.myleaverequest.utils.Formatters.State(d.StatusCode));
	                    q.setText(hcm.myleaverequest.utils.Formatters.FORMATTER_INTRO(d.aRelatedRequests));
	                    q.setState("Error");
	                    _.byId("LRS6B_NOTESICNTAB").setVisible(false);
	                    _.byId("S6B_NOTES_LIST").destroyItems();
	                    _.byId("LRS6B_ATTACH_ICNTAB").setVisible(false);
	                    _.byId("S6B_FILE_LIST").destroyItems();
	                    if (d.Notes) {
	                        var D = hcm.myleaverequest.utils.Formatters._parseNotes(d.Notes);
	                        if (D.NotesCollection) {
	                            _.byId("LRS6B_NOTESICNTAB").setVisible(true);
	                            _.byId("LRS6B_ICNTABBAR").setVisible(true);
	                            _.byId("LRS6B_NOTESICNTAB").setCount(D.NotesCollection.length);
	                            var N = new sap.ui.model.json.JSONModel(D);
	                            _.byId("S6B_NOTES_LIST").setModel(N, "notes");
	                        } else {
	                            _.byId("LRS6B_NOTESICNTAB").setVisible(false);
	                            _.byId("LRS6B_ICNTABBAR").setVisible(false);
	                        }
	                    }
	                    if (d.AttachmentDetails) {
	                        var r = hcm.myleaverequest.utils.Formatters._parseAttachments(d.AttachmentDetails, d.RequestID, _.oDataModel);
	                        if (r.AttachmentsCollection) {
	                            _.byId("LRS6B_ATTACH_ICNTAB").setCount(r.AttachmentsCollection.length);
	                            _.byId("LRS6B_ATTACH_ICNTAB").setVisible(true);
	                            _.byId("LRS6B_ICNTABBAR").setVisible(true);
	                            var t = new sap.ui.model.json.JSONModel(r);
	                            _.byId("S6B_FILE_LIST").setModel(t, "files");
	                        } else {
	                            _.byId("LRS6B_ATTACH_ICNTAB").setVisible(false);
	                        }
	                    }
	                    var u = $.when(hcm.myleaverequest.ZHTM_LRQ_MAN.utils.DataManager.getAbsenceTypeCollection());
	                    u.done(function (v) {
	                        _.handleAdditionalFields(d, v);
	                    });
	                    _.byId("LRS6B_ICNTABBAR").rerender();
	                    _._initState();
	                }
	            };
	            b = hcm.myleaverequest.ZHTM_LRQ_MAN.utils.DataManager.getCachedModelObjProp("ConsolidatedLeaveRequests");
	            var p = hcm.myleaverequest.utils.UIHelper.getPernr();
	            if (p) {
	                if (b === undefined) {
	                    hcm.myleaverequest.ZHTM_LRQ_MAN.utils.DataManager.getConsolidatedLeaveRequests(function (o) {
	                        b = o.LeaveRequestCollection;
	                        hcm.myleaverequest.ZHTM_LRQ_MAN.utils.DataManager.setCachedModelObjProp("ConsolidatedLeaveRequests", b);
	                        s();
	                        hcm.myleaverequest.utils.UIHelper.setIsLeaveCollCached(true);
	                    }, function (o) {
	                        hcm.myleaverequest.ZHTM_LRQ_MAN.utils.DataManager.parseErrorMessages(o);
	                    });
	                } else {
	                    s();
	                }
	            } else {
	                hcm.myleaverequest.ZHTM_LRQ_MAN.utils.ConcurrentEmployment.getCEEnablement(this, function () {
	                    if (b === undefined) {
	                        hcm.myleaverequest.ZHTM_LRQ_MAN.utils.DataManager.getConsolidatedLeaveRequests(function (o) {
	                            b = o.LeaveRequestCollection;
	                            hcm.myleaverequest.ZHTM_LRQ_MAN.utils.DataManager.setCachedModelObjProp("ConsolidatedLeaveRequests", b);
	                            s();
	                            hcm.myleaverequest.utils.UIHelper.setIsLeaveCollCached(true);
	                        }, function (o) {
	                            hcm.myleaverequest.ZHTM_LRQ_MAN.utils.DataManager.parseErrorMessages(o);
	                        });
	                    } else {
	                        s();
	                    }
	                });
	            }
	            if (this.extHookDetailView) {
	                this.extHookDetailView();
	            }
	        }
	    },
	    _buildHeaderFooter: function () {
	        var _ = this;
	         var o = {
	             sI18NDetailTitle: "LR_TITLE_LEAVE_REQUEST",
	             buttonList: [
	//                {
	//                    sId: "LRS6B_BTN_CHANGE",
	//                    sI18nBtnTxt: "LR_CHANGE",
	//                    onBtnPressed: function (e) {
	//                        _.onChange(e);
	//                    }
	//                },
	//                {
	//                    sId: "LRS6B_BTN_WITDHDRAW",
	//                    sI18nBtnTxt: "LR_WITHDRAW",
	//                    onBtnPressed: function (e) {
	//                        _.onWithdraw(e);
	//                    }
	//                }
	              ],
	              oAddBookmarkSettings: {
	                  title: _.resourceBundle.getText("LR_TITLE_DETAILS_VIEW"),
	                icon: "sap-icon://Fiori2/F0394"
	              },
	              bSuppressBookmarkButton: true
	        };
	      var m = new sap.ui.core.routing.HashChanger();
          var u = m.getHash();
	      if (u.indexOf("Shell-runStandaloneApp") >= 0) {
	          o.bSuppressBookmarkButton = false;
	    }
	      if (this.extHookChangeFooterButtons) {
	          o = this.extHookChangeFooterButtons(o);
	      }
	      this.setHeaderFooterOptions(o);
	//    },
	//    _isChangeRequest: function (r) {
	//        return r != undefined && r.length > 0 && r[0].LeaveRequestType == "2";
	//    },
	//    _hasNewEndDate: function (r) {
	//        return this._isChangeRequest(r) && this._hasEndDate(r[0].WorkingDaysDuration);
	//    },
	//    _hasEndDate: function (w) {
	//        return w != undefined && (hcm.myleaverequest.utils.Formatters.isHalfDayLeave(w) || w * 1 != 1);
	//    },
	//    _initState: function () {
	//        var b = false;
	//        if (!this.currntObj.RelatedRequests || this.currntObj.RelatedRequests.length < 1) {
	//            b = this.currntObj.ActionModifyInd;
	//        } else if (this.currntObj.RelatedRequests) {
	//            if (this.currntObj.RelatedRequests[0].LeaveRequestType == "2") {
	//                b = this.currntObj.RelatedRequests[0].ActionModifyInd;
	//            }
	//        }
	//        this.setBtnEnabled("LRS6B_BTN_CHANGE", b);
	//        var a = false;
	//        if (!this.currntObj.RelatedRequests || this.currntObj.RelatedRequests.length < 1) {
	//            a = this.currntObj.ActionDeleteInd || this.currntObj.StatusCode === "CREATED";
	//        }
	//        this.setBtnEnabled("LRS6B_BTN_WITDHDRAW", a);
	//    },
	//    onChange: function () {
	//        var r = this.currntObj.RequestID;
	//        hcm.myleaverequest.utils.UIHelper.setIsChangeAction(true);
	//        if (r === "") {
	//            r = this.currntObj.LeaveKey;
	//        }
	//        if (r !== "") {
	//            this.oRouter.navTo("change", { requestID: r });
	//        } else {
	//            jQuery.sap.log.warning("curntLeaveRequest is null", "_handleRouteMatched", "hcm.myleaverequest.view.S6B");
	//        }
	//    },
	//    onWithdraw: function () {
	//        var _ = this;
	//        this.oHeader = this.byId("LRS6B_HEADER");
	//        var a;
	//        var b;
	//        var c = this.currntObj.StartTime;
	//        var d = this.currntObj.EndTime;
	//        var e = this.currntObj.StartDate;
	//        var f = this.currntObj.EndDate;
	//        var g = this.currntObj.AbsenceTypeName;
	//        if (c === "000000" && d === "000000") {
	//            a = hcm.myleaverequest.utils.Formatters.DATE_ODATA_EEEdMMMyyyy(e);
	//            b = hcm.myleaverequest.utils.Formatters.DATE_ODATA_EEEdMMMyyyy(f);
	//        } else {
	//            a = hcm.myleaverequest.utils.Formatters.DATE_ODATA_EEEdMMMyyyy(e, "medium");
	//            b = hcm.myleaverequest.utils.Formatters.DATE_ODATA_EEEdMMMyyyy(f, "medium");
	//            a += " " + hcm.myleaverequest.utils.Formatters.TIME_hhmm(c);
	//            b += " " + hcm.myleaverequest.utils.Formatters.TIME_hhmm(d);
	//        }
	//        var n = null;
	//        if (this.oHeader) {
	//            n = this.oHeader.getNumber() + "  " + this.oHeader.getNumberUnit();
	//        } else {
	//            n = "-";
	//        }
	//        var s = {
	//            question: this.resourceBundle.getText("LR_WITHDRAWNMSG"),
	//            additionalInformation: [
	//                {
	//                    label: this.resourceBundle.getText("LR_BALANCE_DEDUCTIBLE"),
	//                    text: g
	//                },
	//                {
	//                    label: this.resourceBundle.getText("LR_FROM"),
	//                    text: a
	//                },
	//                {
	//                    label: this.resourceBundle.getText("LR_TO"),
	//                    text: b
	//                },
	//                {
	//                    label: this.resourceBundle.getText("LR_REQUEST"),
	//                    text: n
	//                }
	//            ],
	//            showNote: false,
	//            title: this.resourceBundle.getText("LR_TITLE_WITHDRAW"),
	//            confirmButtonLabel: this.resourceBundle.getText("LR_OK")
	//        };
	//        if (this.extHookWithdrawDialogContent) {
	//            s = this.extHookWithdrawDialogContent(s);
	//        }
	//        sap.ca.ui.dialog.factory.confirm(s, function (r) {
	//            if (r.isConfirmed === true) {
	//                _.withdraw();
	//            }
	//        });
	      },
	    withdraw: function () {
	        var _ = this;
	        var s = this.currntObj.StatusCode;
	        var e = this.currntObj.EmployeeID;
	        var r = this.currntObj.RequestID;
	        var c = this.currntObj.ChangeStateID;
	        var l = this.currntObj.LeaveKey;
	        hcm.myleaverequest.ZHTM_LRQ_MAN.utils.DataManager.withdrawLeaveRequest(s, e, r, c, l, function (a) {
	            sap.ui.getCore().getEventBus().publish("hcm.myleaverequest.LeaveCollection", "refresh");
	            hcm.myleaverequest.utils.UIHelper.setIsWithDrawn(_.currntObj._navProperty);
	            hcm.myleaverequest.utils.UIHelper.setIsWithDrawAction(true);
	            sap.m.MessageToast.show(_.resourceBundle.getText("LR_WITHDRAWDONE"));
	        }, function (a) {
	            hcm.myleaverequest.utils.UIHelper.errorDialog(a);
	        }, this);
	    },
	    
	    handleAdditionalFields: function (c, l) {
	        var _ = this;
	        try {
	            _.byId("LRS6B_ADDN_FORM_CNR").destroyFormElements();
	            _.byId("LRS6B_ADDN_ICNTAB").setVisible(false);
	            for (var h = 0; h < l.length; h++) {
	                if (l[h].AbsenceTypeCode == c.AbsenceTypeCode) {
	                    var a = l[h].AdditionalFields.results;
	                    for (var k = 0; k < a.length; k++) {
	                        var f = new sap.ui.layout.form.FormElement({
	                            layoutData: new sap.ui.layout.ResponsiveFlowLayoutData({ linebreak: true }),
	                            label: new sap.m.Label({ text: a[k].FieldLabel }),
	                            fields: [new sap.m.Text({ text: c.AdditionalFields[a[k].Fieldname].toString() })]
	                        });
	                        _.byId("LRS6B_ADDN_FORM_CNR").addFormElement(f);
                            _.byId("LRS6B_ADDN_ICNTAB").setVisible(true);
	                        _.byId("LRS6B_ICNTABBAR").setVisible(true);
	                    }
	                }
	            }
	        } catch (e) {
	            jQuery.sap.log.warning("additional fields couldn't be added", "_handleRouteMatched", "hcm.myleaverequest.view.S6B");
	            _.byId("LRS6B_ADDN_FORM_CNR").destroyFormElements();
	            _.byId("LRS6B_ADDN_ICNTAB").setVisible(false);
	        }
	    }
});