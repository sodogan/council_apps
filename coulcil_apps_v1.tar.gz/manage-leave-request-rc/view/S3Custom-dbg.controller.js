jQuery.sap.require("sap.ca.scfld.md.controller.ScfldMasterController");
jQuery.sap.require("hcm.myleaverequest.utils.Formatters");
jQuery.sap.require("hcm.myleaverequest.ZHTM_LRQ_MAN.utils.DataManager");
jQuery.sap.require("hcm.myleaverequest.utils.UIHelper");
jQuery.sap.require("hcm.myleaverequest.ZHTM_LRQ_MAN.utils.ConcurrentEmployment");
jQuery.sap.require("sap.m.ObjectAttribute");
sap.ui.controller("hcm.myleaverequest.ZHTM_LRQ_MAN.view.S3Custom", {
	//    extHookChangeFooterButtons: null,
	//    extHookLeaveRequestCollection: null,
	//    extHookItemTemplate: null,

	lastPernr: null,

 _handleRouteMatched : function(oEvent) {
 	
		//Added Town Pump - Init view code
		if (oEvent.getParameter("name") === "masterDetail") {

			var zModel = sap.ui.getCore().getModel("ZPERNR");
			if (zModel.getData().pernr !== this.lastPernr) {
				this.lastPernr = zModel.getData().pernr;
				this._initData();
				this.showEmptyView();
			}
		}
		//End Town Pump
		
        var _this = this;
        
        
  // to use cached data for local routing
  if (oEvent.getParameter("name") === "master" && ((this._isLocalRouting === false) || hcm.myleaverequest.utils.UIHelper.getIsChangeAction())) {
   hcm.myleaverequest.utils.UIHelper.setIsChangeAction(false);
   //clear searchField
   if(!!this._oControlStore & !!this._oControlStore.oMasterSearchField && !!this._oControlStore.oMasterSearchField.clear){
    this._oControlStore.oMasterSearchField.clear();
   }
   var oPernr = hcm.myleaverequest.utils.UIHelper.getPernr();
   if (oPernr) {
     _this._initData();
    }
   else{
       hcm.myleaverequest.utils.ConcurrentEmployment.getCEEnablement(this, function() {
    _this._initData();
   });
   }

  }

  //reset flag
  if(oEvent.getParameter("name") === "master" && this._isLocalRouting === false){
   this._isLocalRouting = true;
  }

 }
	// onInit: function() {
	// 	sap.ca.scfld.md.controller.ScfldMasterController.prototype.onInit.call(this);
	// 	this.oApplication = this.oApplicationFacade.oApplicationImplementation;
	// 	this.resourceBundle = this.oApplicationFacade.getResourceBundle();
	// 	this.oDataModel = this.oApplicationFacade.getODataModel();
	// 	hcm.myleaverequest.ZHTM_LRQ_MAN.utils.DataManager.init(this.oDataModel, this.resourceBundle);
	// 	hcm.myleaverequest.utils.Formatters.init(this.resourceBundle);
	// 	this.oRouter.attachRouteMatched(this._handleRouteMatched, this);
	// 	this.masterListCntrl = this.oView.byId("list");
	// 	this.objLeaveRequestCollection = null;
	// 	this.oBus = sap.ui.getCore().getEventBus();
	// 	this.oBus.subscribe("hcm.myleaverequest.ZHTM_LRQ_MAN.LeaveCollection", "refresh", this._initData, this);
	// 	this.onDataLoaded();
	// 	this._fnRefreshCompleted = null;
	// 	this._isLocalRouting = false;
	// 	this._isInitialized = false;
	// 	this._isMasterRefresh = false;
	// 	this._searchField = "";
	// },
	// onDataLoaded: function () {
	//     var t = this;
	//     if (t.getList().getItems().length < 1) {
	//         if (!sap.ui.Device.system.phone) {
	//             t.showEmptyView();
	//         }
	//     }
	// },
	//    getHeaderFooterOptions: function () {
	//        var _ = this;
	//        var o = {
	//            sI18NMasterTitle: "LR_TITLE_LEAVE_REQUESTS",
	//            onRefresh: function (s, r) {
	//                _._fnRefreshCompleted = r;
	//                _._searchField = s;
	//                _._isMasterRefresh = true;
	//                _._initData();
	//            }
	//        };
	//        var m = new sap.ui.core.routing.HashChanger();
	//        var u = m.getHash();
	//        if (u.indexOf("Shell-runStandaloneApp") >= 0) {
	//            o.bSuppressBookmarkButton = true;
	//        }
	//        if (this.extHookChangeFooterButtons) {
	//            o = this.extHookChangeFooterButtons(o);
	//        }
	//        return o;
	//    },
	// _handleRouteMatched: function(e) {

	// 	//Added Town Pump - Init view code
	// 	if (e.getParameter("name") === "masterDetail") {

	// 		var zModel = sap.ui.getCore().getModel("ZPERNR");
	// 		if (zModel.getData().pernr !== this.lastPernr) {
	// 			this.lastPernr = zModel.getData().pernr;
	// 			this._initData();
	// 		}
	// 	}
	// 	//End Town Pump

	// 	var _ = this;

	// 	if (e.getParameter("name") === "master" && (this._isLocalRouting === false || hcm.myleaverequest.utils.UIHelper.getIsChangeAction())) {
	// 		hcm.myleaverequest.utils.UIHelper.setIsChangeAction(false);
	// 		if (!!this._oControlStore & !!this._oControlStore.oMasterSearchField && !!this._oControlStore.oMasterSearchField.clear) {
	// 			this._oControlStore.oMasterSearchField.clear();
	// 		}
	// 		var p = hcm.myleaverequest.utils.UIHelper.getPernr();
	// 		if (p) {
	// 			_._initData();
	// 		} else {
	// 			hcm.myleaverequest.ZHTM_LRQ_MAN.utils.ConcurrentEmployment.getCEEnablement(this, function() {
	// 				_._initData();
	// 			});
	// 		}
	// 	}
	// 	if (e.getParameter("name") === "master" && this._isLocalRouting === false) {
	// 		this._isLocalRouting = true;
	// 	}

 
	// },


 
	// _initData: function() {
	// 	var _ = this;
	// 	sap.ca.ui.utils.busydialog.requireBusyDialog();
	// 	if (!hcm.myleaverequest.utils.UIHelper.getIsLeaveCollCached()) {
	// 		hcm.myleaverequest.ZHTM_LRQ_MAN.utils.DataManager.getConsolidatedLeaveRequests(function(o) {
	// 			_.objLeaveRequestCollection = o.LeaveRequestCollection;
	// 			if (_.extHookLeaveRequestCollection) {
	// 				_.objLeaveRequestCollection = _.extHookLeaveRequestCollection(_.objLeaveRequestCollection);

	// 			}
	// 			hcm.myleaverequest.ZHTM_LRQ_MAN.utils.DataManager.setCachedModelObjProp("ConsolidatedLeaveRequests", _.objLeaveRequestCollection);
	// 			hcm.myleaverequest.utils.UIHelper.setIsLeaveCollCached(false);
	// 			_.setMasterListItems();
	// 			if (_._searchField !== "") {
	// 				_.applySearchPattern(_._searchField);
	// 			}
	// 		}, function(o) {
	// 			hcm.myleaverequest.ZHTM_LRQ_MAN.utils.DataManager.parseErrorMessages(o);
	// 		});
	// 	} else {
	// 		_.objLeaveRequestCollection = hcm.myleaverequest.ZHTM_LRQ_MAN.utils.DataManager.getCachedModelObjProp("ConsolidatedLeaveRequests");
	// 		hcm.myleaverequest.utils.UIHelper.setIsLeaveCollCached(false);
	// 		_.setMasterListItems();
	// 	}
	// },
	//    getDetailNavigationParameters: function (l) {
	//        var n = "";
	//        if (l) {
	//            var p = l.getBindingContext(this.sModelName).getPath().substr(1).split("/");
	//            if (p.length > 1 && this.objLeaveRequestCollection.length > p[1]) {
	//                n = this.objLeaveRequestCollection[p[1]]._navProperty;
	//            }
	//            return { contextPath: encodeURIComponent(n) };
	//        }
	//    },
	// setMasterListItems: function() {
	// 	var _ = this;
	// 	try {
	// 		if (_.objLeaveRequestCollection) {
	// 			hcm.myleaverequest.utils.UIHelper.setRoutingProperty(_.objLeaveRequestCollection);
	// 			_.objLeaveRequestCollection = hcm.myleaverequest.utils.UIHelper.getRoutingProperty();
	// 			var m = new sap.ui.model.json.JSONModel({
	// 				"LeaveRequestCollection": _.objLeaveRequestCollection
	// 			});
	// 			_.oView.setModel(m);
	// 			var i = new sap.m.ObjectListItem({
	// 				type: "{device>/listItemType}",
	// 				title: "{AbsenceTypeName}",
	// 				number: "{path:'WorkingHoursDuration', formatter:'hcm.myleaverequest.utils.Formatters.adjustSeparator'}",
	// 				numberUnit: _.resourceBundle.getText("LR_LOWERCASE_HOURS"),
	// 				attributes: [
	// 					new sap.m.ObjectAttribute({
	// 						text: "{path:'StartDate', formatter:'hcm.myleaverequest.utils.Formatters.DATE_ODATA_EEEdMMMyyyy'}"
	// 					}),
	// 					new sap.m.ObjectAttribute({
	// 						text: "{parts:[{path:'i18n>LR_HYPHEN'},{path:'WorkingDaysDuration'},{path:'StartTime'},{path:'EndDate'},{path:'EndTime'}], formatter: 'hcm.myleaverequest.utils.Formatters.FORMAT_ENDDATE'}"
	// 					})
	// 				],
	// 				firstStatus: new sap.m.ObjectStatus({
	// 					text: "{StatusName}",
	// 					state: "{path:'StatusCode', formatter:'hcm.myleaverequest.utils.Formatters.State'}"
	// 				}),
	// 				secondStatus: new sap.m.ObjectStatus({
	// 					state: "Error",
	// 					text: "{path:'aRelatedRequests', formatter:'hcm.myleaverequest.utils.Formatters.FORMATTER_INTRO'}"
	// 				}),
	// 				press: jQuery.proxy(_._handleItemPress, _)
	// 			});
	// 			if (this.extHookItemTemplate) {
	// 				i = this.extHookItemTemplate(i);
	// 			}
	// 			_.masterListCntrl.bindItems({
	// 				path: "/LeaveRequestCollection",
	// 				template: i
	// 			});
	// 			if (_._fnRefreshCompleted) {
	// 				_._fnRefreshCompleted();
	// 			}
	// 		}
	// 	} catch (e) {
	// 		jQuery.sap.log.warning(e);
	// 	}
	// 	sap.ca.ui.utils.busydialog.releaseBusyDialog();
	// 	if (!jQuery.device.is.phone && !_._isInitialized) {
	// 		_.registerMasterListBind(_.masterListCntrl);
	// 		_._isInitialized = true;
	// 	}
	// 	if (!jQuery.device.is.phone || hcm.myleaverequest.utils.UIHelper.getIsWithDrawAction()) {
	// 		_.setLeadSelection();
	// 	}
	// },
	// setLeadSelection: function() {
	// 	var I = this.masterListCntrl.getItems();
	// 	var o = null,
	// 		s = null;
	// 	var c = window.location.hash.split("detail");
	// 	if (c[1] !== undefined) {
	// 		c = c[1].split("/");
	// 	}
	// 	if (c[1] !== undefined) {
	// 		s = decodeURIComponent(c[1]);
	// 		s = decodeURIComponent(s);
	// 	}
	// 	if (s !== null && s !== "" && this.objLeaveRequestCollection) {
	// 		for (var i = 0; i < this.objLeaveRequestCollection.length; i++) {
	// 			if (this.objLeaveRequestCollection[i]._navProperty === s) {
	// 				o = i;
	// 				break;
	// 			}
	// 		}
	// 		if (o === null) {
	// 			if (hcm.myleaverequest.utils.UIHelper.getIsWithDrawn(s) && I.length > 0) {
	// 				this.setListItem(I[0]);
	// 			} else {
	// 				this.showEmptyView();
	// 			}
	// 		} else {
	// 			if (I.length > o) {
	// 				this.setListItem(I[o]);
	// 			}
	// 		}
	// 	} else {
	// 		o = 0;
	// 		if (I.length > 0) {
	// 			this.setListItem(I[o]);
	// 		}
	// 	}
	// },
	//    setListItem: function (i) {
	//        if (this._isMasterRefresh) {
	//            this._isMasterRefresh = false;
	//            this.setLeadSelection();
	//        } else {
	//            if (i !== undefined) {
	//                i.setSelected(true);
	//                if (hcm.myleaverequest.utils.UIHelper.getIsWithDrawAction() && jQuery.device.is.phone) {
	//                    hcm.myleaverequest.utils.UIHelper.setIsWithDrawAction(false);
	//                    this.oRouter.navTo("detail", this.getDetailNavigationParameters(i), true);
	//                } else {
	//                    this.oRouter.navTo("detail", this.getDetailNavigationParameters(i), !jQuery.device.is.phone);
	//                }
	//            }
	//            this._isLocalRouting = true;
	//        }
	//    }

	// extHookLeaveRequestCollection: function(objLRC) {
	// 	//Added Town Pump - Init view code
	// 	if (objLRC.length > 0) {
	// 		var I = this.masterListCntrl.getItems();
	// 		if (I !== undefined && I.length > 0) {
	// 			I[0].setSelected(true);
	// 		} else {
	// 			this.showEmptyView();
	// 		}
	// 	} else {
	// 		this.showEmptyView();
	// 	}

	// 	return objLRC;
	// }

});