jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("hcm.myleaverequest.utils.UIHelper");
jQuery.sap.require("hcm.myleaverequest.utils.DataManager");
jQuery.sap.require("hcm.myleaverequest.utils.ConcurrentEmployment");
jQuery.sap.require("hcm.myleaverequest.utils.CalendarTools");

sap.ca.scfld.md.controller.BaseFullscreenController.extend("hcm.myleaverequest.ZHTM_LRQ_MAN.controller.S0", {
	//sap.ui.controller("hcm.myleaverequest.ZHTM_LRQ_MAN.controller.S0", {

	_serviceURl: null,
	_DataManager: null,

	/**
	 * Called when a controller is instantiated and its View controls (if available) are already created.
	 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	 * @memberOf S0
	 */
	onInit: function() {

		this.oRouter.attachRouteMatched(this._handleRouteMatched, this);

	//	jQuery.sap.require("sap.ca.scfld.md.Startup");


		// sap.ui.getCore().dataManager = jQuery.extend(true, {}, hcm.myleaverequest.utils.DataManager);
		
		// sap.ui.getCore().ConcurrentEmployment = jQuery.extend(true, {}, hcm.myleaverequest.utils.ConcurrentEmployment);
		// sap.ui.getCore().CalendarTools = jQuery.extend(true, {}, hcm.myleaverequest.utils.CalendarTools);		
		// sap.ui.getCore().UIHelper = jQuery.extend(true, {}, hcm.myleaverequest.utils.UIHelper);
	//	sap.ca.scfld.md.Startup.init("hcm.myleaverequest", this);

		//	hcm.myleaverequest.utils.DataManager = hcm.myleaverequest.utils.DataManager.clone();

	},

	_handleRouteMatched: function(a) {
		if (a.getParameter("name") === "proxy") {
			//			 hcm.myleaverequest.utils.DataManager.setCachedModelObjProp("DefaultConfigurations", null);
			// hcm.myleaverequest.utils.DataManager.getConfiguration();
			// hcm.myleaverequest.utils.DataManager.setCachedModelObjProp("AbsenceTypeCollection", null);
			this.getEmployees();
		}
	},

	getEmployees: function(searchValue) {

		var self = this;
		var arrParams = [];
		var path = "/Employees";

		if (searchValue !== undefined) {
			var searchString = "$filter=Name eq '*" + searchValue + "*'";
			//	arrParams = [encodeURIComponent(searchString)];
			arrParams = searchString;
		}

		var serviceURL = this.getOwnerComponent().getMetadata().getConfig().serviceUrl;

		var oDataModel = new sap.ui.model.odata.ODataModel(serviceURL, false);
		oDataModel.setCountSupported(false);

		oDataModel.read(path, null, arrParams, true, function(objResponse) {
			var oModelPernr = new sap.ui.model.json.JSONModel(objResponse.results);
			self.getView().setModel(oModelPernr, "proxy");
		}, function() {
			sap.m.MessageBox.error("Error determing assigned employees");
		});

	},

	onSelectionChange: function(oEvent) {
		var oSource = oEvent.getSource();
		var pernr = oSource.getSelectedItem().getDescription();
		var name = oSource.getSelectedItem().getTitle();

		hcm.myleaverequest.utils.UIHelper.setPernr(pernr);

		oEvent.getParameter("listItem").setSelected(false);



		// hcm.myleaverequest.utils.DataManager.getApprover(function(name, id) {
		// 	//		this._DataManager.getApprover(function(name,id) {

		// 	var Approver = name;

		// }, function() {}, this);

		//Indicate Pernr has changed
		var data = {
			"pernr": pernr
		};
		var oModel = new sap.ui.model.json.JSONModel(data);

		sap.ui.getCore().setModel(oModel, "ZPERNR");

		this.getOwnerComponent().getRouter().navTo("home", {
			"pernr": pernr,
			"name": name
		});
	},

	onSearch: function(oEvent) {
		var searchValue = oEvent.getParameter("query");
		this.getEmployees(searchValue);
	},

	/**
	 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
	 * (NOT before the first rendering! onInit() is used for that one!).
	 * @memberOf S0
	 */
	//	onBeforeRendering: function() {
	//
	//	},

	/**
	 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
	 * This hook is the same one that SAPUI5 controls get after being rendered.
	 * @memberOf S0
	 */
	//	onAfterRendering: function() {
	//
	//	},

	/**
	 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
	 * @memberOf S0
	 */
	onExit: function() {
					hcm.myleaverequest.utils.DataManager.setCachedModelObjProp("DefaultConfigurations", null);
					hcm.myleaverequest.utils.DataManager.setCachedModelObjProp("AbsenceTypeCollection", null);
	//	try {
	// 		var c = hcm.myleaverequest.utils.ConcurrentEmployment.getControllerInstance();
	// 		hcm.myleaverequest.utils.UIHelper.setPernr("");



	// 	hcm.myleaverequest.utils.DataManager = null;
	// 	hcm.myleaverequest.utils.ConcurrentEmployment = null;
	// 	 hcm.myleaverequest.utils.CalendarTools = null;
 //hcm.myleaverequest.utils.UIHelper = null;

	// 	hcm.myleaverequest.utils.DataManager = sap.ui.getCore().dataManager;
	// 	hcm.myleaverequest.utils.ConcurrentEmployment = sap.ui.getCore().ConcurrentEmployment;
	// 	 hcm.myleaverequest.utils.CalendarTools = sap.ui.getCore().CalendarTools;	
	// 	 	hcm.myleaverequest.utils.UIHelper = sap.ui.getCore().UIHelper;
 
  //     var oCustomData = new sap.ui.core.CustomData({
  //                  "key": "ApproverEmployeeID",
  //                  "value": "jim"  //this.oChangeModeData.ApproverEmployeeID
  //                  });
                    
  //                  sap.ui.core.CustomData = oCustomData;
                    
		// 	if (c.oCEDialog.isOpen()) {
		// 		c.oCEDialog.Cancelled = true;
		// 		c.oCEDialog.close();
		// 	}
		// } catch (e) {
		// 	jQuery.sap.log.error("couldn't execute onExit", ["onExit failed in main controller"], ["hcm.myleaverequest.Main"]);
		// }
	}

});